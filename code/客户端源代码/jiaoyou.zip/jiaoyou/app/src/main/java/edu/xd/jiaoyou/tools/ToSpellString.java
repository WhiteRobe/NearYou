package edu.xd.jiaoyou.tools;

/**
 * Created by ZhengXi on 2017/6/11.
 */
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import net.sourceforge.pinyin4j.PinyinHelper;

public class ToSpellString {
    // GBK编码采用双字节编码方案，其编码范围：8140－FEFE
    // 高位：81-FE,低位：40-FE，剔除xx7F码位
    private static final int BEGIN = 0x8140;
    private static final int END = 0xFEFE;
    private static boolean isFirstName = true;
    // 仅收录百家姓中，各个读音首字母不同的多音字
    private static HashMap<Character,String> DUOYINZI = null;

    static {
        DUOYINZI = new HashMap<>();
        DUOYINZI.put('阿',"a");
        DUOYINZI.put('艾',"ai");
        DUOYINZI.put('晁',"chao");
        DUOYINZI.put('褚',"chu");
        DUOYINZI.put('丁',"ding");
        DUOYINZI.put('冯',"feng");
        DUOYINZI.put('景',"jing");
        DUOYINZI.put('贾',"jia");
        DUOYINZI.put('区',"ou");
        DUOYINZI.put('齐',"qi");
        DUOYINZI.put('仇',"qiu");
        DUOYINZI.put('乾',"qian");
        DUOYINZI.put('沈',"shen");
        DUOYINZI.put('折',"she");
        DUOYINZI.put('宿',"su");
        DUOYINZI.put('石',"shi");
        DUOYINZI.put('万',"wan");
        DUOYINZI.put('解',"xie");
        DUOYINZI.put('叶',"ye");
        DUOYINZI.put('余',"yu");
        DUOYINZI.put('查',"cha");
        DUOYINZI.put('藏',"zang");
        DUOYINZI.put('曾',"zeng");
        DUOYINZI.put('翟',"zhai");
    }

    /**
     * 获取一个字符串的拼写形式,大写
     * @param s
     * @return
     */
    public static String getStringSpell(String s) {
        if(null==s ||s.equals("")) {
            throw new IllegalArgumentException("参数不能为空");
        }
        isFirstName = true;
        StringBuilder sb = new StringBuilder();
        char[] chars = s.toCharArray();
        for(int i=0;i<chars.length;i++) {
            sb.append(getCharSpell(chars[i]));
        }
        return sb.toString().toUpperCase();
    }

    /**
     * 获取一个字符串的拼写首字母,大写
     * @param s
     * @return
     */
    public static char getFirstLetter(String s) {
        return getStringSpell(s).charAt(0);
    }

    /**
     * 获取每个字符的拼写形式
     * 中文：拼音
     * 英文：字母
     * 数字及其他特殊字符：#
     * @param c
     * @return
     */
    @SuppressWarnings("rawtypes")
    public static String getCharSpell(char c) {
        // 对数字：返回"#"
        if (c >= '0' && c <= '9') {
            // System.out.println("数字");
            return "#";
        }
        // 对英文字母：返回小写字母
        if (c >= 'a' && c <= 'z') {
            // System.out.println("字母");
            return c+"";
        }
        if (c >= 'A' && c <= 'Z') {
            // System.out.println("字母");
            return (char) (c-'A'+'a')+"";
        }
        int code = gbkValue(c);
        // GBK编码收录的汉字
        if(code>=BEGIN && code <=END) {
            // System.out.println("汉字");
            // 姓氏使用多音字表，其余的字默认使用第一个拼音
            if(isFirstName) {
                Iterator iter = DUOYINZI.entrySet().iterator();
                while (iter.hasNext()) {
                    Map.Entry entry = (Map.Entry) iter.next();
                    if(c == (char) entry.getKey())
                        return (String) entry.getValue();
                }
            }
            isFirstName = false;
            try {
                // 对于中文符号，日文韩文等，此方法会抛出NullPointerException
                String[] py = PinyinHelper.toHanyuPinyinStringArray(c);
                return py[0].replaceAll("\\d+","");
            } catch(Exception e) {
                return "#";
            }
        }
        // 对于其他特殊字符：返回"#"
        return "#";
    }

    /**
     * 获得字符的GBK十进制编码
     * @param c
     * @return
     */
    private static int gbkValue(char c) {
        String str = c +"";
        try {
            byte[] bytes = str.getBytes("GBK");
            // 不是双字节的，返回
            if (bytes.length < 2) {
                return 0;
            }
            // 剔除xx7F位码
            if((bytes[1] & 0x00FF )== 0x007F) {
                return 0;
            }
            return (bytes[0] << 8 & 0xFF00) + (bytes[1] & 0x00FF);
        } catch (Exception e) {
            return 0;
        }
    }
}

