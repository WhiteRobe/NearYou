package edu.xd.jiaoyou.view.main;

import android.view.View;

/**
 * Created by ZhengXi on 2017/6/19.
 */

public interface OnTitleClickListener {
    void onTitleClick(View view,int id);
}
