package edu.xd.jiaoyou.view.photoviewer;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.MotionEventCompat;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.github.chrisbanes.photoview.PhotoView;

import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.Image;
import edu.xd.jiaoyou.view.custom.CustomToast;
import edu.xd.jiaoyou.view.custom.GifImageView;

/**
 * Created by ZhengXi on 2017/6/14.
 */

public class PhotoViewerFragment extends Fragment {
    private View mView;
    private RelativeLayout mRelativeLayout;
    private Button btnBack;
    private TextView tvTitle;
    private Button btnFunction;
    private PhotoView mPhotoView;
    private Image image;
    private String path;
    private CharSequence title;
    private int minWidth,minHeight,maxWidth,maxHeight; //图片最佳可视化范围
    private boolean isFirstGif = true; //是否第一次播放gif

    private View.OnLongClickListener onLongClickListener = null;

    public PhotoViewerFragment setImage(Image image) {
        this.image = image;
        return this;
    }

    public PhotoViewerFragment setImagePath(String path) {
        this.path = path;
        return this;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        mRelativeLayout = ((PhotoViewerActivity) getActivity()).mRelativeLayout;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                       Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_photoviewer,null);

        mPhotoView= (PhotoView) mView.findViewById(R.id.photoview);
        mPhotoView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mRelativeLayout.getVisibility() == View.GONE)
                    mRelativeLayout.setVisibility(View.VISIBLE);
                else if(mRelativeLayout.getVisibility() == View.VISIBLE)
                    mRelativeLayout.setVisibility(View.GONE);
            }
        });

        Glide.with(PhotoViewerFragment.this)
                .load(path)
                .into(mPhotoView);

        return mView;
    }

    /**
     * 按照需要为
     * @param onLongClickListener
     */
    public void setOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.onLongClickListener = onLongClickListener;
    }

    /**
     * 在不使用Glide框架的情况下，使用自定义的Image类型作为数据类型
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Deprecated
    public View onDeprecatedCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_photoviewer,null);
        mRelativeLayout = (RelativeLayout) mView.findViewById(R.id.toolbar_photoviewer);
        btnBack = (Button) mView.findViewById(R.id.btn_back);
        tvTitle = (TextView) mView.findViewById(R.id.textView_title);
        tvTitle.setText(title);
        btnFunction = (Button) mView.findViewById(R.id.btn_function);
        mPhotoView= (PhotoView) mView.findViewById(R.id.photoview);

        minWidth = (int) getResources().getDimension(R.dimen.x100);
        minHeight = (int) getResources().getDimension(R.dimen.y100);
        maxWidth = (int) getResources().getDimension(R.dimen.x1080);
        maxHeight = (int) getResources().getDimension(R.dimen.y1920);

        if(image.type == Constant.ImageType.COMMON) {
            //mGifView.setVisibility(View.GONE);
            //设置缩放，photoView做的比较完美了，不需要手动设置
            /**/
            mPhotoView.setImageBitmap(image.toBitmap());
            //覆盖默认的点击放大效果，改为点击全屏
            mPhotoView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(mRelativeLayout.getVisibility() == View.GONE)
                        mRelativeLayout.setVisibility(View.VISIBLE);
                    else if(mRelativeLayout.getVisibility() == View.VISIBLE)
                        mRelativeLayout.setVisibility(View.GONE);
                }
            });
            mPhotoView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    //保存图片
                    return false;
                }
            });
        }

        else if(image.type == Constant.ImageType.GIF) {
            mPhotoView.setVisibility(View.GONE);
            //仅在第一次播放gif时提示
            if(isFirstGif) {
                CustomToast.makeText(getContext(), "如果Gif无法正常播放，可能是手机开启了硬件加速功能",
                        CustomToast.LENGTH_SHORT).show();
                isFirstGif = false;
            }
            /*ViewGroup.LayoutParams params = mGifView.getLayoutParams();
            //计算缩放比例
            float scale = 0.0f;
            if(image.width>=minWidth && image.width<=maxWidth && image.height>=minHeight &&
                    image.height<=maxHeight) {
                params.width = image.width;
                params.height = image.height;
            }
            else if(image.width<minWidth && image.height<minHeight) {
                scale = minWidth / (float) image.width;
                params.width = minWidth;
                params.height = (int) (image.height * scale);
            }
            else if(image.width > maxWidth) {
                scale = maxWidth/ (float) image.width;
                if(image.height>maxHeight && maxHeight<image.height * scale) {
                    scale = maxHeight / (float) image.height;
                }
                params.width = maxWidth;
                params.height = (int) (image.height * scale);
            }
            else if(image.height > maxHeight) {
                scale = maxHeight/ (float) image.height;
                if(image.width>maxWidth && maxWidth<image.width * scale) {
                    scale = maxWidth / (float) image.width;
                }
                params.width = (int) (image.width * scale);
                params.height = maxHeight;
            }
            mGifView.setLayoutParams(params);
            mGifView.setImage(image);
            */
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //暂定方案，image并未释放
                getActivity().finish();
            }
        });
        mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mRelativeLayout.getVisibility() == View.GONE)
                    mRelativeLayout.setVisibility(View.VISIBLE);
                else if(mRelativeLayout.getVisibility() == View.VISIBLE)
                    mRelativeLayout.setVisibility(View.GONE);
            }
        });
        mView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                //保存图片
                return false;
            }
        });
        return mView;
    }

    /*//为gifView设置缩放手势
    @Deprecated
    private void setGestureEvent() {
        class Pointer {
            float primaryX;float primaryY;
            float secondX; float secondY;
            public String toString() {
                return primaryX+" "+primaryY+"->"+secondX+" "+secondY;
            }
        }

        ViewGroup.LayoutParams params = mGifView.getLayoutParams();
        mGifView.setOnTouchListener(new View.OnTouchListener() {
            int firstPointerID;
            int secondPointerID;
            float firstX,firstY,secondX,secondY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = MotionEventCompat.getActionMasked(event);
                switch (action) {
                    case MotionEvent.ACTION_DOWN:
                        firstPointerID = event.getPointerId(event.getActionIndex());
                        firstX = event.getRawX();
                        firstY = event.getRawY();
                        break;
                    case MotionEvent.ACTION_POINTER_DOWN:
                        secondPointerID= event.getPointerId(event.getActionIndex());
                        break;
                    case MotionEvent.ACTION_MOVE:
                        int index = event.findPointerIndex(firstPointerID);
                        secondX = MotionEventCompat.getX(event,index);
                        secondY = MotionEventCompat.getY(event,index);
                        break;
                    case MotionEvent.ACTION_POINTER_UP:
                        break;
                    case MotionEvent.ACTION_UP:
                        secondX = event.getRawX();
                        secondY = event.getRawY();
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        break;
                }
                System.out.println(firstX+" "+firstY+"->"+secondX+" "+secondY);

                return false;
            }
        });
    }
    */
}
