package edu.xd.jiaoyou.view;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import org.json.JSONException;
import org.json.JSONObject;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.tools.MessageTool;

/**
 * Created by ZhengXi on 2017/5/26.
 */

public class SettingActivity extends AppCompatActivity implements View.OnClickListener {

    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;
    private UICallback uiCallback=new UICallback() {
        @Override
        public void dealServerRes(JSONObject msgIn) {}

        @Override
        public void dealServerPush(JSONObject msgIn) {
            String response = null;
            try {
                JSONObject data = msgIn.getJSONObject("Data");
                response = data.getString("Class");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {}

        @Override
        public void localMsg(String msg) {}
    };
    private ServiceConnection connection=new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
            dataService.setUICallback(uiCallback);
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };
    private Button btnBack;
    private Button btnMp;
    private Button btnCe;
    private Button btnFb;
    private Button btnLo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        Intent bindIntent = new Intent(SettingActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        init();
    }

    private void init() {
        btnBack = (Button) findViewById(R.id.btn_setting_back);
        btnBack.setOnClickListener(this);
        btnMp = (Button) findViewById(R.id.btn_setting_modifyPassword);
        btnMp.setOnClickListener(this);
        btnCe = (Button) findViewById(R.id.btn_setting_certification);
        btnCe.setOnClickListener(this);
        btnFb = (Button) findViewById(R.id.btn_setting_feedback);
        btnFb.setOnClickListener(this);
        btnLo = (Button) findViewById(R.id.btn_setting_logout);
        btnLo.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_setting_back:
                SettingActivity.this.onBackPressed();
                break;
            case R.id.btn_setting_modifyPassword:
                //dataService.resetPW();
                break;
            case R.id.btn_setting_certification:
                break;
            case R.id.btn_setting_feedback:
                break;
            case R.id.btn_setting_logout:
                dataService.sendJsonMsg(MessageTool.mkOfflineJSMsg(dataService.getUserID(),dataService.getMID()));
                Intent intent = new Intent(SettingActivity.this,LoginActivity.class);
                startActivity(intent);
                finish();
                break;
        }
    }
}
