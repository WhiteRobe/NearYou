package edu.xd.jiaoyou.view.main;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONObject;

import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.UserPageActivity;
import edu.xd.jiaoyou.view.custom.RecycleViewDivider;
import edu.xd.jiaoyou.view.custom.SideBar;

/**
 * Created by ZhengXi on 2017/6/19.
 */

public class FriendFragment extends Fragment {

    private DataService dataService = null;
    private UICallback uiCallback = null;

    private Context mContext;
    private View mView;
    private Button btnMine;
    private Button btnSearch;
    private RecyclerView mRecyclerView;
    private SideBar mSideBar;
    private TextView mTextView;
    private FriendAdapter mAdapter = null;
    private OnTitleClickListener onTitleClickListener = null;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;

        dataService = ((MainActivity) getActivity()).getDataService();
        uiCallback = new FriendFragment.UICallBack();
        mAdapter = new FriendAdapter();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_main_friends,container,false);

        btnMine = (Button) mView.findViewById(R.id.btn_main_mine);
        btnSearch = (Button) mView.findViewById(R.id.btn_main_search);

        mTextView = (TextView) mView.findViewById(R.id.side_text);

        mRecyclerView = (RecyclerView) mView.findViewById(R.id.rcyView_main_friends);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mRecyclerView.addItemDecoration(new RecycleViewDivider(mContext));
        mRecyclerView.setAdapter(mAdapter);

        mSideBar = (SideBar) mView.findViewById(R.id.sidebar_main_friends);
        mSideBar.setOnTouchingLetterChangedListener(new OnTouchingLetterChangedListener());
        mRecyclerView.addOnScrollListener(new OnScrollListener(mSideBar));

        //loadLocalCache();
        setOnclickEvent();
        return mView;
    }

    //toolbar点击事件
    public void setOnTitleClickListener(OnTitleClickListener onTitleClickListener) {
        this.onTitleClickListener = onTitleClickListener;
    }

    //设置view点击事件
    private void setOnclickEvent() {
        btnMine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onTitleClickListener!=null)
                    onTitleClickListener.onTitleClick(v,v.getId());
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onTitleClickListener!=null)
                    onTitleClickListener.onTitleClick(v,v.getId());
            }
        });

        mAdapter.setOnItemClickListener(new FriendAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                if (position==0) {
                    Intent intent = new Intent(mContext, FriendNotificationActivity.class);
                    startActivity(intent);
                }
                else {
                    Intent intent = new Intent(mContext, UserPageActivity.class);
                    intent.putExtra("userId",mAdapter.getUserId(position));
                    intent.putExtra("userName",mAdapter.getItemByPosition(position).name);
                    intent.putExtra("userProfile",mAdapter.getItemByPosition(position).profile);
                    startActivity(intent);
                }
            }
        });
    }

    //加载本地cache数据
    private void loadLocalCache() {
        mAdapter.add(Constant.AppData.friends);
    }

    //加载服务器返回的数据
    private void loadServiceData() {

    }

    //侧边栏点击动画
    private void setAnimator(final String text) {
        ObjectAnimator alpha = ObjectAnimator.ofFloat(mTextView,"alpha",1f,0f);
        alpha.setDuration(800);
        alpha.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                mTextView.setVisibility(View.VISIBLE);
                mTextView.setText(text);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                mTextView.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationCancel(Animator animation) {
                mTextView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                mTextView.setVisibility(View.VISIBLE);
                mTextView.setText(text);
            }
        });
        alpha.start();
    }

    //回调接口
    private class UICallBack implements UICallback {
        @Override
        public void dealServerRes(JSONObject msgIn) {}

        @Override
        public void dealServerPush(JSONObject msgIn) {}

        @Override
        public void dealServerMessage(JSONObject msgIn) {}

        public void localMsg(String msg){}
    }

    //recyclerView滑动监听
    private class OnScrollListener extends RecyclerView.OnScrollListener {
        private SideBar sideBar;
        private int firstVisibleItemPosition; //第一个可见item的位置

        public OnScrollListener(SideBar sideBar) {
            this.sideBar = sideBar;
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            RecyclerView.LayoutManager layoutManager = recyclerView
                    .getLayoutManager();
            if (layoutManager instanceof LinearLayoutManager) {
                firstVisibleItemPosition = ((LinearLayoutManager) layoutManager)
                        .findFirstVisibleItemPosition();
                onPosition(firstVisibleItemPosition);
            }
        }

        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            onPosition(firstVisibleItemPosition);
        }

        //根据屏幕上的item设置sidebar的选中状态
        public void onPosition(int firstCompleteVisiblePosition) {
            sideBar.setSelected(mAdapter.getItemType(firstCompleteVisiblePosition));
        }
    }

    private class OnTouchingLetterChangedListener implements SideBar.OnTouchingLetterChangedListener {
        @Override
        public void onTouchingLetterChanged(String s) {
            // the character first position
            int position = -1;
            try {
                //由于不确定点击的字符是否存在于可点击的字符集
                //使用try catch捕获异常
                position = (int) mAdapter.getChars().get(s);
            } catch (Exception e) {}
            if (position != -1) {
                // mRecyclerView.scrollToPosition(position);
                LinearLayoutManager layoutManager = (LinearLayoutManager) mRecyclerView
                        .getLayoutManager();
                //将指定的position滑动到距离上面第0个的位置，也就是顶部。
                layoutManager.scrollToPositionWithOffset(position, 0);
            }
            setAnimator(s);
        }
    }
}
