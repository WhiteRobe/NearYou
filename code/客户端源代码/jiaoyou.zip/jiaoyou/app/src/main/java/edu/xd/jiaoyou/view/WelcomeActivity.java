package edu.xd.jiaoyou.view;

import android.Manifest;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageButton;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import edu.xd.jiaoyou.BaseApplication;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.InfoValue;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.custom.CustomToast;
import edu.xd.jiaoyou.view.custom.SideBar;
import edu.xd.jiaoyou.view.main.MainActivity;

/**
 * Created by ZhengXi on 2017/5/14.
 */

public class WelcomeActivity extends AppCompatActivity {

    private static final String TAG = "WelcomeActivity";

    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;

    private UICallback uiCallback=new UICallback() {
        @Override
        public void dealServerRes(JSONObject msgIn) {

        }

        @Override
        public void dealServerPush(JSONObject msgIn) {
            String response = null;
            try {
                JSONObject data = msgIn.getJSONObject("Data");
                response = data.getString("Class");
                System.out.println("Welcome response:"+response);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if(response.equals(InfoValue.MsgPush.LoginSuccess)) {
                Intent intent = new Intent(WelcomeActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
            else {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        CustomToast.makeText(WelcomeActivity.this,"登录失败，请检查网络设置",
                                CustomToast.LENGTH_SHORT).show();
                    }
                });
            }
        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {

        }

        @Override
        public void localMsg(String msg) {
            if (msg.equals("DIAOXIAN"))
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        CustomToast.makeText(WelcomeActivity.this,"与服务器断开连接",
                                CustomToast.LENGTH_SHORT).show();
                    }
                });
        }
    };

    private ServiceConnection connection=new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
            dataService.setUICallback(uiCallback);
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };

    private Button btnRegister;
    private Button btnLogin;
    private ImageButton imgBtnQQ;
    private ImageButton imgBtnWeChat;
    private ImageButton imgBtnWeibo;

    private static float sTvSize = -1.0f;
    private static final float RATIO = 0.30769231f;

    private LoginBroadcastReceiver receiver = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        init();

        Intent bindIntent = new Intent(WelcomeActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        if(isNeedCheck){
            checkPermissions(needPermissions);
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(150);
                    BaseApplication application = (BaseApplication) getApplication();
                    if(application.hasAccount()) {
                        dataService.login(application.getAccount(),application.getPassword());
                    }
                } catch (Exception e) {
                }
            }
        }).start();


        receiver = new LoginBroadcastReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction("Intent.ACTION_LOGIN_RECEIVER");
        registerReceiver(receiver,filter);
    }

    @Override
    protected void onResume() {
        initTextSize();
        if(getRequestedOrientation()!= ActivityInfo.SCREEN_ORIENTATION_PORTRAIT){
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        super.onResume();
    }

    @Override
    public void onDestroy() {
        unbindService(connection);
        unregisterReceiver(receiver);
        super.onDestroy();
    }

    private void init() {
        btnRegister = (Button) findViewById(R.id.btn_welcome_register);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });

        btnLogin = (Button) findViewById(R.id.btn_welcome_login);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeActivity.this,LoginActivity.class);
                startActivity(intent);
                //Intent intent = new Intent(WelcomeActivity.this,MainActivity.class);
                //startActivity(intent);
            }
        });

        imgBtnQQ = (ImageButton) findViewById(R.id.imgBtn_welcome_qq);
        imgBtnQQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomToast.makeText(WelcomeActivity.this,"QQ",CustomToast.LENGTH_SHORT).show();
            }
        });

        imgBtnWeChat = (ImageButton) findViewById(R.id.imgBtn_welcome_wechat);
        imgBtnWeChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomToast.makeText(WelcomeActivity.this,"WeChat",CustomToast.LENGTH_SHORT).show();
            }
        });

        imgBtnWeibo = (ImageButton) findViewById(R.id.imgBtn_welcome_weibo);
        imgBtnWeibo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomToast.makeText(WelcomeActivity.this,"Weibo",CustomToast.LENGTH_SHORT).show();
            }
        });
    }

    private void initTextSize() {
        btnRegister.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                sTvSize = btnRegister.getHeight()*RATIO;
                btnRegister.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                if(sTvSize!=-1.0f) {
                    WelcomeActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            btnRegister.setTextSize(TypedValue.COMPLEX_UNIT_PX, sTvSize);
                            btnLogin.setTextSize(TypedValue.COMPLEX_UNIT_PX, sTvSize);
                            Log.v(TAG,"初始化字体完成");
                        }
                    });
                }
            }
        });
    }

    private class LoginBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context,Intent intent) {
            if(intent.getBooleanExtra("login_success",false)) {
                Log.v(TAG,"receiver");
                finish();
            }
        }
    }

    //-----------安卓6.0动态权限--------------//
    /**
     * 需要进行检测的权限数组
     */
    protected String[] needPermissions = {
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.READ_PHONE_STATE
    };

    private static final int PERMISSON_REQUESTCODE = 0;

    /**
     * 判断是否需要检测，防止不停的弹框
     */
    private boolean isNeedCheck = true;

    /**
     *
     * //@param needRequestPermissonList
     * @since 2.5.0
     *
     */
    private void checkPermissions(String... permissions) {
        List<String> needRequestPermissonList = findDeniedPermissions(permissions);
        if (null != needRequestPermissonList
                && needRequestPermissonList.size() > 0) {
            ActivityCompat.requestPermissions(this,
                    needRequestPermissonList.toArray(
                            new String[needRequestPermissonList.size()]),
                    PERMISSON_REQUESTCODE);
        }
    }

    /**
     * 获取权限集中需要申请权限的列表
     *
     * @param permissions
     * @return
     * @since 2.5.0
     *
     */
    private List<String> findDeniedPermissions(String[] permissions) {
        List<String> needRequestPermissonList = new ArrayList<String>();
        for (String perm : permissions) {
            if (ContextCompat.checkSelfPermission(this,
                    perm) != PackageManager.PERMISSION_GRANTED
                    || ActivityCompat.shouldShowRequestPermissionRationale(
                    this, perm)) {
                needRequestPermissonList.add(perm);
            }
        }
        return needRequestPermissonList;
    }

    /**
     * 检测是否说有的权限都已经授权
     * @param grantResults
     * @return
     * @since 2.5.0
     *
     */
    private boolean verifyPermissions(int[] grantResults) {
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] paramArrayOfInt) {
        if (requestCode == PERMISSON_REQUESTCODE) {
            if (!verifyPermissions(paramArrayOfInt)) {
                showMissingPermissionDialog();
                isNeedCheck = false;
            }
        }
    }

    /**
     * 显示提示信息
     *
     * @since 2.5.0
     *
     */
    private void showMissingPermissionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("顶顶顶");
        builder.setMessage("dasjdhahdj");

        // 拒绝, 退出应用
        builder.setNegativeButton("quxiao",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });

        builder.setPositiveButton("shezhi",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startAppSettings();
                    }
                });

        builder.setCancelable(false);

        builder.show();
    }

    /**
     *  启动应用的设置
     *
     * @since 2.5.0
     *
     */
    private void startAppSettings() {
        Intent intent = new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if(keyCode == KeyEvent.KEYCODE_BACK){
            this.finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

}
