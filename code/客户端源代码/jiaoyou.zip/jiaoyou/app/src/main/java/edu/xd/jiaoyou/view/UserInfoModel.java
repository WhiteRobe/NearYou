package edu.xd.jiaoyou.view;

import java.io.Serializable;

/**
 * Created by ZhengXi on 2017/6/19.
 */

public class UserInfoModel implements Serializable {
}
