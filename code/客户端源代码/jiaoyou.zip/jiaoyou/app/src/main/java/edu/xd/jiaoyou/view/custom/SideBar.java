package edu.xd.jiaoyou.view.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import edu.xd.jiaoyou.R;

/**
 * Created by ZhengXi on 2017/6/19.
 */

public class SideBar extends View {
    //触摸事件
    private OnTouchingLetterChangedListener listener = null;
    //字符集
    private String[] chars = { "A", "B", "C", "D", "E", "F", "G", "H", "I",
            "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
            "W", "X", "Y", "Z", "#" };
    //可点击的字符集
    private String[] enableClickChars;
    private int choose = -1;//选中的字符 in chars
    private Paint paint = new Paint();

    public SideBar(Context context) {
        super(context);
    }

    public SideBar(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SideBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    /**
     * 绘制View
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);    // 获取焦点改变背景颜色.
        int height = getHeight();// 获取对应高度
        int width = getWidth();  // 获取对应宽度
        int singleHeight = height / chars.length;// 获取每一个字母的高度

        for (int i = 0; i < chars.length; i++) {
            paint.setColor(Color.argb(138, 0, 0, 0));//R.color.alpha0.54Black
            paint.setTypeface(Typeface.SANS_SERIF);
            paint.setAntiAlias(true);
            paint.setTextSize(getResources().getDimension(R.dimen.x42));
            //选中的状态
            if (i == choose) {
                paint.setColor(Color.argb(222, 0, 0, 0));//R.color.alpha0.87Black
                paint.setFakeBoldText(true);
            }
            // x坐标等于中间-字符串宽度的一半.
            float xPos = width / 2 - paint.measureText(chars[i]) / 2;
            float yPos = singleHeight * i + singleHeight;
            canvas.drawText(chars[i], xPos, yPos, paint);
            paint.reset();// 重置画笔
        }
    }

    /**
     * 点击事件
     */
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        final int action = event.getAction();
        final float y = event.getY();// 点击y坐标
        final int oldChoose = choose;
        //点击y坐标所占总高度的比例*字符集长度就等于点击的字符
        final int c = (int) (y / getHeight() * chars.length);

        switch (action) {
            case MotionEvent.ACTION_UP:
                setBackgroundResource(R.color.transparent);
                choose = -1;
                invalidate();
                break;
            default:
                if (oldChoose != c) {
                    if (c >= 0 && c < chars.length) {
                        if (listener != null) {
                            listener.onTouchingLetterChanged(chars[c]);
                        }
                        choose = c;
                        invalidate();
                    }
                }
                break;
        }
        return true;
    }

    public void setOnTouchingLetterChangedListener(OnTouchingLetterChangedListener
                                                           onTouchingLetterChangedListener) {
        this.listener = onTouchingLetterChangedListener;
    }

    public void setUnableClickChars(String[] enableClickChars) {
        this.enableClickChars = enableClickChars;
    }

    public interface OnTouchingLetterChangedListener {
        void onTouchingLetterChanged(String c);
    }

    //根据selected的字符，设置位置
    public void setSelected(String nowChar) {
        choose = -1;
        if(nowChar == null || nowChar.equals("")) return;
        char c = nowChar.charAt(0);
        if(enableClickChars!=null) {
            //查找c是否可点击
            for(int i=0;i<enableClickChars.length;i++) {
                char enableChar = enableClickChars[i].charAt(0);
                if(c == enableChar) {
                    if (c == '#') choose = 26;
                    else choose = c-'A';
                }
            }
        }
        invalidate();
    }
}