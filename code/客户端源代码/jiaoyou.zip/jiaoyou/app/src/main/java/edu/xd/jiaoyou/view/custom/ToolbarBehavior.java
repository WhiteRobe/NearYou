package edu.xd.jiaoyou.view.custom;

import android.content.Context;
import android.graphics.Color;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import edu.xd.jiaoyou.R;

/**
 * Created by ZhengXi on 2017/5/31.
 */

public class ToolbarBehavior extends CoordinatorLayout.Behavior {

    private static final String TAG = "ToolbarBehavior";

    private Button btnBack;
    private TextView tvName;

    private int appbarHeight  = 0;
    private int toolbarHeight = 0;
    private float front = 0f;

    public ToolbarBehavior(Context context, AttributeSet attrs) {
        super(context,attrs);
    }

    @Override
    public boolean layoutDependsOn(CoordinatorLayout parent, View child, View dependency) {
        btnBack = (Button) child.findViewById(R.id.btn_homepage_back);
        tvName = (TextView) child.findViewById(R.id.title_homepage_name);
        appbarHeight  = dependency.getHeight();
        toolbarHeight = child.getHeight();
        return dependency instanceof AppBarLayout;
    }

    @Override
    public boolean onDependentViewChanged(CoordinatorLayout parent, View child, View dependency) {
        float scale = Math.abs(dependency.getY()/(appbarHeight-toolbarHeight));

        if(scale<0.6) {
            if(canChange(scale)) {
                child.setBackgroundColor(Color.TRANSPARENT);
                btnBack.setBackground(btnBack.getContext().getDrawable(R.drawable.homepage_back));
                btnBack.setAlpha(1.0f);
                dependency.setAlpha(1.0f);
                Log.v(TAG,"0.0--0.6");
                tvName.setTextColor(Color.TRANSPARENT);
            }
        }

        if(scale>=0.6&&scale<1) {
            int background = Color.argb((int)((scale-0.6)*255*2.5),255,255,255);
            child.setBackgroundColor(background);
            if(canChange(scale)) {
                Log.v(TAG,"0.6--1.0");
                btnBack.setBackground(btnBack.getContext().getDrawable(R.drawable.setting_back));
            }
            btnBack.setAlpha((scale-0.6f)*2.5f);
            tvName.setTextColor(Color.argb((int)((scale-0.6)*255*2.5),0,0,0));
            dependency.setAlpha(1-(scale-0.6f)*2.5f);
        }

        if(scale>=1) {
            if (canChange(scale)) {
                Log.v(TAG,"1.0--");
                child.setBackgroundColor(Color.WHITE);
                btnBack.setBackground(btnBack.getContext().getDrawable(R.drawable.setting_back));
                tvName.setTextColor(Color.BLACK);
            }
        }
        return true;
    }

    private boolean canChange(float now) {
        if(front<0.6) {
            front = now;
            if(now>=0.6) return true;
            return false;
        }
        else if(front<1.0) {
            front = now;
            if(now>=1.0||now<0.6) return true;
            return false;
        }
        else if(front>=1.0) {
            front = now;
            if(now<1.0) return true;
            return false;
        }
        return false;
    }

}
