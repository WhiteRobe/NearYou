package edu.xd.jiaoyou.view;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Bundle;
import android.os.IBinder;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.StringToInteger;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.InfoValue;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.custom.CircleImageView;
import edu.xd.jiaoyou.view.custom.RecycleViewDivider;
import edu.xd.jiaoyou.view.main.MomentAdapter;
import edu.xd.jiaoyou.view.main.MomentModel;

/**
 * Created by ZhengXi on 2017/5/31.
 */

public class HomepageActivity extends BaseActivity {

    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };
    private UICallback uiCallback = new UICallback() {
        //资料
        String name,profile,location,school;
        //动态
        int id,userId,pictures,likes,comments,width,height;;
        String content,time,date,place,pictureName;
        boolean isLike;
        List<String> images = new ArrayList<>();
        @Override
        public void dealServerRes(JSONObject msgIn) {
            try {
                JSONObject data = msgIn.getJSONObject("Data");
                System.out.println("MsgIn:"+data);
                //info类型
                if (data.getString("Class").equals(InfoValue.MsgReq.SearchFriendById)) {
                    JSONObject value = data.getJSONObject("Value");
                    System.out.println("UserInfo:"+value);
                    name = value.getString("NickName");
                    profile = Constant.SERVICE_IP+"/avatar/"+value.getString("Id")+"_avatar";
                    location = value.getString("Address");
                    school = value.getString("School");
                    //更新ui
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            tvName.setText(name);
                            tvTitle.setText(name);
                            tvSchool.setText(school);

                            Glide.with(HomepageActivity.this)
                                    .load(profile)
                                    .asBitmap()
                                    .into(cvProfile);
                        }
                    });
                }
                //moment类型
                if (data.getString("Class").equals(InfoValue.MsgRes.MomentResponse)) {
                    JSONObject value = data.getJSONObject("Value");
                    System.out.println("Moments:" + data);
                    id = StringToInteger.StringToInteger(value.getString("MomentsNo"));
                    userId = StringToInteger.StringToInteger(value.getString("Id"));
                    name = value.getString("NickName");
                    profile = Constant.SERVICE_IP + "/avatar/" + "123" + "_avatar";
                    ;
                    pictures = value.getInt("PicNum");
                    likes = value.getInt("Liked");
                    comments = value.getInt("Comments");
                    pictureName = value.getString("Pic");
                    content = value.getString("Text");
                    time = value.getString("Time");
                    date = value.getString("Date");
                    place = value.getString("Location");
                    isLike = value.getInt("IsLike") == 0 ? false : true;

                    images.clear();
                    StringBuffer buffer = new StringBuffer(pictureName);
                    if (pictures == 0) {
                        width = 0;
                        height = 0;
                    } else if (pictures == 1) {
                        width = 996;
                        height = 996;
                        images.add(Constant.SERVICE_IP + "/momentpic/" + pictureName);
                        System.out.println("ImagePath:" + pictureName);
                    } else if (pictures > 1) {
                        width = 0;
                        height = 0;
                        for (int i = 0; i < pictures; i++) {
                            String path = buffer.replace(0, 1, String.valueOf(i + 1)).toString();
                            System.out.println("ImagePath:" + path);
                            images.add(Constant.SERVICE_IP + "/momentpic/" +
                                    buffer.replace(0, 1, String.valueOf(i + 1)).toString());
                        }
                    }
                    //更新UI
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mAdapter.insert(0, new MomentModel(id, userId, name, profile, content, pictures, width, height
                                    , time, place, likes, comments, isLike, images));
                        }
                    });
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void dealServerPush(JSONObject msgIn) {

        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {}

        @Override
        public void localMsg(String msg) {}
    };

    private AppBarLayout mAppBar;
    private Toolbar mToolbar;
    private Button btnBack;
    private TextView tvTitle;
    private CircleImageView cvProfile;
    private TextView tvName;

    private TextView tvLocation;
    private TextView tvSchool;
    private RecyclerView rcyMoments;
    private MomentAdapter mAdapter;

    private int userId = -1;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        Intent bindIntent = new Intent(HomepageActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        Intent intent = getIntent();
        userId = intent.getIntExtra("userId",-1);
        System.out.println("Homepage userId:"+userId);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (dataService==null) {}
                dataService.setUICallback(uiCallback);
                //获取个人信息
                dataService.searchFriendsByid(String.valueOf(userId));
                //获取个人动态
                dataService.getMomentsByid(String.valueOf(userId));
            }
        }).start();

        init();
        loadServiceData();
    }

    @Override
    public void onDestroy() {
        unbindService(connection);
        super.onDestroy();
    }

    private void init() {
        mAdapter = new MomentAdapter();

        int statusHeight = getStatusHeight();
        //动态设置AppBarLayout高度，使其达到状态栏半透明的效果
        mAppBar = (AppBarLayout) findViewById(R.id.appbar_homepage);
        final CoordinatorLayout.LayoutParams params = new
                CoordinatorLayout.LayoutParams(mAppBar.getLayoutParams());
        params.height = statusHeight+(int)getResources().getDimension(R.dimen.y480)+1;
        mAppBar.setLayoutParams(params);
        mToolbar = (Toolbar) findViewById(R.id.toolbar_homepage);
        setSupportActionBar(mToolbar);

        tvTitle = (TextView) findViewById(R.id.title_homepage_name);
        btnBack = (Button) findViewById(R.id.btn_homepage_back);
        cvProfile = (CircleImageView) findViewById(R.id.img_homepage_profile);
        tvName = (TextView) findViewById(R.id.textView_homepage_name);

        tvLocation = (TextView) findViewById(R.id.textView_homepage_location);
        tvSchool = (TextView) findViewById(R.id.textView_homepage_school);
        //初始化RecycleView
        rcyMoments = (RecyclerView) findViewById(R.id.rcyView_homepage_moments);
        LinearLayoutManager manager = new LinearLayoutManager(HomepageActivity.this);
        rcyMoments.setLayoutManager(manager);
        int dividerHeight = (int) getResources().getDimension(R.dimen.y24);
        int dividerColor = Color.rgb(242,242,242);//R.color.colorBaseBackground
        rcyMoments.addItemDecoration(new RecycleViewDivider(HomepageActivity.this,
                LinearLayoutManager.HORIZONTAL,dividerHeight,dividerColor));
        rcyMoments.setAdapter(mAdapter);

        setOnClickEvent();
    }

    //此页面没有加载本地数据的方法
    private void loadServiceData() {
        /*final Timer timer = new Timer();
        TimerTask checkServiceTask = new TimerTask() {
            @Override
            public void run() {
                if (dataService!=null) {
                    dataService.setUICallback(uiCallback);
                    dataService.getMomentsByid(String.valueOf(userId));
                    timer.cancel();
                }
            }
        };
        timer.schedule(checkServiceTask,0,200);
        */
    }

    private void setOnClickEvent() {
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        mAdapter.setOnItemClickListener(new MomentAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

            }
        });

        mAdapter.setOnImageClickListener(new MomentAdapter.OnImageClickListener() {
            @Override
            public void onImageClick(View view, int index, int position) {

            }
        });

        mAdapter.setOnButtonClickListener(new MomentAdapter.OnButtonClickListener() {
            @Override
            public void onButtonClick(View view, String tag, int position) {

            }
        });
    }

}
