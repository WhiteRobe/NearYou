package edu.xd.jiaoyou.view.main;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.Bundle;
import android.os.IBinder;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.bumptech.glide.Glide;;

import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.StringToInteger;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.view.SettingActivity;
import edu.xd.jiaoyou.view.addfirends.AddFriendsActivity;
import edu.xd.jiaoyou.view.BaseActivity;
import edu.xd.jiaoyou.view.HomepageActivity;
import edu.xd.jiaoyou.view.UserInfoActivity;
import edu.xd.jiaoyou.view.custom.CircleImageView;

/**
 * Created by ZhengXi on 2017/5/18.
 */

public class MainActivity extends BaseActivity implements View.OnClickListener,OnTitleClickListener {

    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;

    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };

    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
    private CircleImageView cvProfile;
    private TextView tvName;
    private Button btnHomepage;
    private Button btnInfo;
    private Button btnSetting;

    private ImageButton imgBtnMoments;
    private ImageButton imgBtnMessages;
    private ImageButton imgBtnFriends;
    private TextView tvMoments;
    private TextView tvMessages;
    private TextView tvFriends;

    private MomentFragment momFragment = null;
    private MessageFragment msgFragment = null;
    private FriendFragment friFragment = null;
    private FragmentManager fManager = null;

    private int sDefaultColor = 0;
    private int sSelectedColor = 0;
    private int lastPage = 0;//记录上一次的主页面

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fManager = getSupportFragmentManager();

        Intent bindIntent = new Intent(MainActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        Intent intent = new Intent("Intent.ACTION_LOGIN_RECEIVER");
        intent.putExtra("login_success",true);
        sendBroadcast(intent);

        init();
    }

    @Override
    public void onResume() {
        //更新信息界面
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (dataService==null) {}
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        String name = dataService.getNickName();
                        if (name==null || name.equals("  ")) name = "匿名";
                        tvName.setText(name);
                        Glide.with(MainActivity.this)
                                .load(Constant.SERVICE_IP+"/avatar/"+dataService.getUserID()+"_avatar")
                                .asBitmap()
                                .error(R.color.dark_gray)
                                .into(cvProfile);
                    }
                });
            }
        }).start();
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        unbindService(connection);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_main_homepage:
                Intent intent1 = new Intent(MainActivity.this, HomepageActivity.class);
                intent1.putExtra("userId", StringToInteger.StringToInteger(dataService.getUserID()));
                startActivity(intent1);
                break;
            case R.id.btn_main_info:
                Intent intent2 = new Intent(MainActivity.this, UserInfoActivity.class);
                intent2.putExtra("userId",StringToInteger.StringToInteger(dataService.getUserID()));
                startActivity(intent2);
                break;
            case R.id.btn_main_setting:
                Intent intent3 = new Intent(MainActivity.this, SettingActivity.class);
                startActivity(intent3);
                finish();
                break;
            case R.id.imgBtn_main_moments:
                if(lastPage == 0 && momFragment!=null) momFragment.autoRefresh();
                lastPage = 0;
                setCurrentPage(0);
                break;
            case R.id.imgBtn_main_messages:
                if(lastPage == 1 && msgFragment!=null) msgFragment.autoRefresh();
                lastPage = 1;
                setCurrentPage(1);
                break;
            case R.id.imgBtn_main_friends:
                lastPage = 2;
                setCurrentPage(2);
                break;
        }
    }

    @Override
    public void onTitleClick(View v,int id) {
        switch (id) {
            case R.id.btn_main_mine:
                mDrawerLayout.openDrawer(mNavigationView);
                break;
            case R.id.btn_main_search:
                Intent intent = new Intent(MainActivity.this, AddFriendsActivity.class);
                startActivity(intent);
                break;
        }
    }

    public DataService getDataService() {
        return dataService;
    }

    public boolean isConnected() {
        return dataService!=null;
    }

    private void init() {
        sDefaultColor = Color.BLACK;
        sSelectedColor = ContextCompat.getColor(MainActivity.this,R.color.colorTabSelected);

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        mNavigationView = (NavigationView) findViewById(R.id.navigation);
        View container = mNavigationView.inflateHeaderView(R.layout.headview_main_navigation);
        cvProfile = (CircleImageView) container.findViewById(R.id.img_main_profilePhoto);
        tvName = (TextView) container.findViewById(R.id.textView_main_name);

        btnHomepage = (Button) container.findViewById(R.id.btn_main_homepage);
        btnHomepage.setOnClickListener(this);
        btnInfo = (Button) container.findViewById(R.id.btn_main_info);
        btnInfo.setOnClickListener(this);
        btnSetting = (Button) container.findViewById(R.id.btn_main_setting);
        btnSetting.setOnClickListener(this);

        imgBtnMoments = (ImageButton) findViewById(R.id.imgBtn_main_moments);
        imgBtnMoments.setOnClickListener(this);
        imgBtnMessages = (ImageButton) findViewById(R.id.imgBtn_main_messages);
        imgBtnMessages.setOnClickListener(this);
        imgBtnFriends = (ImageButton) findViewById(R.id.imgBtn_main_friends);
        imgBtnFriends.setOnClickListener(this);
        tvMoments = (TextView) findViewById(R.id.textView_main_moments);
        tvMessages = (TextView) findViewById(R.id.textView_main_messages);
        tvFriends = (TextView) findViewById(R.id.textView_main_friends);

       setCurrentPage(0);
    }

    //设置显示页面
    private void setCurrentPage(int pageTag) {
        FragmentTransaction fTransaction = fManager.beginTransaction();
        hideAllFragment(fTransaction);
        switch (pageTag) {
            case 0:
                imgBtnMoments.setImageDrawable(getDrawable(R.drawable.moments_clicked));
                imgBtnMessages.setImageDrawable(getDrawable(R.drawable.messages));
                imgBtnFriends.setImageDrawable(getDrawable(R.drawable.friends));
                tvMoments.setTextColor(sSelectedColor);
                tvMessages.setTextColor(sDefaultColor);
                tvFriends.setTextColor(sDefaultColor);

                if(momFragment==null) {
                    momFragment = new MomentFragment();
                    momFragment.setOnTitleClickListener(this);
                    fTransaction.add(R.id.content,momFragment);
                    fTransaction.show(momFragment);
                }
                else fTransaction.show(momFragment);


                break;
            case 1:
                imgBtnMoments.setImageDrawable(getDrawable(R.drawable.moments));
                imgBtnMessages.setImageDrawable(getDrawable(R.drawable.messages_clicked));
                imgBtnFriends.setImageDrawable(getDrawable(R.drawable.friends));
                tvMoments.setTextColor(sDefaultColor);
                tvMessages.setTextColor(sSelectedColor);
                tvFriends.setTextColor(sDefaultColor);

                if(msgFragment==null) {
                    msgFragment = new MessageFragment();
                    msgFragment.setOnTitleClickListener(this);
                    fTransaction.add(R.id.content,msgFragment);
                    fTransaction.show(msgFragment);
                }
                else fTransaction.show(msgFragment);

                break;
            case 2:
                imgBtnMoments.setImageDrawable(getDrawable(R.drawable.moments));
                imgBtnMessages.setImageDrawable(getDrawable(R.drawable.messages));
                imgBtnFriends.setImageDrawable(getDrawable(R.drawable.friends_clicked));
                tvMoments.setTextColor(sDefaultColor);
                tvMessages.setTextColor(sDefaultColor);
                tvFriends.setTextColor(sSelectedColor);

                if(friFragment==null) {
                    friFragment = new FriendFragment();
                    friFragment.setOnTitleClickListener(this);
                    fTransaction.add(R.id.content,friFragment);
                    fTransaction.show(friFragment);
                }
                else fTransaction.show(friFragment);

                break;
            default:
                break;
        }
        fTransaction.commit();
        lastPage = pageTag;
    }

    //获取当前显示页面
    private int getCurrentPage() {
        if (lastPage == 0)
            return momFragment.getCurrentPage();
        else if(lastPage == 1)
            return msgFragment.getCurrentPage();
        return Constant.ViewTag.FRIENDS_TAG;
    }

    //隐藏所有的fragment
    private void hideAllFragment(FragmentTransaction transaction) {
        if(momFragment!=null) {
            transaction.hide(momFragment);
        }
        if(msgFragment!=null) {
            transaction.hide(msgFragment);
        }
        if(friFragment!=null) {
            transaction.hide(friFragment);
        }
    }

}