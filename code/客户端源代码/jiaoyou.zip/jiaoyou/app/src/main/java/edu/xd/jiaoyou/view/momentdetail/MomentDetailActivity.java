package edu.xd.jiaoyou.view.momentdetail;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.List;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.custom.RecycleViewDivider;
import edu.xd.jiaoyou.view.main.MomentModel;

/**
 * Created by ZhengXi on 2017/6/3.
 */

public class MomentDetailActivity extends AppCompatActivity {


    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };
    private UICallback uiCallback = new UICallback() {
        @Override
        public void dealServerRes(JSONObject msgIn) {

        }

        @Override
        public void dealServerPush(JSONObject msgIn) {

        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {

        }
        @Override
        public void localMsg(String msg) {

        }
    };

    private Button btnBack;
    private TextView tvTitle;
    private RecyclerView rcyComments;
    private CommentAdapter mAdapter;

    private List<CommentModel> data = null;
    private MomentModel momentModel = null;
    private int momentId = -1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_momentdetail);

        Intent bindIntent = new Intent(MomentDetailActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        Intent intent = getIntent();
        momentId = intent.getIntExtra("momentId",-1);

        init();
        loadServiceData();
    }

    @Override
    public void onDestroy() {
        unbindService(connection);
        super.onDestroy();
    }

    private void init() {
        btnBack = (Button) findViewById(R.id.btn_back);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        tvTitle = (TextView) findViewById(R.id.textView_title);
        tvTitle.setText("动态详情");
        rcyComments = (RecyclerView) findViewById(R.id.rcyView_detail_comments);
        LinearLayoutManager manager = new LinearLayoutManager(MomentDetailActivity.this);
        rcyComments.addItemDecoration(new RecycleViewDivider(MomentDetailActivity.this));
        rcyComments.setLayoutManager(manager);
        mAdapter = new CommentAdapter(data);
        rcyComments.setAdapter(mAdapter);
    }

    //获取服务器信息
    private void loadServiceData() {
        //List<>
    }
}
