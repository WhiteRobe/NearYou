package edu.xd.jiaoyou.view;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.Fragment;

import java.util.List;

/**
 * Created by ZhengXi on 2017/6/12.
 */

public class CommonFragmentPagerAdapter extends FragmentPagerAdapter {

    private List<Fragment> fragments;

    public CommonFragmentPagerAdapter(FragmentManager manager, List<Fragment> fragments) {
        super(manager);
        this.fragments = fragments;
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }
}
