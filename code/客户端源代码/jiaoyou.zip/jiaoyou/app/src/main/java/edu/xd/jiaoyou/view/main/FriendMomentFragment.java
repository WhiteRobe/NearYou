package edu.xd.jiaoyou.view.main;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.json.JSONObject;

import java.io.Serializable;

import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.custom.CustomToast;
import edu.xd.jiaoyou.view.custom.RecycleViewDivider;
import edu.xd.jiaoyou.view.momentdetail.MomentDetailActivity;
import edu.xd.jiaoyou.view.photoviewer.PhotoViewerActivity;
import in.srain.cube.views.ptr.PtrClassicDefaultHeader;
import in.srain.cube.views.ptr.PtrDefaultHandler;
import in.srain.cube.views.ptr.PtrFrameLayout;

/**
 * Created by ZhengXi on 2017/6/19.
 */

public class FriendMomentFragment extends Fragment {

    private DataService dataService = null;
    private UICallback uiCallback = null;

    private Context mContext;
    private View mView;
    private PtrFrameLayout mPtrFrameLayout;
    private RecyclerView mRecyclerView;
    private MomentAdapter mAdapter;

    //recyclerView分割线
    private int dividerHeight;
    private int dividerColor;

    //绑定到activity
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;
        //获得绑定的服务
        dataService = ((MainActivity) getActivity()).getDataService();
        uiCallback = new FriendMomentFragment.UICallBack();
        //初始化分割线参数
        dividerHeight = (int) mContext.getResources().getDimension(R.dimen.y24);
        dividerColor = Color.rgb(242,242,242);
        //初始化mAdapter
        mAdapter = new MomentAdapter();
        setOnClickEvent();
    }

    //绘制fragment
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.pager_moment_friend,container,false);

        mPtrFrameLayout = (PtrFrameLayout) mView.findViewById(R.id.ptrLayout);
        PtrClassicDefaultHeader header = new PtrClassicDefaultHeader(mContext);
        mPtrFrameLayout.setHeaderView(header);
        mPtrFrameLayout.addPtrUIHandler(header);
        mPtrFrameLayout.setPtrHandler(new PtrDefaultHandler() {
            //刷新事件
            @Override
            public void onRefreshBegin(PtrFrameLayout frame) {
                dataService.setUICallback(uiCallback);
                //dataService.getMomentsNearby();
            }
        });

        mRecyclerView = (RecyclerView) mView.findViewById(R.id.rcyView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mRecyclerView.addItemDecoration(new RecycleViewDivider(mContext,LinearLayoutManager.HORIZONTAL,
                dividerHeight,dividerColor));
        mRecyclerView.addOnScrollListener(new FriendMomentFragment.OnScrollListener());
        mRecyclerView.setAdapter(mAdapter);

        //loadLocalCache();
        return mView;
    }

    //自动刷新
    public void autoRefresh() {
        mPtrFrameLayout.postDelayed(new Runnable() {
            @Override
            public void run() {
                mPtrFrameLayout.autoRefresh();
            }
        },100);
    }

    //停止刷新
    public void stopRefresh() {
        mPtrFrameLayout.post(new Runnable() {
            @Override
            public void run() {
                mPtrFrameLayout.refreshComplete();
            }
        });
    }

    //加载本地cache数据
    private void loadLocalCache() {
        mAdapter.add(Constant.AppData.friendMoments);
    }

    //加载服务器返回的数据
    private void loadServiceData() {

    }

    //设置点击事件
    private void setOnClickEvent() {
        //点击Item事件
        mAdapter.setOnItemClickListener(new MomentAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent intent = new Intent(view.getContext(), MomentDetailActivity.class);
                intent.putExtra("momentID",mAdapter.getMomentId(position));
                mContext.startActivity(intent);
            }
        });
        //点击点赞，评论事件
        mAdapter.setOnButtonClickListener(new MomentAdapter.OnButtonClickListener() {
            @Override
            public void onButtonClick(View view, String viewTag, int position) {
                CustomToast.makeText(mContext,viewTag+" "+position,
                        CustomToast.LENGTH_SHORT).show();
            }
        });
        //点击图片事件
        mAdapter.setOnImageClickListener(new MomentAdapter.OnImageClickListener() {
            @Override
            public void onImageClick(View view, int imageId, int position) {
                Intent intent = new Intent(mContext, PhotoViewerActivity.class);
                intent.putExtra("current_item",imageId);
                intent.putExtra("image_list",(Serializable) mAdapter.getMomentImages(position));
                startActivity(intent);
            }
        });
    }

    //recyclerView滑动监听
    private static class OnScrollListener extends RecyclerView.OnScrollListener {
        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
            //判断是当前layoutManager是否为LinearLayoutManager(默认)
            //只有LinearLayoutManager才有查找第一个和最后一个可见view位置的方法
            if (layoutManager instanceof LinearLayoutManager) {
                LinearLayoutManager linearManager = (LinearLayoutManager) layoutManager;
                //获取最后一个可见view的位置
                int lastItemPosition = linearManager.findLastVisibleItemPosition();
                //获取第一个可见view的位置
                int firstItemPosition = linearManager.findFirstVisibleItemPosition();
                //System.out.println(lastItemPosition + "   " + firstItemPosition);
            }
        }

        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }
    }

    //回调接口
    private static class UICallBack implements UICallback {
        @Override
        public void dealServerRes(JSONObject msgIn) {}

        @Override
        public void dealServerPush(JSONObject msgIn) {}

        @Override
        public void dealServerMessage(JSONObject msgIn) {}

        @Override
        public void localMsg(String msg) {}
    }

}
