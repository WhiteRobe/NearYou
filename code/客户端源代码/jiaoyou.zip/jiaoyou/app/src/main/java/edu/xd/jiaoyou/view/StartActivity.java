package edu.xd.jiaoyou.view;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import edu.xd.jiaoyou.BaseApplication;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.InfoValue;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.custom.CustomToast;
import edu.xd.jiaoyou.view.main.MainActivity;

/**
 * Created by ZhengXi on 2017/6/22.
 */

public class StartActivity extends AppCompatActivity {
    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;
    private UICallback uiCallback=new UICallback() {
        @Override
        public void dealServerRes(JSONObject msgIn) {}

        @Override
        public void dealServerPush(JSONObject msgIn) {
            System.out.println(msgIn);
            String response = null;
            try {
                JSONObject data = msgIn.getJSONObject("Data");
                response = data.getString("Class");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if(response.equals(InfoValue.MsgPush.LoginSuccess)) {
                System.out.println("LoginSuccess");
                loginSuccess = true;
            }
        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {}

        @Override
        public void localMsg(String msg) {}
    };
    private ServiceConnection connection=new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
            dataService.setUICallback(uiCallback);
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };

    private TextView textView;
    private int time = 2;
    private boolean loginSuccess = false;
    private Timer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        textView = (TextView) findViewById(R.id.start_text);

        Intent bindIntent = new Intent(StartActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (dataService==null) {}
                dataService.setUICallback(uiCallback);
                BaseApplication application = (BaseApplication) getApplication();
                if(application.hasAccount()) {
                    int i = 0;
                    //sleep 一秒判断高德地图是否可用
                    while (!dataService.isGaodeSDKAvaliable()) {
                        try {
                            if (i==1) break;
                            Thread.sleep(1000);
                            i++;
                        } catch (Exception e) {}
                    }
                    dataService.login(application.getAccount(),application.getPassword());
                }
                else {
                    try {
                        Thread.sleep(1000);
                        Intent intent = new Intent(StartActivity.this,LoginOrRegisterActivity.class);
                        startActivity(intent);
                        finish();
                        timer.cancel();
                    } catch (Exception e) {}
                }
            }
        }).start();

        timer = new Timer();
        TimerTask taskMain = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textView.setText(String.valueOf(time));
                        if (time==1 && loginSuccess) {
                            timer.cancel();
                            Intent intent = new Intent(StartActivity.this,MainActivity.class);
                            startActivity(intent);
                            finish();
                        }
                        if (time == 0) {
                            timer.cancel();
                            Intent intent = new Intent(StartActivity.this,MainActivity.class);
                            startActivity(intent);
                            CustomToast.makeText(StartActivity.this,"未连接到服务器",
                                    CustomToast.LENGTH_SHORT).show();
                            finish();
                        }
                        time--;
                    }
                });
            }
        };
        timer.schedule(taskMain,0,1000);
    }

    @Override
    public void onDestroy() {
        unbindService(connection);
        super.onDestroy();
    }

}
