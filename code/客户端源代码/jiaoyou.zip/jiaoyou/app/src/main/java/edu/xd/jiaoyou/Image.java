package edu.xd.jiaoyou;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Movie;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by ZhengXi on 2017/6/13.
 */

/**
 * Image封装类
 */
public class Image {

    public int width;  //图片宽度
    public int height; //图片高度

    /**
     * 图片类型
     * {@link edu.xd.jiaoyou.Constant}
     */
    public int type;

    private Bitmap bitmap;
    private InputStream inputStream;
    private Movie player;

    public Image(Bitmap bm) {
        bitmap = bm;
        width = bitmap.getWidth();
        height = bitmap.getHeight();
        type = Constant.ImageType.COMMON;
    }

    public Image(InputStream is) {
        inputStream = is;
        player = Movie.decodeStream(inputStream);
        if(player!=null) {
            this.type = Constant.ImageType.GIF;
            width = player.width();
            height = player.height();
        }
        else {
            this.type = Constant.ImageType.COMMON;
            bitmap = BitmapFactory.decodeStream(inputStream);
            width = bitmap.getWidth();
            height = bitmap.getHeight();
        }
    }

    public Bitmap toBitmap() {
        return bitmap;
    }

    public InputStream toInputStream() {
        return inputStream;
    }

    public Movie toPlayer() {
        return player;
    }

    /**
     * 释放内存
     */
    public void recycle() {
        if(player!=null)
            player=null;

        if(bitmap!=null) {
            bitmap.recycle();
            bitmap = null;
        }

        if(inputStream!=null)
            try {
                inputStream.close();
                inputStream = null;
            } catch (IOException e) {
                e.printStackTrace();
            }
    }

}
