package edu.xd.jiaoyou.data;

import org.json.JSONObject;

/**
 * Created by a on 2017/4/25.
 */

public interface UICallback {
    public void dealServerRes(JSONObject msgIn);
    public void dealServerPush(JSONObject msgIn);
    public void dealServerMessage(JSONObject msgIn);
    public void localMsg(String msg);
}
