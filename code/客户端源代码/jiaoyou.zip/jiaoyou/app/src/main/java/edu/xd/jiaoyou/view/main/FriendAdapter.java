package edu.xd.jiaoyou.view.main;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.view.custom.CircleImageView;

/**
 * Created by ZhengXi on 2017/5/28.
 */

public class FriendAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int ITEM_TYPE_CONTENT = 0x0001; //内容
    public static final int ITEM_TYPE_HEADER  = 0x0002; //头部

    private List<FriendModel> mData = null;
    private View convertView = null;
    private RecyclerView.ViewHolder mHolder = null;
    private String lastType = "";
    private HashMap<String,Integer> chars = null; //联系人首字母的字符集,及其首位置
    private boolean hasHeaderView = true;         //是否含有hasHeaderView，默认有

    private OnItemClickListener onItemClickListener = null;

    public FriendAdapter() {
        mData = new ArrayList<>();
        chars = new HashMap<>();
    }
    
    public void setHeaderView(boolean hasHeaderView) {
        this.hasHeaderView = hasHeaderView;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == ITEM_TYPE_HEADER) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(
                    R.layout.headview_main_friend,parent,false);
            mHolder = new HeaderViewHolder(convertView);
        }
        else if(viewType == ITEM_TYPE_CONTENT) {
            convertView = LayoutInflater.from(parent.getContext()).inflate
                    (R.layout.item_main_friends,parent,false);
            mHolder = new ContentViewHolder(convertView);
        }
        return mHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof HeaderViewHolder) {
            ((HeaderViewHolder) holder).btnNewFriends.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(onItemClickListener!=null)
                        onItemClickListener.onItemClick(v,position);
                }
            });
        }
        else if(holder instanceof ContentViewHolder) {
            FriendModel item;
            //由于hasHeaderView的存在，position比mData.ize大1
            if(hasHeaderView) item = mData.get(position-1);
            else item = mData.get(position);
            
            if(item.type==null||item.type.equals(lastType))
                ((ContentViewHolder) holder).tvType.setVisibility(View.GONE);
            else {
                chars.put(item.type,position);
                ((ContentViewHolder) holder).tvType.setText(item.type);
            }
            ((ContentViewHolder) holder).tvName.setText(item.name);
            if(item.hasProfile())
                Glide.with( ((ContentViewHolder) holder).context)
                        .load(item.profile)
                        .asBitmap()
                        .into( ((ContentViewHolder) holder).cvProfile);
            else  ((ContentViewHolder) holder).cvProfile.setImageDrawable(
                    ((ContentViewHolder) holder).context.getDrawable(R.drawable.profile));
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(onItemClickListener!=null)
                        onItemClickListener.onItemClick(v,position);
                }
            });
            lastType = item.type;
        }
    }

    @Override
    public int getItemCount() {
        if (hasHeaderView) {
            return mData.size() + 1;
        }
        else return mData.size();
    }

    @Override
    public int getItemViewType(int position) {
        if(hasHeaderView) {
            if (position == 0) return ITEM_TYPE_HEADER;
            else return ITEM_TYPE_CONTENT;
        }
        else return ITEM_TYPE_CONTENT;
    }

    //返回联系人首字母字符集
    public HashMap getChars() {
        return chars;
    }

    //根据位置返回该位置的字符
    public String getItemType(int position) {
        //第一项为headView
        if(position > 0) {
            return mData.get(position-1).type;
        }
        return null;
    }

    //返回指定位置的源数据
    public FriendModel getItemByPosition(int position) {
        return mData.get(position-1);
    }

    //根据位置返回userId
    public int getUserId(int position) {
        if(position > 0)
            return mData.get(position-1).userId;
        return -1;
    }

    public void add(FriendModel data) {
        mData.add(data);
        this.notifyDataSetChanged();
    }

    public void add(List<FriendModel> data) {
        mData.addAll(data);
        this.notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(View view,int position);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    private static class ContentViewHolder extends RecyclerView.ViewHolder {
        public Context context = null;
        public CircleImageView cvProfile = null;
        public TextView tvName = null;
        public TextView tvType = null;

        public ContentViewHolder(View itemView) {
            super(itemView);
            context = itemView.getContext();
            cvProfile = (CircleImageView) itemView.findViewById(R.id.img_friends_profile);
            tvName = (TextView) itemView.findViewById(R.id.textView_friends_name);
            tvType = (TextView) itemView.findViewById(R.id.textView_friends_type);
        }
    }

    private static class HeaderViewHolder extends RecyclerView.ViewHolder {
        public Button btnNewFriends = null;

        public HeaderViewHolder(View itemView) {
            super(itemView);
            btnNewFriends = (Button) itemView.findViewById(R.id.btn_main_addfriends);
        }
    }
}
