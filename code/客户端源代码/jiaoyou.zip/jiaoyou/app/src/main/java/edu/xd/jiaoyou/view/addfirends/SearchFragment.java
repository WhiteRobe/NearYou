package edu.xd.jiaoyou.view.addfirends;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.StringToInteger;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.UserPageActivity;
import edu.xd.jiaoyou.view.custom.CustomToast;
import edu.xd.jiaoyou.view.custom.RecycleViewDivider;
import edu.xd.jiaoyou.view.main.FriendAdapter;
import edu.xd.jiaoyou.view.main.FriendModel;

/**
 * Created by ZhengXi on 2017/6/12.
 */

public class SearchFragment extends Fragment {

    private DataService dataService = null;
    private UICallback uiCallback = null;

    private Context mContext;
    private View mView;
    private Button btnSearch;
    private EditText etSearch;
    private RecyclerView mRecyclerView;
    private FriendAdapter mAdapter;

    private String account = null;

    /**
     * 根据fragment和viewpager的生命周期，每次调用dataService方法时
     * 手动设置uiCallBack
     * @param context
     */
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;

        //获得绑定的服务
        //此时activity还没有绑定服务完成
        //使用线程监听activity的绑定情况
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(!((AddFriendsActivity) getActivity()).isConnected()) {}
                dataService = ((AddFriendsActivity) getActivity()).getDataService();
            }
        }).start();
        uiCallback = new SearchFragment.UICallBack();

        mAdapter = new FriendAdapter();
        mAdapter.setHeaderView(false);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_addfriends_search,null);
        btnSearch = (Button) mView.findViewById(R.id.btn_addfriends_search);
        etSearch = (EditText) mView.findViewById(R.id.et_addfrieds_search);

        mRecyclerView = (RecyclerView) mView.findViewById(R.id.rcyView_addfirends);
        mRecyclerView.setAdapter(mAdapter);
        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(manager);
        mRecyclerView.addItemDecoration(new RecycleViewDivider(getContext()));

        setOnClickEvent();
        return mView;
    }

    private void setOnClickEvent() {
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                account = etSearch.getText().toString();
                if(account!=null && !account.equals("")) {
                    CustomToast.makeText(mContext,"正在查询", CustomToast.LENGTH_SHORT).show();
                    dataService.setUICallback(uiCallback);
                    dataService.searchFriendsByid(account);
                }
                else {
                    CustomToast.makeText(mContext,"账号不能为空", CustomToast.LENGTH_SHORT).show();
                }
            }
        });

        mAdapter.setOnItemClickListener(new FriendAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent intent = new Intent(mContext, UserPageActivity.class);
                intent.putExtra("userId",mAdapter.getUserId(position));
                intent.putExtra("stranger",true);
                startActivity(intent);
            }
        });
    }

    private class UICallBack implements UICallback {
        int userId;
        String name;
        String profile;
        String type;
        @Override
        public void dealServerRes(JSONObject msgIn) {
            try {
                JSONObject data = msgIn.getJSONObject("Data");
                JSONObject value = data.getJSONObject("Value");
                userId = StringToInteger.StringToInteger(
                        value.getString("Id"));
                name = value.getString("NickName");
                profile = value.getString("Avatar");
                type = value.getString("FirstLt");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void dealServerPush(JSONObject msgIn) {}

        @Override
        public void dealServerMessage(JSONObject msgIn) {}

        @Override
        public void localMsg(String msg) {
            if (msg.equals(profile)) {
                mRecyclerView.post(new Runnable() {
                    @Override
                    public void run() {
                        mAdapter.add(new FriendModel(userId, name, profile, type));
                    }
                });
            }
            if (msg.equals("DIAOXIAN"))
                mView.post(new Runnable() {
                    @Override
                    public void run() {
                        CustomToast.makeText(mContext,"与服务器断开连接",
                                CustomToast.LENGTH_SHORT).show();
                    }
                });
        }
    }

}
