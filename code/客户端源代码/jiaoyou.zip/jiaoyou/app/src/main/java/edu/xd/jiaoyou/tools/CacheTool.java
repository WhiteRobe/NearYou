package edu.xd.jiaoyou.tools;

import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * Created by ZhengXi on 2017/6/6.
 */

public class CacheTool {

    private static final String TAG = "CacheTool";

    /**
     * 将实现了Serializable接口的类的对象保存到文件中
     * @param obj  要写入的对象
     * @param path 要写入的路径
     */
    public static void writeObjectToFile(Object obj,String path) {
        File file = new File(path);
        if (!file.exists())
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        try {
            FileOutputStream out = new FileOutputStream(path);
            ObjectOutputStream objOut = new ObjectOutputStream(out);
            objOut.writeObject(obj);
            objOut.flush();
            objOut.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 从文件中读取对象
     * @param path 要读取文件的路径
     * @return Object对象，根据需求强制类型转换
     */
    public static Object readObjectFromFile(String path) {
        Object temp = null;;
        try {
            FileInputStream in = new FileInputStream(path);
            ObjectInputStream objIn=new ObjectInputStream(in);
            temp=objIn.readObject();
            objIn.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return temp;
    }
}
