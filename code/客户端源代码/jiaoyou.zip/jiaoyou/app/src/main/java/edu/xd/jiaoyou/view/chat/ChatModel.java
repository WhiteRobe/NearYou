package edu.xd.jiaoyou.view.chat;

import java.io.Serializable;

import edu.xd.jiaoyou.Constant;

/**
 * Created by ZhengXi on 2017/5/26.
 */

public class ChatModel implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final int ITEM_TYPE_LEFT  = 0x0001;
    private static final int ITEM_TYPE_RIGHT = 0x0002;

    public String profile; //头像路径
    public String content; //内容
    public String picture; //图片路径，限制1张
    public String time;    //事件
    public int from;       //内容来源

    public ChatModel(String profile,String content,String picture,String time,int from) {
        this.profile = profile;
        this.content = content;
        this.picture = picture;
        this.time = time;
        check(from);
        this.from = from;
    }

    public boolean canShowTime() {
        if(time==null) return false;
        else if(time.equals("")) return false;
        return true;
    }

    //是否文本类型
    public boolean isText() {
        if(profile==null || profile.equals("")) return true;
        return false;
    }

    public boolean hasProfile() {
        if(profile==null || profile.equals("") || profile.equals("default_avatar.jpg")) return false;
        return true;
    }

    private void check(int from) {
        if(from!=ITEM_TYPE_LEFT && from!=ITEM_TYPE_RIGHT) {
            throw new IllegalArgumentException();
        }
    }
}
