package edu.xd.jiaoyou.data;

import edu.xd.jiaoyou.tools.MessageTool;

import org.json.JSONObject;

/**
 * Created by dai on 2017/4/26.
 */

public class DisspatcServerMsg {
    public void dispatch(JSONObject msgIn, UICallback uiCallback)throws Exception {
        String msgType = msgIn.getString("MsgType");
        System.out.println("DLog:收到一条:"+MessageTool.getMsgTypeName(msgType)+"\n  - "+msgIn.toString());
        if (msgType.equals(InfoValue.MsgType.SERVER_RES)) {
            uiCallback.dealServerRes(msgIn);
        }
        else if (msgType.equals(InfoValue.MsgType.SERVER_REQ)) {
            //System.out.println("收到服务器请求类型:" + msgType);
        }
        else if (msgType.equals(InfoValue.MsgType.SERVER_PUSH)) {
            uiCallback.dealServerPush(msgIn);
        }
        else if (msgType.equals(InfoValue.MsgType.EMPTY)) {
            //System.out.println("收到服务器空包类型:" + msgType);
        }
        else if (msgType.equals(InfoValue.MsgType.MESSAGE)) {
            uiCallback.dealServerMessage(msgIn);
        }
        else {
            System.out.println("DLog:Dispatcher收到其他消息:"+MessageTool.getMsgTypeName(msgType));
        }
    }
}
