package edu.xd.jiaoyou.view.chat;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.InfoValue;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.BaseActivity;
import edu.xd.jiaoyou.view.UserPageActivity;

/**
 * Created by ZhengXi on 2017/5/22.
 */

public class ChatActivity extends BaseActivity implements View.OnClickListener {

    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;
    private UICallback uiCallback = new UICallback() {
        @Override
        public void dealServerRes(JSONObject msgIn) {}

        @Override
        public void dealServerPush(JSONObject msgIn) {
            String response = null;
            try {
                JSONObject data = msgIn.getJSONObject("Data");
                response = data.getString("Class");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if(response.equals(InfoValue.MsgPush.Success)) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mAdapter.add(new ChatModel(myProfile,message,null,null,2));
                        etText.setText("");
                    }
                });
            }
        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {
            try {
                JSONObject data = msgIn.getJSONObject("Data");
                msg = data.getString("Value");
                time = data.getString("Time");
                location = data.getString("City")+" "+data.getString("Stress");
                System.out.println("time"+time);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFirst) time = null;
                        isFirst = false;
                        mAdapter.add(new ChatModel(profile,msg,null,time,1));
                        tvLocation.setText(location);
                    }
                });
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void localMsg(String msg) {}
    };
    
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };

    private Button btnBack;
    private TextView tvTitle;
    private TextView tvLocation;
    private Button btnInfo;
    private RecyclerView rcyContent;
    private Button btnSend;
    private Button btnMore;
    private Button btnEmoticon;
    private EditText etText;
    private String message;   //发送的消息
    private ChatAdapter mAdapter = null;

    private int userId = -1;
    private String name;
    private String myName;
    private String myProfile;
    private String profile;
    private String location;

    private String time,msg;
    private static boolean isFirst = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        Intent bindIntent = new Intent(ChatActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);
        
        Intent intent = getIntent();
        userId = intent.getIntExtra("userId",-1);
        if (userId == 123) name="郑茜";
        else if (userId==0) name="戴宏";
        System.out.println(userId);

        profile = Constant.SERVICE_IP+"/avatar/"+userId+"_avatar";
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(dataService==null) {}
                dataService.setUICallback(uiCallback);
                myName = dataService.getNickName();
                myProfile = Constant.SERVICE_IP+"/avatar/"+dataService.getUserID()+"_avatar";
            }
        }).start();
        
        init();
        loadLocalCache();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unbindService(connection);
    }

    private void init() {
        mAdapter = new ChatAdapter();

        btnBack = (Button) findViewById(R.id.btn_back);
        btnBack.setOnClickListener(this);
        tvTitle = (TextView) findViewById(R.id.textView_title);
        tvTitle.setText(name);
        tvLocation = (TextView) findViewById(R.id.textView_location);
        btnInfo = (Button) findViewById(R.id.btn_info);
        btnInfo.setOnClickListener(this);

        rcyContent = (RecyclerView) findViewById(R.id.rcyView_chat_content);
        rcyContent.setLayoutManager(new LinearLayoutManager(ChatActivity.this));
        rcyContent.setAdapter(mAdapter);

        btnSend = (Button) findViewById(R.id.btn_chat_send);
        btnSend.setOnClickListener(this);
        btnMore = (Button) findViewById(R.id.btn_chat_more);
        btnMore.setOnClickListener(this);
        btnEmoticon = (Button) findViewById(R.id.btn_chat_emoticon);
        btnEmoticon.setOnClickListener(this);
        etText = (EditText) findViewById(R.id.editText_chat_text);
        etText.addTextChangedListener(new TextWatcher());

        rcyContent.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                RecyclerView.LayoutManager layoutManager = rcyContent.getLayoutManager();
                if (layoutManager instanceof LinearLayoutManager) {
                    LinearLayoutManager linearManager = (LinearLayoutManager) layoutManager;
                    //获取最后一个可见view的位置
                    int lastItemPosition = linearManager.findLastVisibleItemPosition();
                    //获取第一个可见view的位置
                    int firstItemPosition = linearManager.findFirstVisibleItemPosition();
                    System.out.println("near"+lastItemPosition + "   " + firstItemPosition);
                }
            }
        });
        mAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                super.onItemRangeInserted(positionStart,itemCount);
                int messageCount = mAdapter.getItemCount();
                int lastVisiblePosition =
                        ((LinearLayoutManager) rcyContent.getLayoutManager()).
                                findLastCompletelyVisibleItemPosition();

                if (lastVisiblePosition == -1 ||
                        (positionStart >= (messageCount - 1) &&
                                lastVisiblePosition == (positionStart - 1))) {
                    rcyContent.scrollToPosition(positionStart);
                }
            }
        });
    }

    //加载本地聊天记录
    private void loadLocalCache() {
        List<ChatModel> models = Constant.AppData.chats.get(0);
        mAdapter.add(models);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_back:
                onBackPressed();
                break;
            case R.id.btn_chat_send:
                message = etText.getText().toString();
                dataService.setUICallback(uiCallback);
                dataService.sendTxtMessage(String.valueOf(userId),message);
                break;
            case R.id.btn_info:
                Intent intent = new Intent(ChatActivity.this, UserPageActivity.class);
                intent.putExtra("userId",userId);
                intent.putExtra("userName",name);
                intent.putExtra("userProfile",profile);
                startActivity(intent);
                finish();
            case R.id.btn_chat_more:
                break;
            case R.id.btn_chat_emoticon:
                break;
        }
    }

    private class TextWatcher implements android.text.TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            if(null==etText.getText().toString() || etText.getText().toString().equals("")) {
                btnSend.setVisibility(View.GONE);
                btnMore.setVisibility(View.VISIBLE);
            }
            else {
                btnSend.setVisibility(View.VISIBLE);
                btnMore.setVisibility(View.GONE);
            }
        }
    }
}
