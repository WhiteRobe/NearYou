package edu.xd.jiaoyou.view.custom;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import edu.xd.jiaoyou.R;

/**
 * Created by ZhengXi on 2017/6/2.
 */

public class ImageTextButton extends RelativeLayout {

    private ImageView mImage;
    private TextView  mText;

    public ImageTextButton(Context context) {
        super(context);
    }

    public ImageTextButton(Context context, AttributeSet attrs) {
        super(context,attrs);
        LayoutInflater.from(context).inflate(R.layout.custom_image_text_button,this,true);
        mImage = (ImageView) findViewById(R.id.image);
        mText = (TextView) findViewById(R.id.text);

        TypedArray mArray = context.obtainStyledAttributes(attrs,R.styleable.ImageTextButton);
        mImage.setImageDrawable(mArray.getDrawable(R.styleable.ImageTextButton_src));
        if(mArray.getText(R.styleable.ImageTextButton_text)==null) {
            mText.setVisibility(GONE);
        }
        else mText.setText(mArray.getText(R.styleable.ImageTextButton_text));
        mArray.recycle();
    }

    public void setText(CharSequence text) {
        if(mText.getVisibility()==GONE)
            mText.setVisibility(VISIBLE);
        mText.setText(text);
    }

    public void setTextColor(int color) {
        mText.setTextColor(color);
    }

    public void setTextSize(float size) {
        mText.setTextSize(size);
    }

    public void setTextSize(int unit,float size) {
        mText.setTextSize(unit,size);
    }

    public void setImageDrawable(Drawable drawable) {
        mImage.setImageDrawable(drawable);
    }

    public void setImageResource(int resID) {
        mImage.setImageResource(resID);
    }

}
