package edu.xd.jiaoyou.view.main;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ZhengXi on 2017/5/28.
 */

public class MomentModel implements Serializable {

    private static final long serialVersionUID = 1L;

    public int id = -1;               //动态id
    public int userId = -1;           //用户id
    public String name = null;        //用户昵称/名字
    public String profile = null;     //头像路径
    public String content = null;     //动态内容
    public int pictures = -1;         //图片数量
    public int width = -1;            //图片宽高
    public int height = -1;           //仅一张图片时有效
    public String time = null;        //发布时间
    public String place = null;       //发布地点
    public int likes = -1;            //点赞数
    public int comments = -1;         //评论数
    public boolean isLike = false;    //是否点过赞
    public List<String> images = null;//图片路径

    public MomentModel(int id,int userId,String name,String profile, String content,int pictures,int width,
                       int height,String time,String place,int likes,int comments,boolean isLike,List<String> images) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.profile = profile;
        this.content = content;
        this.pictures = pictures;
        this.width = width;
        this.height = height;
        this.time = time;
        this.place = place;
        this.likes = likes;
        this.comments = comments;
        this.isLike = isLike;
        //若不采用添加值的方式，再次读取list会导致引用对象为空
        this.images = new ArrayList<>();
        this.images.addAll(images);
        this.pictures = images.size(); //以实际list大小为准

        if(pictures==-1 && (width==-1 || height==-1)) {
            throw new IllegalArgumentException("picture size 0 * 0 is invalid");
        }
    }

    public boolean hasProfile() {
        if (profile == null || profile.equals("") || profile.equals("default_avatar.jpg")) return false;
        return true;
    }

    public boolean hasPicture() {
        if (pictures == -1 || pictures == 0) return false;
        return true;
    }
}
