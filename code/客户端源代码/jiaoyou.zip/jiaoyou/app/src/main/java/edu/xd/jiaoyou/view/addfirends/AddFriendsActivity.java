package edu.xd.jiaoyou.view.addfirends;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.view.CommonFragmentPagerAdapter;

/**
 * Created by ZhengXi on 2017/6/3.
 */

public class AddFriendsActivity extends AppCompatActivity {

    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;

    private Button btnCancel;
    private TextView tvTitle;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    private CommonFragmentPagerAdapter mAdapter;
    private SearchFragment searchFragment;
    private NearbyFragment nearbyFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addfriends);

        Intent bindIntent = new Intent(AddFriendsActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        init();
    }

    @Override
    public void onDestroy() {
        unbindService(connection);
        super.onDestroy();
    }

    public DataService getDataService() {
        return dataService;
    }

    public boolean isConnected() {
        return dataService!=null;
    }

    private void init() {
        btnCancel = (Button) findViewById(R.id.btn_back);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        tvTitle = (TextView) findViewById(R.id.textView_title);
        tvTitle.setText("添加好友");

        mTabLayout = (TabLayout) findViewById(R.id.tab_addfriends);
        mTabLayout.addTab(mTabLayout.newTab().setText("精确查找"));
        mTabLayout.addTab(mTabLayout.newTab().setText("附近的人"));
        mTabLayout.post(new Runnable() {
            @Override
            public void run() {
                setIndicator(mTabLayout,154,154);
            }
        });

        mViewPager = (ViewPager) findViewById(R.id.viewPager_addfriends);
        searchFragment = new SearchFragment();
        nearbyFragment = new NearbyFragment();
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(searchFragment);
        fragments.add(nearbyFragment);
        mAdapter = new CommonFragmentPagerAdapter(getSupportFragmentManager(),fragments);
        mViewPager.setAdapter(mAdapter);

        mViewPager.addOnPageChangeListener(new TabLayoutOnPageChangeListener(mTabLayout));
        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                mViewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private ServiceConnection connection=new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };

    /**
     * 重写TabLayout.TabLayoutOnPageChangeListener
     */
    private class TabLayoutOnPageChangeListener extends TabLayout.TabLayoutOnPageChangeListener {

        public TabLayoutOnPageChangeListener(TabLayout tabLayout) {
            super(tabLayout);
        }

        @Override
        public void onPageSelected(int position) {
            super.onPageSelected(position);
            if(position==1) {
                nearbyFragment.autoRefresh();
            }
        }

    }

    /**
     * 设置tabLayout下划线据父view的边距，调整其大小，单位px
     * 调整下划线大小之后，如果其长度小于文字长度，其上的文字长度会跟随下划线长度
     * 通过java反射机制
     * @param tabs     需要设置的tablayout
     * @param leftPX   左侧下划线边距
     * @param rightPX  右侧下划线边距
     */
    private void setIndicator (TabLayout tabs,int leftPX,int rightPX) {
        Class<?> tabLayout = tabs.getClass();
        Field tabStrip = null;
        try {
            tabStrip = tabLayout.getDeclaredField("mTabStrip");
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }

        tabStrip.setAccessible(true);
        LinearLayout llTab = null;
        try {
            llTab = (LinearLayout) tabStrip.get(tabs);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        //设置单位为dp时，使用TypedValue.COMPLEX_UNIT_DIP将其转换为dp
        //int left = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, leftPX, Resources.getSystem().getDisplayMetrics());
        //int right = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, rightPX, Resources.getSystem().getDisplayMetrics());

        for (int i = 0; i < llTab.getChildCount(); i++) {
            View child = llTab.getChildAt(i);
            child.setPadding(0, 0, 0, 0);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1);
            params.leftMargin = leftPX;
            params.rightMargin = rightPX;
            child.setLayoutParams(params);
            child.invalidate();
        }
    }

}
