package edu.xd.jiaoyou.view.momentdetail;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.view.custom.CircleImageView;

/**
 * Created by ZhengXi on 2017/5/23.
 */

public class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.ViewHolder> {

    private List<CommentModel> mData = null;
    private View convertView = null;
    private ViewHolder mHolder = null;

    public CommentAdapter(List<CommentModel> data) {
        this.mData = data;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        convertView = LayoutInflater.from(parent.getContext()).inflate
                (R.layout.item_comments,parent,false);
        mHolder = new CommentAdapter.ViewHolder(convertView);
        return mHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        CommentModel item = mData.get(position);

        holder.itemView.setTag(position);
        if (item.hasProfile()) {
            Glide.with(holder.itemView.getContext())
                    .load(item.profile)
                    .into(holder.cvProfilePhoto);
        }
        holder.tvName.setText(item.name);
        holder.tvContent.setText(item.content);
        holder.tvTime.setText(item.time);
        if(position==getItemCount()-1) holder.view.setVisibility(View.VISIBLE);
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        public View itemView = null;
        public CircleImageView cvProfilePhoto = null;
        public TextView tvName = null;
        public TextView tvContent = null;
        public TextView tvTime = null;
        public View view = null;

        public ViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;

            cvProfilePhoto = (CircleImageView) itemView.findViewById(R.id.img_comments_profile);
            tvName = (TextView) itemView.findViewById(R.id.textView_comments_name);
            tvContent = (TextView) itemView.findViewById(R.id.textView_comments_content);
            tvTime = (TextView) itemView.findViewById(R.id.textView_comments_time);
            view = (View) itemView.findViewById(R.id.view_comments_blank);
        }
    }
}
