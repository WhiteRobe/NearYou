package edu.xd.jiaoyou.view.main;

import java.io.Serializable;

/**
 * Created by ZhengXi on 2017/5/28.
 */

public class FriendModel implements Serializable {

    private static final long serialVersionUID = 1L;

    public int userId = -1;      //用户id
    public String name = null;   //用户昵称/姓名
    public String profile = null;//头像路径
    public String type = null;   //拼音首字母

    public FriendModel(int userId,String name,String profile,String type) {
        this.userId = userId;
        this.profile = profile;
        this.name = name;
        this.type = type;
    }

    public boolean hasProfile() {
        if(profile==null || profile.equals("") || profile.equals("default_avatar.jpg")) return false;
        return true;
    }
}
