package edu.xd.jiaoyou.view.publish;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;

import java.util.List;

import edu.xd.jiaoyou.R;


/**
 * Created by ZhengXi on 2017/6/16.
 */

public class GridViewAddImagesAdapter extends BaseAdapter {
    private List<String> data;
    private Context context;
    private int maxImages = 9; //最大上传数，默认9张

    private OnItemClickListener onItemClickListener = null;

    public GridViewAddImagesAdapter(List<String> data) {
        this.data = data;
    }

    /**
     * 获取最大上传张数
     * @return
     */
    public int getMaxImages() {
        return maxImages;
    }

    /**
     * 设置最大上传张数
     * @param maxImages
     */
    public void setMaxImages(int maxImages) {
        this.maxImages = maxImages;
    }

    /**
     * 让GridView中的数据数目加1最后一个显示+号
     * @return 返回GridView中的数量
     */
    @Override
    public int getCount() {
        int count = data==null ? 1 : data.size() + 1;
        // if count == maxImage 说明只剩最后一张图片没有加载
        if (count > maxImages) {
            return data.size();
        } else {
            return count;
        }
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    /**
     * 更新view，
     * 为了在外部维护方便，使用data替换的方式更新
     * @param data
     */
    public void notifyDataSetChanged(List<String> data) {
        this.data = data;
        this.notifyDataSetChanged();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        context = parent.getContext();
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_addimages,null);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        if (data != null && position < data.size()) {
            Glide.with(context)
                    .load(data.get(position))
                    .priority(Priority.HIGH)
                    .into(viewHolder.imageView);
            //viewHolder.imageView.setImageDrawable(parent.getContext().getDrawable(R.drawable.background));
            viewHolder.btnDel.setVisibility(View.VISIBLE);
            viewHolder.btnDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    data.remove(position);
                    notifyDataSetChanged();
                }
            });
        } else {
            Glide.with(context)
                    .load(R.drawable.add_image)
                    .priority(Priority.HIGH)
                    .into(viewHolder.imageView);
            //使用下面的方式图片不会改变？
            //viewHolder.imageView.setImageDrawable(parent.getContext().getDrawable(R.drawable.add_image));
            viewHolder.btnDel.setVisibility(View.GONE);
        }

        viewHolder.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onItemClickListener!=null) {
                    if(position == data.size())
                        onItemClickListener.onClickBlankImage(position);
                    else onItemClickListener.onClickAlreadyImage(position);
                }
            }
        });
        return convertView;
    }

    public interface OnItemClickListener {
        void onClickBlankImage(int position);
        void onClickAlreadyImage(int position);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public class ViewHolder {
        public View mView;
        public Button btnDel;
        public ImageView imageView;

        public ViewHolder(View itemView) {
            mView = itemView;
            btnDel = (Button) mView.findViewById(R.id.btn_delete);
            imageView = (ImageView) mView.findViewById(R.id.image_addimage);
        }
    }
}
