/**
 * Copyright (C), 2017-2018, Xidian University, Xian, China
 * 
 * @auther dai
 * @date 2017-4-23
 */
package edu.xd.jiaoyou.tools;

import com.amap.api.location.AMapLocation;
import edu.xd.jiaoyou.data.InfoValue;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

public class MessageTool {
	/**
	 * get File Type
	 * @param fileName
	 * @return exp: .jpg
	 */
	public static String getType(String fileName){
		return fileName.substring(fileName.indexOf("."));
	}
	/**
	 * Get time
	 * @return Hh:Mm:Ss
     */
	public String getTime(){
		Calendar c= Calendar.getInstance();
		return c.get(Calendar.HOUR_OF_DAY)+":"+c.get(Calendar.MINUTE)+":"+c.get(Calendar.SECOND);
	}
	/**
	 * Get Sql-format System time
	 * 
	 * @return sqlDate
	 */
	public static String getSqlDate(){
		return ""+new java.sql.Date(new Date().getTime());
	}
	/**
	 * Make Message with a set<string>.
	 * 
	 * @param set
	 * @return msg
	 */
	public static String mkMsg(Set<String> set){
		String msg="";
		Iterator<String> it=set.iterator();
		while(it.hasNext()){
			msg+=transMsg(it.next());
			msg+=PackageConstants.ESCAPE_STRING;
		}
		return msg+"\n";
	}
	/**
	 * Make Message with a String[].
	 *
	 * @param //String[]
	 * @return msg
	 */
	public static String mkMsg(String[] string){
		String msg="";
		int lenth=string.length;
		for(int i=0;i<lenth;i++){
			msg+=transMsg(string[i]);
			msg+=PackageConstants.ESCAPE_STRING;
		}
		return msg+"\n";
	}
	/**
	 * Pack message.
	 * 
	 * @param STRING
	 * @return transedMsg
	 */
	public static String transMsg(String STRING){
		return STRING.replace(PackageConstants.ESCAPE_STRING,PackageConstants.ESCAPE_STRING_TRANS_VALUE);
	}
	/**
	 * Unpack message.
	 * 
	 * @param STRING
	 * @return unTransedMsg
	 */
	public static String unTransMsg(String STRING){
		return STRING.replace(PackageConstants.ESCAPE_STRING_TRANS_VALUE,PackageConstants.ESCAPE_STRING);
	}
	/**
	 * Is the string contains PackageConstants.ESCAPE_STRING ?
	 * 
	 * @param STRING
	 * @return boolean
	 */
	public boolean checkEscape(String STRING){
		return STRING.contains(PackageConstants.ESCAPE_STRING);
	}
	/**
	 * Is the string contains PackageConstants.ESCAPE_STRING_TRANS_VALUE ?
	 * 
	 * @param STRING
	 * @return boolean
	 */
	public boolean checkEscapeTrans(String STRING){
		return STRING.contains(PackageConstants.ESCAPE_STRING_TRANS_VALUE);
	}
	/**
	 * Extract parts of msg_string from origin string.
	 * 
	 * @param msgString
	 * @param msgPart
	 * @return str
	 */
	public static String extractMsg(String msgString,int msgPart){
		String str="";
		int start=-PackageConstants.ESC_STRING_LENGTH,end=msgString.indexOf(PackageConstants.ESCAPE_STRING);
		for(int i=0;i<msgPart;i++){
			start=msgString.indexOf(PackageConstants.ESCAPE_STRING,start+PackageConstants.ESC_STRING_LENGTH);
			end=msgString.indexOf(PackageConstants.ESCAPE_STRING,end+PackageConstants.ESC_STRING_LENGTH);
		}
		if(end==-1)end=msgString.length();
		//System.out.println(start+PackageConstants.ESC_STRING_LENGTH+":"+end);//Test
		str=msgString.substring(start+PackageConstants.ESC_STRING_LENGTH,end);
		return unTransMsg(str);
	}

	//获取指定编号的服务器消息头名字
	public static String getMsgTypeName(String num){
		int index=Integer.parseInt(num);
		if(index>=InfoValue.MsgName.MsgType.length)return null;
		else return InfoValue.MsgName.MsgType[index];
	}
	public static String getMsgPushName(String num){
		int index=Integer.parseInt(num);
		if(index>=InfoValue.MsgName.MsgPush.length)return null;
		else return InfoValue.MsgName.MsgPush[index];
	}
	public static String getMsgReqName(String num){
		int index=Integer.parseInt(num);
		if(index>=InfoValue.MsgName.MsgReq.length)return null;
		else return InfoValue.MsgName.MsgReq[index];
	}
	public static String getMsgResName(String num){
		int index=Integer.parseInt(num);
		if(index>=InfoValue.MsgName.MsgRes.length)return null;
		else return InfoValue.MsgName.MsgRes[index];
	}

	public static JSONObject mkGeoJSMsg(JSONObject msgOut,JSONObject value){
		try {
			JSONObject data=new JSONObject();
				data.put("Class",InfoValue.MsgPush.UpdataGeo);
				data.put("Value",value);
				data.put("Day",TimeManager.getSqlDate());
				data.put("Time",TimeManager.getTime());
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkLoginJSMsg(String id, String pw, String MID, AMapLocation gd){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.LOGIN);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",InfoValue.PackageConstants.CLIENT_ID);
				JSONObject data=new JSONObject();
				data.put("Account",id);
				data.put("Password",pw);
				data.put("Longitude",gd.getLongitude()+"");
				data.put("Latitude",gd.getLatitude()+"");
				data.put("Address",gd.getAddress()+"");
				data.put("Adcode",gd.getAdCode()+"");
				data.put("Valicode","empty");
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkRegisterJSMsg(String id, String pw, String MID, AMapLocation gd){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.REGISTER);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",InfoValue.PackageConstants.CLIENT_ID);
				JSONObject data=new JSONObject();
				data.put("Account",id);
				data.put("Password",pw);
				data.put("Longitude",gd.getLongitude()+"");
				data.put("Latitude",gd.getLatitude()+"");
				data.put("Address",gd.getAddress()+"");
				data.put("Adcode",gd.getAdCode()+"");
				data.put("Valicode","empty");
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkOfflineJSMsg(String userID,String MID){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.CLIENT_PUSH);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",InfoValue.PackageConstants.CLIENT_ID);
				JSONObject data=new JSONObject();
				data.put("Class",InfoValue.MsgPush.ClientOffline);
				data.put("UserId",userID);
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkSearchFriensByIdJSMsg(String userId,String targetId,String MID){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.CLIENT_REQ);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",userId);
				JSONObject data=new JSONObject();
				data.put("Class",InfoValue.MsgReq.SearchFriendById);
					JSONObject value=new JSONObject();
					value.put("TargetId",targetId);
				data.put("Value",value);
				data.put("Day",TimeManager.getSqlDate());
				data.put("Time",TimeManager.getTime());
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkSearchFriensByNicknameJSMsg(int begin,String userId,String targetId,String MID){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.CLIENT_REQ);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",userId);
			JSONObject data=new JSONObject();
			data.put("Class",InfoValue.MsgReq.SearchFriendById);
			JSONObject value=new JSONObject();
				value.put("TargetId",targetId);//目标的昵称
			data.put("Value",value);
			data.put("Day",TimeManager.getSqlDate());
			data.put("Time",TimeManager.getTime());
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkSearchFriensNearbyJSMsg(int begin,String userId,String adcode,String MID){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.CLIENT_REQ);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",userId);
			JSONObject data=new JSONObject();
				data.put("Class",InfoValue.MsgReq.SearchFriendNearby);
				JSONObject value=new JSONObject();
					value.put("Begin",begin);
					value.put("Adcode",adcode);
				data.put("Value",value);
				data.put("Day",TimeManager.getSqlDate());
				data.put("Time",TimeManager.getTime());
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkGetMomentsFriendsJSMsg(String userId,String MID){
		JSONObject msgOut=new JSONObject();
		//waiting to solve
		return msgOut;
	}
	public static JSONObject mkGetMomentsByidJSMsg(String userId,String targetId,String MID){
		//最新五条消息
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.CLIENT_REQ);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",userId);
			JSONObject data=new JSONObject();
				data.put("Class",InfoValue.MsgReq.GetMomentsById);
				JSONObject value=new JSONObject();
					value.put("TargetId",targetId);
				data.put("Value",value);
				data.put("Day",TimeManager.getSqlDate());
				data.put("Time",TimeManager.getTime());
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkGetMomentsNearbyJSMsg(int begin,String userId,String adcode,String MID){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.CLIENT_REQ);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",userId);
				JSONObject data=new JSONObject();
				data.put("Class",InfoValue.MsgReq.GetMomentsNearby);
				JSONObject value=new JSONObject();
					value.put("Begin",begin);
					value.put("Adcode",adcode);
				data.put("Value",value);
				data.put("Day",TimeManager.getSqlDate());
				data.put("Time",TimeManager.getTime());
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkMessageJSMsg(String userId,String targetId,String MID,String classs,String type,String text,AMapLocation gd){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.MESSAGE);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",userId);
				JSONObject data=new JSONObject();
				data.put("Class",classs);
				data.put("Type",type);
				data.put("Value",text);
				data.put("Target",targetId);
				data.put("City",gd.getCity());
				data.put("Stress",gd.getStreet());
				data.put("Address",gd.getAddress());
				data.put("Day",TimeManager.getSqlDate());
				data.put("Time",TimeManager.getTime());
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkMommentJSMsg(String userId,String MID,String text,boolean privacy,int picNum,String type,AMapLocation gd){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.CLIENT_POST_MOMENTS);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",userId);
				JSONObject data=new JSONObject();
				data.put("Type",type);
				data.put("Text",text);
				data.put("PicNum",picNum+"");
				data.put("Location",gd.getCity()+" "+gd.getStreet());
				data.put("Adcode",gd.getAdCode());
				if(privacy)data.put("Privacy","true");
				else data.put("Privacy","false");
				data.put("Day",TimeManager.getSqlDate());
				data.put("Time",TimeManager.getTime());
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkCommentJSMsg(int momentId,String userId,String MID,String text,boolean privacy,AMapLocation gd){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.CLIENT_POST_COMMENT);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",userId);
				JSONObject data=new JSONObject();
				data.put("Target",momentId);
				data.put("Text",text);
				data.put("Location",gd.getCity()+" "+gd.getStreet());
				data.put("Time",TimeManager.getTime());
				data.put("Day",TimeManager.getSqlDate());
				if(privacy)data.put("Privacy","true");
				else data.put("Privacy","false");
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
	public static JSONObject mkResetPWJSMsg(String userId,String MID,String oldPW,String newPW){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.CLIENT_REQ);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",userId);
			JSONObject data=new JSONObject();
				data.put("Class", InfoValue.MsgReq.ResetPassword);
				JSONObject value=new JSONObject();
					value.put("Account",userId);
					value.put("OldPassword",oldPW);
					value.put("NewPassword",newPW);
				data.put("Value",value);
				data.put("Time",TimeManager.getTime());
				data.put("Day",TimeManager.getSqlDate());
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
    public static JSONObject mkAddFRriendMsg(String userId,String targetId,String nickName,String brief,String MID){
        JSONObject msgOut=new JSONObject();
        try {
            msgOut.put("MsgType", InfoValue.MsgType.CLIENT_REQ);
            msgOut.put("MsgId",MID);
            msgOut.put("UID",userId);
                JSONObject data=new JSONObject();
                data.put("Class", InfoValue.MsgReq.AddFriends);
                    JSONObject value=new JSONObject();
                    value.put("TargetId",targetId);
                    value.put("Brief",brief);
                    value.put("NickName",nickName);
                data.put("Value",value);
                data.put("Time",TimeManager.getTime());
                data.put("Day",TimeManager.getSqlDate());
            msgOut.put("Data",data);
        }catch (Exception e){e.printStackTrace();}
        return msgOut;
    }
	public static JSONObject mkMomentLikeMsg(String userId,String targetId,String nickName,boolean isLike,String moment_no,String MID){
		JSONObject msgOut=new JSONObject();
		try {
			msgOut.put("MsgType", InfoValue.MsgType.CLIENT_PUSH);
			msgOut.put("MsgId",MID);
			msgOut.put("UID",userId);
			JSONObject data=new JSONObject();
				data.put("Class", InfoValue.MsgPush.MomentLikedOrUnlike);
					JSONObject value=new JSONObject();
					value.put("TargetId",targetId);
					if(isLike)value.put("IsLike","true");
					else value.put("IsLike","false");
					value.put("NickName",nickName);
					value.put("MomentsNo",moment_no);
				data.put("Value",value);
				data.put("Time",TimeManager.getTime());
				data.put("Day",TimeManager.getSqlDate());
			msgOut.put("Data",data);
		}catch (Exception e){e.printStackTrace();}
		return msgOut;
	}
}
