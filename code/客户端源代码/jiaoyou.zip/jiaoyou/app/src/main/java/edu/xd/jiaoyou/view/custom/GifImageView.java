package edu.xd.jiaoyou.view.custom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Movie;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.widget.ImageView;

import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.Image;

/**
 * Created by ZhengXi on 2017/6/12.
 */


/**
 * 此项目中图片仅由代码动态加载，故未考虑xml文件中的属性
 */
public class GifImageView extends ImageView {

    private Movie mMovie; //播放动画的关键类
    private long mMovieStart; //记录动画开始的时间
    private boolean isPlaying = false; //是否正在播放
    private boolean isAutoPlay = true; //是否允许自动播放
    private boolean isGif = false; //是否是gif图片
    private Image image; //图片内容

    private int width;
    private int height;

    public GifImageView(Context context) {
        super(context);
    }

    public GifImageView(Context context, AttributeSet attrs) {
        super(context,attrs);
    }

    //测量控件大小
    //此项目中不需要动态设置控件大小，交给父控件NineGridLayout管理
    @Override
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec,heightMeasureSpec);
    }

    //绘制控件
    @Override
    public void onDraw(Canvas canvas) {
        //获取控件宽高
        if(width==0 && height==0) {
            width = getWidth();
            height = getHeight();
        }

        if(isGif) {
            if(isAutoPlay) {//自动播放
                playMovie(canvas);
                invalidate();
            }
        }

        else { //普通图片
            super.onDraw(canvas);
        }
    }

    //设置是否自动播放，默认为自动
    public void setAutoPlay(boolean isAutoPlay) {
        this.isAutoPlay = isAutoPlay;
        invalidate();
    }

    //为控件设置需要加载的Image
    public void setImage(Image image) {
        this.image = image;
        if(image.type == Constant.ImageType.COMMON ) {
            super.setImageBitmap(image.toBitmap());
        }
        else if(image.type == Constant.ImageType.GIF) {
            this.isGif = true;
            mMovie = image.toPlayer();
            invalidate();
        }
    }

    //销毁此控件,节约内存
    public void recycle() {
        //关闭自动播放
        isAutoPlay = false;
        //清空image对象
        if(image!=null)  {
            image.recycle();
            image = null;
        }
        //释放缓存
        destroyDrawingCache();
    }

    /**
     * 开始播放GIF动画，播放完成返回true，未完成返回false。
     * 4.0以上有些手机开启硬件加速之后，gif无法正常播放，需要在配置文件中禁止
     * @param canvas
     * @return 播放完成返回true，未完成返回false。
     */
    private boolean playMovie(Canvas canvas) {
        long now = SystemClock.uptimeMillis();
        if (mMovieStart == 0) {
            mMovieStart = now;
        }
        int duration = mMovie.duration();
        if (duration == 0) {
            duration = 1000;
        }
        int relTime = (int) ((now - mMovieStart) % duration);
        mMovie.setTime(relTime);

        //设置画布填充满控件
        float scaleX = (float) width/image.width;
        float scaleY = (float) height/image.height;
        canvas.scale(scaleX,scaleY);
        mMovie.draw(canvas, 0, 0);
        if ((now - mMovieStart) >= duration) {
            mMovieStart = 0;
            return true;
        }
        return false;
    }

    //invalidate();重绘view 即draw过程，不能影响view大小（measure）和位置（layout）
}
