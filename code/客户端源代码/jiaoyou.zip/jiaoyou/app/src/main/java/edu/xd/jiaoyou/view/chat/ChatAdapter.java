package edu.xd.jiaoyou.view.chat;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.view.custom.CircleImageView;

/**
 * Created by ZhengXi on 2017/5/26.
 */

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int ITEM_TYPE_ERROR = 0x0000;
    private static final int ITEM_TYPE_LEFT  = 0x0001;
    private static final int ITEM_TYPE_RIGHT = 0x0002;

    private Context mContext;
    private List<ChatModel> mData = null;
    private View convertView = null;
    private RecyclerView.ViewHolder mHolder = null;

    public ChatAdapter() {
        mData = new ArrayList<>();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        mContext = parent.getContext();
        switch (viewType) {
            case ITEM_TYPE_LEFT:
                convertView = LayoutInflater.from(parent.getContext()).inflate
                        (R.layout.item_chat_left,parent,false);
                mHolder = new LeftViewHolder(convertView);
                break;
            case ITEM_TYPE_RIGHT:
                convertView = LayoutInflater.from(parent.getContext()).inflate
                        (R.layout.item_chat_right,parent,false);
                mHolder = new RightViewHolder(convertView);
                break;
        }
        return mHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder,int position) {
        ChatModel item = mData.get(position);

        if(holder instanceof LeftViewHolder) {
            if(item.canShowTime()) {
                ((LeftViewHolder) holder).tvTime.setVisibility(View.VISIBLE);
                ((LeftViewHolder) holder).tvTime.setText(item.time);
            }
            else {
                ((LeftViewHolder) holder).tvTime.setVisibility(View.GONE);
                ((LeftViewHolder) holder).vTop.setVisibility(View.GONE);
            }

            if (item.hasProfile()) {
                Glide.with(mContext)
                        .load(item.profile)
                        .asBitmap()
                        .into(((LeftViewHolder) holder).cvProfile);

            }
            ((LeftViewHolder) holder).tvContent.setText(item.content);
        }

        else if(holder instanceof RightViewHolder) {
            if(item.canShowTime()) {
                ((RightViewHolder) holder).tvTime.setVisibility(View.VISIBLE);
                ((RightViewHolder) holder).tvTime.setText(item.time);
            }
            else {
                ((RightViewHolder) holder).tvTime.setVisibility(View.GONE);
                ((RightViewHolder) holder).vTop.setVisibility(View.GONE);
            }

            if (item.hasProfile()) {
                Glide.with(mContext)
                        .load(item.profile)
                        .asBitmap()
                        .into(((RightViewHolder) holder).cvProfile);
            }
            ((RightViewHolder) holder).tvContent.setText(item.content);
        }
    }

    @Override
    public int getItemViewType(int position) {
        switch (mData.get(position).from) {
            case ITEM_TYPE_LEFT:
                return ITEM_TYPE_LEFT;
            case ITEM_TYPE_RIGHT:
                return ITEM_TYPE_RIGHT;
            default:
                return ITEM_TYPE_ERROR;
        }
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void add(ChatModel data) {
        int position = getItemCount();
        mData.add(data);

        this.notifyItemInserted(position);
    }

    public void add(List<ChatModel> data) {
        int position = getItemCount();
        mData.addAll(data);

        this.notifyItemRangeInserted(position,data.size());
        this.notifyItemRangeChanged(position,data.size());
    }

    private static class LeftViewHolder extends RecyclerView.ViewHolder {
        public CircleImageView cvProfile;
        public TextView tvContent;
        public TextView tvTime;
        public View vTop;

        public LeftViewHolder(View itemView) {
            super(itemView);

            cvProfile = (CircleImageView) itemView.findViewById(R.id.img_left_profile);
            tvContent = (TextView) itemView.findViewById(R.id.textView_left_content);
            tvTime = (TextView) itemView.findViewById(R.id.textView_left_time);
            vTop = (View) itemView.findViewById(R.id.view_left_top);
        }
    }

    private static class RightViewHolder extends RecyclerView.ViewHolder {
        public CircleImageView cvProfile = null;
        public TextView tvContent = null;
        public TextView tvTime = null;
        public View vTop = null;

        public RightViewHolder(View itemView) {
            super(itemView);

            cvProfile = (CircleImageView) itemView.findViewById(R.id.img_right_profile);
            tvContent = (TextView) itemView.findViewById(R.id.textView_right_content);
            tvTime = (TextView) itemView.findViewById(R.id.textView_right_time);
            vTop = (View) itemView.findViewById(R.id.view_right_top);
        }
    }
}
