package edu.xd.jiaoyou.view;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.support.percent.PercentRelativeLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import org.json.JSONException;
import org.json.JSONObject;

import edu.xd.jiaoyou.BaseApplication;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.InfoValue;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.custom.CustomToast;
import edu.xd.jiaoyou.view.main.MainActivity;

/**
 * Created by ZhengXi on 2017/5/14.
 */
public class LoginActivity extends AppCompatActivity {

    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;
    private UICallback uiCallback=new UICallback() {
        @Override
        public void dealServerRes(JSONObject msgIn) {}

        @Override
        public void dealServerPush(JSONObject msgIn) {
            String response = null;
            try {
                JSONObject data = msgIn.getJSONObject("Data");
                response = data.getString("Class");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if(response.equals(InfoValue.MsgPush.LoginSuccess)) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        CustomToast.makeText(LoginActivity.this,"登录成功",
                                CustomToast.LENGTH_SHORT).show();
                    }
                });
                //将登陆账号密码写入数据库
                SharedPreferences preferences = getSharedPreferences("ACCOUNT",MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("userId",dataService.getUserID());
                editor.putString("account",phoneNumber);
                editor.putString("password",password);
                editor.commit();

                Intent intent =new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
            else if(response.equals(InfoValue.MsgPush.LoginFailed)) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        CustomToast.makeText(LoginActivity.this,"登录失败，请检查网络设置",
                                CustomToast.LENGTH_SHORT).show();
                    }
                });
            }
        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {}

        @Override
        public void localMsg(String msg) {
            if (msg.equals("DIAOXIAN"))
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        CustomToast.makeText(LoginActivity.this,"与服务器断开连接",
                                CustomToast.LENGTH_SHORT).show();
                    }
                });
        }
    };
    private ServiceConnection connection=new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
            dataService.setUICallback(uiCallback);
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };

    private ImageView logo;
    private PercentRelativeLayout rlPhone;
    private PercentRelativeLayout rlPassword;
    private EditText etPhone;
    private EditText etPassword;
    private Button btnLogin;

    private String phoneNumber;
    private String password;

    private static final int TYPE_DISAPPEAR = 0x0000; //logo消失类型
    private static final int TYPE_RESET     = 0x0001; //重置类型
    private float translationY; //平移距离
    private float startAlpha;   //动画起始alpha
    private int state = TYPE_RESET; //当前状态：disappear or no

    private static float sTvSize = -1.0f;
    private static final float RATIO = 0.30769231f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Intent bindIntent = new Intent(LoginActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        BaseApplication application = (BaseApplication) getApplication();
        phoneNumber = application.getAccount();
        password = application.getPassword();
        if (phoneNumber.equals("null")) phoneNumber = "";
        if (password.equals("null")) password = "";

        init();
    }

    @Override
    protected void onResume() {
        if(getRequestedOrientation()!= ActivityInfo.SCREEN_ORIENTATION_PORTRAIT){
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        initTextSize();
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        unbindService(connection);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (state == TYPE_DISAPPEAR) setAnimator(TYPE_RESET);
        else super.onBackPressed();
    }

    private void init() {
        logo = (ImageView) findViewById(R.id.img_login_logo);

        rlPhone = (PercentRelativeLayout) findViewById(R.id.rLayout_login_phoneNumber);
        rlPassword = (PercentRelativeLayout) findViewById(R.id.rLayout_login_password);

        etPhone = (EditText) findViewById(R.id.editText_login_phoneNumber);
        etPhone.setText(phoneNumber);

        //editText有焦点模式，故其焦点的响应事件优先级高于点击事件
        etPhone.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) setOnFocused(0);
            }
        });
        etPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (state == TYPE_RESET) setAnimator(TYPE_DISAPPEAR);
            }
        });
        etPassword = (EditText) findViewById(R.id.editText_login_password);
        etPassword.setText(password);
        etPassword.setLongClickable(false);
        etPassword.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) setOnFocused(1);
                if (state == TYPE_RESET) setAnimator(TYPE_DISAPPEAR);
            }
        });

        btnLogin = (Button) findViewById(R.id.btn_login_login);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phoneNumber = etPhone.getText().toString();
                password = etPassword.getText().toString();
                if(!dataService.login(phoneNumber,password)) {
                    CustomToast.makeText(LoginActivity.this,"获取地理位置权限失败",CustomToast.LENGTH_SHORT)
                            .show();
                }
            }
        });

    }

    //设置logo消失/出现的动画
    private void setAnimator(int type) {
        if (type == TYPE_DISAPPEAR) {
            startAlpha = 1f;
            translationY = getResources().getDimension(R.dimen.y360);
            state = TYPE_DISAPPEAR;
        }
        else {
            startAlpha = 0f;
            translationY = 0;
            state = TYPE_RESET;
        }

        ObjectAnimator alpha = ObjectAnimator.ofFloat(logo,"alpha",startAlpha,1f-startAlpha);
        alpha.setDuration(150);
        ObjectAnimator translateLogo = ObjectAnimator.ofFloat(logo,"translationY",logo.getTranslationY()
                ,-translationY);
        translateLogo.setDuration(150);
        ObjectAnimator translateR1 = ObjectAnimator.ofFloat(rlPhone,"translationY",rlPhone.getTranslationY(),
                -translationY);
        translateR1.setDuration(150);
        ObjectAnimator translateR2 = ObjectAnimator.ofFloat(rlPassword,"translationY",rlPassword.getTranslationY(),
                -translationY);
        translateR1.setDuration(150);
        ObjectAnimator translateBtn = ObjectAnimator.ofFloat(btnLogin,"translationY",btnLogin.getTranslationY(),
                -translationY);
        translateR1.setDuration(150);

        AnimatorSet set = new AnimatorSet();
        set.playTogether(alpha,translateLogo,translateR1,translateR2,translateBtn);
        set.start();
    }

    //设置焦事件
    private void setOnFocused(int focused) {
        if (focused == 0) {
            rlPhone.setBackground(getDrawable(R.drawable.shape_login_edittext_focused));
            rlPassword.setBackground(getDrawable(R.drawable.shape_login_edittext_unfocused));
        }
        else if (focused == 1){
            rlPhone.setBackground(getDrawable(R.drawable.shape_login_edittext_unfocused));
            rlPassword.setBackground(getDrawable(R.drawable.shape_login_edittext_focused));
        }
    }

    private void initTextSize() {
        btnLogin.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                sTvSize = btnLogin.getHeight()*RATIO;
                btnLogin.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                if(sTvSize!=-1.0f) {
                    LoginActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            btnLogin.setTextSize(TypedValue.COMPLEX_UNIT_PX,sTvSize);
                            etPhone.setTextSize(TypedValue.COMPLEX_UNIT_PX,sTvSize);
                            etPassword.setTextSize(TypedValue.COMPLEX_UNIT_PX,sTvSize);
                        }
                    });
                }
            }
        });
    }

}

