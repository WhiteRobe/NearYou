package edu.xd.jiaoyou.view.custom;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import edu.xd.jiaoyou.R;

/**
 * Created by ZhengXi on 2017/6/4.
 */

public class CustomDialog extends Dialog {

    private TextView tvTitle;
    private TextView tvMessage;
    private EditText etText;
    private Button btnYes;
    private Button btnNo;
    private CharSequence title;
    private CharSequence message;

    private OnYesClickListener onYesClickListener = null;
    private OnNoClickListener onNoClickListener = null;

    //默认样式
    public CustomDialog(Context context) {
        super(context);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.custom_dialog);
        setCanceledOnTouchOutside(false);//点击空白处不能取消

        tvTitle = (TextView) findViewById(R.id.title);
        tvMessage = (TextView) findViewById(R.id.message);
        if(title!=null)
            tvTitle.setText(title);
        if(message!=null)
            tvMessage.setText(message);
        etText = (EditText) findViewById(R.id.editText);
        btnYes = (Button) findViewById(R.id.yes);
        btnNo = (Button) findViewById(R.id.no);
        setOnClickEvent();
    }

    public void setTitle(CharSequence title) {
        this.title = title;
    }

    public void setMessage(CharSequence message) {
        this.message = message;
    }

    public CharSequence getTitle() {
        if(tvTitle!=null) return tvTitle.getText().toString();
        else return title;
    }

    public CharSequence getInput() {
        if (etText!=null) return etText.getText().toString();
        else return null;
    }

    public void setOnYesClickListener(OnYesClickListener onYesClickListener) {
        this.onYesClickListener = onYesClickListener;
    }

    public void setOnNoClickListener(OnNoClickListener onNoClickListener) {
        this.onNoClickListener = onNoClickListener;
    }

    public interface OnYesClickListener {
        void onYesClick();
    }

    public interface OnNoClickListener {
        void onNoClick();
    }

    private void setOnClickEvent() {
        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onNoClickListener!=null)
                    onNoClickListener.onNoClick();
            }
        });
        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onYesClickListener!=null)
                    onYesClickListener.onYesClick();
            }
        });
    }

}
