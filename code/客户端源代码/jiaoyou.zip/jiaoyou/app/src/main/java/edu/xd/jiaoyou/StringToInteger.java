package edu.xd.jiaoyou;

/**
 * Created by ZhengXi on 2017/6/19.
 */

public class StringToInteger {

    public static int StringToInteger(String str) {
        int i = -1;
        try {
            i = Integer.parseInt(str);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return i;
    }

    public static String IntegerToString(int i) {
        return String.valueOf(i);
    }
}
