package edu.xd.jiaoyou.view.main;

import java.io.Serializable;

/**
 * Created by ZhengXi on 2017/5/22.
 */

public class ChatMessageModel implements Serializable {

    private static final long serialVersionUID = 1L;

    public int userId = -1;      //用户id
    public String name = null;   //用户昵称/姓名
    public String profile = null;//头像路径
    public String brief = null;  //最后一个聊天记录的简略形式
    public String time = null;   //最后一次聊天的时间

    public ChatMessageModel(int userId, String name, String profile,String brief, String time) {
        this.userId = userId;
        this.name = name;
        this.profile = profile;
        this.brief = brief;
        this.time = time;
    }

    public boolean hasProfile() {
        if(profile==null || profile.equals("") || profile.equals("default_avatar.jpg")) return false;
        return true;
    }
}
