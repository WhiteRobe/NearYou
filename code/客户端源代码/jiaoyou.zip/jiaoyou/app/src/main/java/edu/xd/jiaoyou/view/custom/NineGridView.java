package edu.xd.jiaoyou.view.custom;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.util.List;

import edu.xd.jiaoyou.R;

/**
 * Created by ZhengXi on 2017/6/18.
 */
public class NineGridView extends ViewGroup {

    private int gap = 21;//默认间隔
    private int columns; //列
    private int rows;    //行
    private int maxWidth = 0;//控件最大宽度

    private int index = 0;//当前view index，用于设置点击事件时

    private OnItemClickListener onItemClickListener = null;

    public NineGridView(Context context) {
        super(context);
        gap = (int) context.getResources().getDimension(R.dimen.x21);
        maxWidth = (int) context.getResources().getDimension(R.dimen.x996);
    }

    public NineGridView(Context context, AttributeSet attrs) {
        super(context, attrs);
        gap = (int) context.getResources().getDimension(R.dimen.x21);
        maxWidth = (int) context.getResources().getDimension(R.dimen.x996);
    }

    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {}

    /**
     * 设置子view数目
     * @param count
     * @param width  当number==1时此属性才有效
     * @param height
     */
    public void onCreateView(final int count, int width, int height) {
        if(count > 9 || count < 0) {
            throw new IllegalArgumentException("the number of picture is must between 0 and 9");
        }

        //初始化行列数
        generateChildrenLayout(count);

        //添加子View到viewGroup中
        for (int i=0;i<count;i++) {
            index = i;
            ImageView childrenView = generateImageView();
            childrenView.setTag(R.id.NineGridChildrenId,i);
            childrenView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(onItemClickListener!=null)
                        onItemClickListener.onItemClick(v,(int) v.getTag(R.id.NineGridChildrenId));
                }
            });
            addView(childrenView, generateDefaultLayoutParams());
        }

        layoutChildrenView(count,width,height);
    }

    //为控件填充数据
    public void setImageFromUrl(List<String> urls) {
        for(int i=0;i<urls.size();i++) {
            ImageView childrenView = (ImageView) getChildAt(i);

            //java.lang.IllegalArgumentException: You must not call setTag() on a view Glide is targeting
            //因为Glide需要给imageView设置Tag，不能自己执行setTag的操作
            //1.设置 view.setTag(int,Object)
            //2.不使用 imageView做根布局
            Glide.with(getContext())
                    .load(urls.get(i))
                    .into(childrenView);
        }
    }

    //绘制每个子view在viewGroup中的位置
    private void layoutChildrenView(int count,int width,int height){
        //获取每个view的LayoutParams
        ViewGroup.LayoutParams params = getLayoutParams();

        if(count==1) {
            params.height = 0;
            setLayoutParams(params);
        }
        //只有一张图片
        //当图片宽度小于等于控件宽度时，原尺寸显示
        //当图片宽度大于控件宽度时，按控件宽度等比例缩放
        if(count==1) {
            ImageView childrenView = (GifImageView) getChildAt(0);

            if(width > maxWidth) {
                float ratio = (float) maxWidth/width;
                params.height = (int) (height * ratio);
                if((int) (height * ratio) > maxWidth) {//长图
                    ratio = (float) maxWidth/height;
                    params.width = (int) (width * ratio);
                    params.height = maxWidth;
                }
                setLayoutParams(params);
            }
            else {
                params.width = width;
                params.height = height;
                setLayoutParams(params);
            }
            childrenView.layout(0,0,params.width,params.height);
        }

        //多张图片，每张图片显示固定大小
        else {
            int singleWidth = (maxWidth - gap * (3 - 1)) / 3;
            int singleHeight = singleWidth;

            //根据子view数量确定宽高
            params.width = singleWidth * columns + gap * (columns -1);
            params.height = singleHeight * rows + gap * (rows - 1);
            setLayoutParams(params);

            for (int i = 0; i < count; i++) {
                ImageView childrenView = (GifImageView) getChildAt(i);

                int[] position = findPosition(i);
                int left = (singleWidth + gap) * position[1];
                int top = (singleHeight + gap) * position[0];
                int right = left + singleWidth;
                int bottom = top + singleHeight;

                childrenView.layout(left, top, right, bottom);
            }
        }

    }

    //为子view定位
    private int[] findPosition(int childNum) {
        int[] position = new int[2];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if ((i * columns + j) == childNum) {
                    position[0] = i;//行
                    position[1] = j;//列
                    break;
                }
            }
        }
        return position;
    }

    /**
     * 根据图片个数确定行列数量
     * 对应关系如下
     * num        row        column
     * 1           1        1
     * 2           1        2
     * 3           1        3
     * 4           2        2
     * 5           2        3
     * 6           2        3
     * 7           3        3
     * 8           3        3
     * 9           3        3
     *
     * @param length
     */
    private void generateChildrenLayout(int length) {
        if (length <= 3) {
            rows = 1;
            columns = length;
        } else if (length <= 6) {
            rows = 2;
            columns = 3;
            if (length == 4) {
                columns = 2;
            }
        } else {
            rows = 3;
            columns = 3;
        }
    }

    private ImageView generateImageView() {
        ImageView imageView = new GifImageView(getContext());
        imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        imageView.setBackgroundColor(getResources().getColor(R.color.colorBaseBackground));
        return imageView;
    }
}