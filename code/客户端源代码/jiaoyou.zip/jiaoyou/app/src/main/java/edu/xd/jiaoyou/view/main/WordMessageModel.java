package edu.xd.jiaoyou.view.main;

import java.io.Serializable;

/**
 * Created by ZhengXi on 2017/6/19.
 */

public class WordMessageModel implements Serializable {

    private static final long serialVersionUID = 1L;

    public int id = -1;          //评论/赞的动态的id
    public int userId = -1;      //用户id
    public String name = null;   //用户昵称/姓名
    public String profile = null;//头像路径
    public String time = null;   //评论/赞的时间
    public String brief = null;  //动态内容简略形式
    public String content = null;//评论/赞

    public WordMessageModel(int id,int userId, String name, String profile,String time,String brief,String content) {
        this.id = id;
        this.userId = -1;
        this.name = name;
        this.profile = profile;
        this.time = time;
        this.brief = brief;
        this.content = content;
    }

    public boolean hasProfile() {
        if(profile==null || profile.equals("") || profile.equals("default_avatar.jpg")) return false;
        return true;
    }
}
