package edu.xd.jiaoyou.view.photoviewer;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.view.CommonFragmentPagerAdapter;

/**
 * Created by ZhengXi on 2017/6/14.
 */

public class PhotoViewerActivity extends AppCompatActivity {

    public RelativeLayout mRelativeLayout;
    public Button btnBack;
    public TextView tvTitle;
    public Button btnFunction;

    private ViewPager mViewPager;
    private CommonFragmentPagerAdapter mAdapter;
    private List<Fragment> fragments;

    private int currentPage = 0;   //当前item，默认第一页
    private boolean enable = false;//能否触发长按事件，默认不能
    private List<String> images;   //图片路径

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);      //隐藏标题
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);//设置全屏
        setContentView(R.layout.activity_photoviewer);

        Intent intent = getIntent();
        currentPage = intent.getIntExtra("current_item",0);
        enable = intent.getBooleanExtra("onLongClickEnable",false);
        images = (List<String>) intent.getSerializableExtra("image_list");

        init();
    }

    private void init() {
        setOnClickEnable(enable);

        mRelativeLayout = (RelativeLayout) findViewById(R.id.toolbar_photoviewer);
        btnBack = (Button) findViewById(R.id.btn_back);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        tvTitle = (TextView) findViewById(R.id.textView_title);
        tvTitle.setText((currentPage+1)+"/"+images.size());
        btnFunction = (Button) findViewById(R.id.btn_function);

        mViewPager = (ViewPager) findViewById(R.id.viewpager_photoviewer);
        fragments = new ArrayList<>();

        for(int i=0;i<images.size();i++) {
            fragments.add(new PhotoViewerFragment().setImagePath(images.get(i)));
        }
        mAdapter = new CommonFragmentPagerAdapter(getSupportFragmentManager(),fragments);
        mViewPager.setAdapter(mAdapter);
        mViewPager.setCurrentItem(currentPage);

        //设置viewPager滑动监听，动态改变title
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {}

            @Override
            public void onPageSelected(int position) {
                tvTitle.setText((position+1)+"/"+images.size());
                currentPage = position;
            }

            @Override
            public void onPageScrollStateChanged(int state) {}
        });
    }

    @Override
    public void finish() {
        super.finish();
        for(int i=0;i<fragments.size();i++) {
            fragments.get(i).onDestroyView();
        }
        fragments = null;
    }

    //设置是否开启长按事件，默认false
    public void setOnClickEnable(boolean enable) {
        if (enable) {
            for (int i=0;i<fragments.size();i++) {
                ((PhotoViewerFragment) fragments.get(i)).setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        //保存图片
                        //saveImage();
                        return false;
                    }
                });
            }
        }
    }

    //保存指定位置的图片到 "/sdcard/MYclient/pictures/"
    private void saveImage() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                //不确定图片来源，使用Glide再加载一次
                Glide.with(PhotoViewerActivity.this)
                        .load(images.get(currentPage))
                        .asBitmap()
                        .into(new SimpleTarget<Bitmap>() {
                            @Override
                            public void onResourceReady(Bitmap resource, GlideAnimation glideAnimation) {
                            }
                        });

            }
        }).start();
    }

}
