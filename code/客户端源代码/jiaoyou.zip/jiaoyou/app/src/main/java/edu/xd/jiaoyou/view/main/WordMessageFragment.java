package edu.xd.jiaoyou.view.main;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.daimajia.swipe.SwipeLayout;

import org.json.JSONObject;

import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.custom.RecycleViewDivider;
import in.srain.cube.views.ptr.PtrClassicDefaultHeader;
import in.srain.cube.views.ptr.PtrDefaultHandler;
import in.srain.cube.views.ptr.PtrFrameLayout;

/**
 * Created by ZhengXi on 2017/6/19.
 */

public class WordMessageFragment extends Fragment {

    private DataService dataService = null;
    private UICallback uiCallback = null;

    private Context mContext;
    private View mView;
    private PtrFrameLayout mPtrFrameLayout = null;
    private RecyclerView mRecyclerView = null;
    private WordMessageAdapter mAdapter = null;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;

        uiCallback = new WordMessageFragment.UICallBack();
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(!((MainActivity) getActivity()).isConnected()) {}
                dataService = ((MainActivity) getActivity()).getDataService();
                dataService.setUICallback(uiCallback);
            }
        }).start();

        mAdapter = new WordMessageAdapter();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.pager_message_word,container,false);

        mPtrFrameLayout = (PtrFrameLayout) mView.findViewById(R.id.ptrLayout);
        PtrClassicDefaultHeader header = new PtrClassicDefaultHeader(mContext);
        mPtrFrameLayout.setHeaderView(header);
        mPtrFrameLayout.addPtrUIHandler(header);
        mPtrFrameLayout.setPtrHandler(new PtrDefaultHandler() {
            //刷新事件
            @Override
            public void onRefreshBegin(PtrFrameLayout frame) {
                loadServiceData();
            }
        });

        mRecyclerView = (RecyclerView) mView.findViewById(R.id.rcyView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mRecyclerView.addItemDecoration(new RecycleViewDivider(mContext));
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setAdapter(mAdapter);

        //loadLocalCache();
        return mView;
    }

    private void setOnClickEvent() {
        mAdapter.setOnItemClickListener(new WordMessageAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

            }
        });

        mAdapter.setOnItemLongClickListener(new WordMessageAdapter.OnItemLongClickListener() {
            @Override
            public void onItemLongClick(View view, int position) {

            }
        });
    }

    private void loadLocalCache() {
        mAdapter.add(Constant.AppData.wordMessages);
    }

    private void loadServiceData() {

    }

    private class UICallBack implements UICallback {
        @Override
        public void dealServerRes(JSONObject msgIn) {}

        @Override
        public void dealServerPush(JSONObject msgIn) {}

        @Override
        public void dealServerMessage(JSONObject msgIn) {}

        @Override
        public void localMsg(String msg) {}
    }
}
