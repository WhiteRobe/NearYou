package edu.xd.jiaoyou.view.main;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.view.CommonFragmentPagerAdapter;
import edu.xd.jiaoyou.view.custom.CircleImageView;
import edu.xd.jiaoyou.view.publish.PublishActivity;

/**
 * Created by ZhengXi on 2017/6/19.
 */

public class MomentFragment extends Fragment {

    public static final int STATE_DISAPPEAR = 0x0000; //fab消失
    public static final int STATE_COMMON    = 0x0001; //
    private float translationY; //平移距离
    private float startAlpha;   //动画起始alpha

    private View mView;
    private Button btnMine;
    private Button btnSearch;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    private CircleImageView fab;
    private FragmentPagerAdapter mAdapter = null;
    private NearbyMomentFragment nearbyMomentFragment = null;
    private FriendMomentFragment friendMomentFragment = null;
    private OnTitleClickListener onTitleClickListener = null;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        nearbyMomentFragment = new NearbyMomentFragment();
        friendMomentFragment = new FriendMomentFragment();
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(nearbyMomentFragment);
        fragments.add(friendMomentFragment);
        mAdapter = new CommonFragmentPagerAdapter(getChildFragmentManager(),fragments);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_main_moments,container,false);

        fab = (CircleImageView) mView.findViewById(R.id.fab_main_publish);

        btnMine = (Button) mView.findViewById(R.id.btn_main_mine);
        btnSearch = (Button) mView.findViewById(R.id.btn_main_search);

        mTabLayout = (TabLayout) mView.findViewById(R.id.tab_main);

        mViewPager = (ViewPager) mView.findViewById(R.id.viewPager_moments);
        mViewPager.setAdapter(mAdapter);
        mViewPager.addOnPageChangeListener(new TabLayoutOnPageChangeListener(mTabLayout));

        mTabLayout.addTab(mTabLayout.newTab().setText("附近"));
        mTabLayout.addTab(mTabLayout.newTab().setText("好友"));
        mTabLayout.addOnTabSelectedListener(new OnTabSelectedListener());

        setOnClickEvent();
        return mView;
    }

    //获取当前viewPager页面
    public int getCurrentPage() {
        int current = mViewPager.getCurrentItem();
        if (current == 0) return Constant.ViewTag.MOM_NEARBY_TAG;
        else if (current == 1) return Constant.ViewTag.MOM_FRIEND_TAG;
        return Constant.ViewTag.ERROR_TAG;
    }

    //toolbar点击事件
    public void setOnTitleClickListener(OnTitleClickListener onTitleClickListener) {
        this.onTitleClickListener = onTitleClickListener;
    }

    //设置fab动画
    public void setFabState(final int state) {
        if (state == STATE_DISAPPEAR) {
            startAlpha = 1f;
            translationY = fab.getResources().getDimension(R.dimen.y168);
        }
        else if (state == STATE_COMMON) {
            startAlpha = 0f;
            translationY = 0;
        }

        System.out.println("state:" + state);

        ObjectAnimator alpha = ObjectAnimator.ofFloat(fab,"alpha",startAlpha,1f-startAlpha);
        alpha.setDuration(150);
        ObjectAnimator translateY = ObjectAnimator.ofFloat(fab,"translationY",fab.getTranslationY(),
                -translationY);
        translateY.setDuration(150);
        //ObjectAnimator

        AnimatorSet set = new AnimatorSet();
        set.playTogether(alpha,translateY);
        /*set.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                if (state == STATE_DISAPPEAR && fab.getVisibility() == View.GONE)
                    fab.setVisibility(View.VISIBLE);
                else if (state == STATE_COMMON && fab.getVisibility() == View.VISIBLE)
                    fab.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (state == STATE_DISAPPEAR && fab.getVisibility() == View.GONE)
                    fab.setVisibility(View.GONE);
                else if (state == STATE_COMMON && fab.getVisibility() == View.VISIBLE)
                    fab.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationCancel(Animator animation) {}

            @Override
            public void onAnimationRepeat(Animator animation) {}
        });
        */
        //set.start();
        System.out.println("start");
    }

    //刷新事件
    public void autoRefresh() {
        int current = mViewPager.getCurrentItem();
        if (current == 0) nearbyMomentFragment.autoRefresh();
        else if (current == 1) friendMomentFragment.autoRefresh();
    }

    //设置view点击事件
    private void setOnClickEvent() {
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mView.getContext(), PublishActivity.class);
                startActivity(intent);
            }
        });
        btnMine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onTitleClickListener!=null)
                    onTitleClickListener.onTitleClick(v,v.getId());
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onTitleClickListener!=null)
                    onTitleClickListener.onTitleClick(v,v.getId());
            }
        });
    }

    //tab监听viewPager滑动事件
    private class TabLayoutOnPageChangeListener extends TabLayout.TabLayoutOnPageChangeListener {
        public TabLayoutOnPageChangeListener(TabLayout tabLayout) {
            super(tabLayout);
        }

        @Override
        public void onPageSelected(int position) {

        }
    }

    //tab选中事件
    private class OnTabSelectedListener implements TabLayout.OnTabSelectedListener {
        @Override
        public void onTabSelected(TabLayout.Tab tab) {
            mViewPager.setCurrentItem(tab.getPosition());
        }
        @Override
        public void onTabUnselected(TabLayout.Tab tab) {}
        @Override
        public void onTabReselected(TabLayout.Tab tab) {}
    }
}
