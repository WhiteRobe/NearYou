package edu.xd.jiaoyou.view;

import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;

import org.json.JSONException;
import org.json.JSONObject;

import edu.xd.jiaoyou.BaseApplication;
import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.InfoValue;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.tools.ToSpellString;
import edu.xd.jiaoyou.view.custom.CustomDialog;
import edu.xd.jiaoyou.view.custom.CustomToast;
import edu.xd.jiaoyou.view.custom.InfoItemButton;
import edu.xd.jiaoyou.view.main.MainActivity;
import github.imageselector.ImageConfig;
import github.imageselector.ImageSelector;
import github.imageselector.ImageSelectorActivity;

/**
 * Created by ZhengXi on 2017/6/3.
 */

public class UserInfoActivity extends AppCompatActivity implements View.OnClickListener{

    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;
    private UICallback uiCallback=new UICallback() {
        @Override
        public void dealServerRes(JSONObject msgIn) {
            try {
                JSONObject res = msgIn.getJSONObject("Data");
                JSONObject value = res.getJSONObject("Value");
                //获取相应资料
                data.put(0,value.getString("RealName"));
                data.put(1,value.getString("NickName"));
                data.put(2,value.getString("Sex"));
                data.put(4,value.getString("Birth"));
                data.put(5,value.getString("Education"));
                data.put(6,value.getString("School"));
                data.put(7,value.getString("Address"));
                data.put(8,value.getString("Phone"));
                data.put(9,value.getString("Email"));
                servicePath = Constant.SERVICE_IP+"/avatar/"+value.getString("Id")+"_avatar";

                //更新UI
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        int i=0;
                        for(;i<3;i++) {
                            loadDataIntoView(i,data.get(i));
                        }
                        for(i=4;i<=data.size();i++) {
                            loadDataIntoView(i,data.get(i));
                        }
                        //尝试加载头像，无法确定是否有头像
                        Glide.with(UserInfoActivity.this)
                                .load(servicePath)
                                .asBitmap()
                                .error(R.color.dark_gray)
                                .into(new SimpleTarget<Bitmap>() {
                                    @Override
                                    public void onResourceReady(Bitmap resource, GlideAnimation<? super Bitmap> glideAnimation) {
                                        if (resource!=null) {
                                            System.out.println("set begin");
                                            btnProfile.setImageBitmap(resource);
                                            System.out.println("set finish");
                                        }
                                    }
                                });
                    }
                });
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void dealServerPush(JSONObject msgIn) {
            String response = null;
            try {
                JSONObject data = msgIn.getJSONObject("Data");
                response = data.getString("Class");
            } catch (JSONException e){
                e.printStackTrace();
            }
            if(response.equals(InfoValue.MsgPush.UpdataSuccess)) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        //更新配置文件
                        SharedPreferences p1 = getSharedPreferences("NewAccount",MODE_PRIVATE);
                        SharedPreferences.Editor e1 = p1.edit();
                        e1.putBoolean("isNew",false);
                        e1.commit();
                        SharedPreferences p2 = getSharedPreferences("Account",MODE_APPEND);
                        SharedPreferences.Editor e2 = p2.edit();
                        e2.putString("userName",data.get(0).toString());
                        e2.putString("profilePath",servicePath);
                        e2.commit();
                        System.out.println("update success");
                        CustomToast.makeText(UserInfoActivity.this,"更新成功",
                                CustomToast.LENGTH_SHORT).show();
                    }
                });
            }
        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {}

        @Override
        public void localMsg(String msg) {}
    };
    private ServiceConnection connection=new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
            dataService.setUICallback(uiCallback);
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };

    private static final String HEAD = "请填写你的";
    private static final String TAIL = ",此信息将展示在你的个人资料中。";
    private String[] itemMessage = {"姓名","昵称","性别","生日","学历","学校",
            "地址","手机号","邮箱"};

    private Button btnBack;
    private Button btnSave;
    private TextView tvTitle;
    private InfoItemButton btnName;
    private InfoItemButton btnNick;
    private InfoItemButton btnSex;
    private InfoItemButton btnProfile;
    private InfoItemButton btnBirthday;
    private InfoItemButton btnEducation;
    private InfoItemButton btnSchool;
    private InfoItemButton btnLocation;
    private InfoItemButton btnPhone;
    private InfoItemButton btnEmai;
    private Dialog mDialog;

    private SparseArray<CharSequence> data = null;
    private String localPath;//本地头像的path
    private String servicePath; //服务器上的头像
    private Bitmap profile; //头像
    private int userId = -1;
    private boolean isNewAccount = true; //判断是否为新用户
    private boolean isMySelf = false; //是否为自己
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userinfo);

        Intent bindIntent = new Intent(UserInfoActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        Intent intent = getIntent();
        userId = intent.getIntExtra("userId",-1);
        System.out.println("userInfo:"+userId);

        //判断是否为新用户,更新过信息之后，会将此值设为false
        SharedPreferences preferences = getSharedPreferences("NewAccount",MODE_PRIVATE);
        isNewAccount = preferences.getBoolean("isNew",true);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (dataService==null) {}
                dataService.setUICallback(uiCallback);
                if (String.valueOf(userId).equals(dataService.getUserID())) {
                    isMySelf = true;
                }
            }
        }).start();

        initView();
        initData();
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(UserInfoActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    @Override
    public void onDestroy() {
        if (profile!=null) {
            profile.recycle();
            profile = null;
        }
        unbindService(connection);
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ImageSelector.IMAGE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            //path = data.getStringExtra(ImageSelectorActivity.EXTRA_RESULT);
            localPath = data.getStringArrayListExtra(ImageSelectorActivity.EXTRA_RESULT).get(0);
            profile = BitmapFactory.decodeFile(localPath);
            btnProfile.setImageBitmap(profile);
        }
    }

    private void initView() {
        btnBack = (Button) findViewById(R.id.btn_back);
        btnBack.setOnClickListener(this);
        btnSave = (Button) findViewById(R.id.btn_function);
        btnSave.setBackground(getDrawable(R.drawable.save));
        btnSave.setOnClickListener(this);
        tvTitle = (TextView) findViewById(R.id.textView_title);
        tvTitle.setText("个人资料");
        btnName = (InfoItemButton) findViewById(R.id.btn_name);
        btnName.setOnClickListener(this);
        btnName.setTag(0);
        btnNick = (InfoItemButton) findViewById(R.id.btn_nick);
        btnNick.setOnClickListener(this);
        btnNick.setTag(1);
        btnSex = (InfoItemButton) findViewById(R.id.btn_sex);
        btnSex.setOnClickListener(this);
        btnSex.setTag(2);
        btnProfile = (InfoItemButton) findViewById(R.id.btn_profile);
        btnProfile.setOnClickListener(this);
        btnProfile.setTag(3);
        btnBirthday = (InfoItemButton) findViewById(R.id.btn_birthday);
        btnBirthday.setOnClickListener(this);
        btnBirthday.setTag(4);
        btnEducation = (InfoItemButton) findViewById(R.id.btn_education);
        btnEducation.setOnClickListener(this);
        btnEducation.setTag(5);
        btnSchool = (InfoItemButton) findViewById(R.id.btn_school);
        btnSchool.setOnClickListener(this);
        btnSchool.setTag(6);
        btnLocation= (InfoItemButton) findViewById(R.id.btn_location);
        btnLocation.setOnClickListener(this);
        btnLocation.setTag(7);
        btnPhone = (InfoItemButton) findViewById(R.id.btn_phone);
        btnPhone.setOnClickListener(this);
        btnPhone.setTag(8);
        btnEmai = (InfoItemButton) findViewById(R.id.btn_email);
        btnEmai.setOnClickListener(this);
        btnEmai.setTag(9);

        mDialog = new Dialog();
    }

    //初始化data
    private void initData() {
        data = new SparseArray<>();
        if (isNewAccount && isMySelf) {
            data.put(0,"  ");
            data.put(1,"  ");
            data.put(2,"  ");
            data.put(4,"  ");
            data.put(5,"  ");
            data.put(6,"  ");
            data.put(7,"  ");
            data.put(8,"  ");
            data.put(9,"  ");
            int i=0;
            for(;i<3;i++) {
                loadDataIntoView(i,data.get(i));
            }
            for(i=4;i<=data.size();i++) {
                loadDataIntoView(i,data.get(i));
            }

            DialogOnClickListener listener = new DialogOnClickListener();
            new AlertDialog.Builder(UserInfoActivity.this,
                    android.R.style.Theme_Material_Light_Dialog_Alert)
                    .setTitle("提示")
                    .setMessage("为了得到更好的体验，请在使用此APP之前完善自己的个人信息。")
                    .setNegativeButton("暂不",listener)
                    .setPositiveButton("好的",listener)
                    .setCancelable(false)
                    .show();
        }
        else {
            CustomToast.makeText(UserInfoActivity.this,"同步资料中",CustomToast.LENGTH_SHORT).show();
            //向服务器发送获取自己资料的请求
            new Thread(new Runnable() {
                @Override
                public void run() {
                    while (dataService==null){}
                    dataService.searchFriendsByid(String.valueOf(userId));
                }
            }).start();
        }
    }

    //生成用于返回给服务器的json
    private JSONObject toJSON() {
        JSONObject msgOut = new JSONObject();
        try{
            msgOut.put("MsgType", InfoValue.MsgType.ALTER_PROFILE);
            msgOut.put("MsgId",dataService.getMID());
            msgOut.put("UID",dataService.getUserID());
            JSONObject js = new JSONObject();
            js.put("NickName",data.get(1));
            js.put("Note","该用户什么也没说");
            js.put("Hobby","无");
            js.put("Master","无");
            js.put("Learning","无");
            js.put("Country","中国");
            js.put("Province","北京");
            js.put("City","朝阳区");
            js.put("Address",data.get(7));
            //js.put("Adcode",dataService.getGdMap().getAdCode()+"");
            js.put("Adcode","123");
            js.put("LocPrivacy","false");
            js.put("School",data.get(6));
            js.put("Organization","未填写");
            js.put("Education",data.get(5));
            js.put("JobPrivacy","false");
            js.put("RealName",data.get(0));
            js.put("Birth",data.get(4));
            js.put("Phone",data.get(8));
            js.put("Email",data.get(9));
            js.put("Sex",data.get(2));
            js.put("IndiPrivacy","false");
            js.put("FirstLt", ToSpellString.getFirstLetter(data.get(0).toString())+"");
            if(localPath==null || localPath.equals("  ")) js.put("UpdataAvatar","false");
            else{
                js.put("UpdataAvatar","true");//or"false"
                js.put("Type",localPath.substring(localPath.indexOf(".")));//这是图片的名字
            }
            msgOut.put("Data",js);
        }catch (Exception e) {
            e.printStackTrace();
        }
        return msgOut;
    }

    //根据tag将数据装入view中
    private void loadDataIntoView(int tag,CharSequence text) {
        switch (tag) {
            case 0:
                btnName.setText(text);
                break;
            case 1:
                btnNick.setText(text);
                break;
            case 2:
                btnSex.setText(text);
                break;
            case 4:
                btnBirthday.setText(text);
                break;
            case 5:
                btnEducation.setText(text);
                break;
            case 6:
                btnSchool.setText(text);
                break;
            case 7:
                btnLocation.setText(text);
                break;
            case 8:
                btnPhone.setText(text);
                break;
            case 9:
                btnEmai.setText(text);
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_back:
                onBackPressed();
                break;
            case R.id.btn_function:
                dataService.sendProfile(toJSON(),localPath);
                break;
            case R.id.btn_name:
                mDialog.setText(btnName.getTitle(),HEAD+itemMessage[0]+TAIL);
                mDialog.setTag((int) btnName.getTag());
                mDialog.show();
                break;
            case R.id.btn_nick:
                mDialog.setText(btnNick.getTitle(),HEAD+itemMessage[1]+TAIL);
                mDialog.setTag((int) btnNick.getTag());
                mDialog.show();
                break;
            case R.id.btn_sex:
                mDialog.setText(btnSex.getTitle(),HEAD+itemMessage[2]+TAIL);
                mDialog.setTag((int) btnSex.getTag());
                mDialog.show();
                break;
            case R.id.btn_profile:
                ImageConfig config = ((BaseApplication) getApplication()).getSingleSelect();
                ImageSelector.open(UserInfoActivity.this,config);
                break;
            case R.id.btn_birthday:
                mDialog.setText(btnBirthday.getTitle(),HEAD+itemMessage[3]+TAIL);
                mDialog.setTag((int) btnBirthday.getTag());
                mDialog.show();
                break;
            case R.id.btn_education:
                mDialog.setText(btnEducation.getTitle(),HEAD+itemMessage[4]+TAIL);
                mDialog.setTag((int) btnEducation.getTag());
                mDialog.show();
                break;
            case R.id.btn_school:
                mDialog.setText(btnSchool.getTitle(),HEAD+itemMessage[5]+TAIL);
                mDialog.setTag((int) btnSchool.getTag());
                mDialog.show();
                break;
            case R.id.btn_location:
                mDialog.setText(btnLocation.getTitle(),HEAD+itemMessage[6]+TAIL);
                mDialog.setTag((int) btnLocation.getTag());
                mDialog.show();
                break;
            case R.id.btn_phone:
                mDialog.setText(btnPhone.getTitle(),HEAD+itemMessage[7]+TAIL);
                mDialog.setTag((int) btnPhone.getTag());
                mDialog.show();
                break;
            case R.id.btn_email:
                mDialog.setText(btnEmai.getTitle(),HEAD+itemMessage[8]+TAIL);
                mDialog.setTag((int) btnEmai.getTag());
                mDialog.show();
                break;
        }
    }

    /**
     * 内部管理CustomDialog对象
     * 避免每次实例化CustomDialog对象时都要实现其OnYesClickListener,OnNoClickListener接口
     * 另一种解决方式是动态添加View到dialog中，实现其实例化之后的动态更新
     */
    private class Dialog implements CustomDialog.OnYesClickListener,CustomDialog.OnNoClickListener {

        private CustomDialog mDialog = null;
        private int tag = -1;

        //保存响应点击事件的view的tag
        public void setTag(int tag) {
            this.tag = tag;
        }

        public void setText(CharSequence title,CharSequence message) {
            mDialog = new CustomDialog(UserInfoActivity.this);
            mDialog.setTitle(title);
            mDialog.setMessage(message);
            mDialog.setOnYesClickListener(this);
            mDialog.setOnNoClickListener(this);
        }

        public void show() {
            mDialog.show();
        }

        @Override
        public void onYesClick() {
            CharSequence input = mDialog.getInput();
            data.put(tag,input);//修改data中的数据
            loadDataIntoView(tag,input);//将修改后的内容加载到view上
            mDialog.dismiss();
        }

        @Override
        public void onNoClick() {
            mDialog.dismiss();//mDialog.cancel()方法与dismiss()方法的区别？
        }
    }

    //
    private class DialogOnClickListener implements DialogInterface.OnClickListener {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            if (which == DialogInterface.BUTTON_POSITIVE)
                dialog.dismiss();
            else if (which == DialogInterface.BUTTON_NEGATIVE) {
                Intent intent = new Intent(UserInfoActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }
}
