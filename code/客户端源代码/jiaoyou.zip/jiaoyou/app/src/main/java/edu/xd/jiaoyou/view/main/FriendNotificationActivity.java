package edu.xd.jiaoyou.view.main;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import edu.xd.jiaoyou.R;

/**
 * Created by ZhengXi on 2017/6/20.
 */

public class FriendNotificationActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friendnotification);
    }
}
