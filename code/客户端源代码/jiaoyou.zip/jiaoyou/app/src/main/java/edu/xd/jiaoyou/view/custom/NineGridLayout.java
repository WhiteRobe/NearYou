package edu.xd.jiaoyou.view.custom;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.List;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.Image;


/**
 * Created by ZhengXi on 2017/6/12.
 */

/**
 * 此项目中图片仅由代码动态加载，故未考虑xml文件中的属性
 */
@Deprecated
public class NineGridLayout extends ViewGroup {

    private int gap = 21;//默认间隔
    private int columns; //列数
    private int rows;    //行数
    private List<Image> images; //图片数据
    private int maxWidth;  //控件最大宽度 （=高)

    private OnItemClickListener onItemClickListener = null;

    public NineGridLayout(Context context) {
        super(context);
        gap = (int) context.getResources().getDimension(R.dimen.x21);
    }

    public NineGridLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        gap = (int) context.getResources().getDimension(R.dimen.x21);
    }

    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }
    
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {}

    //绘制每个子view在viewGroup中的位置
    private void layoutChildrenView(){
        int childrenCount = images.size();

        //获取每个view的LayoutParams
        ViewGroup.LayoutParams params = getLayoutParams();
        maxWidth = params.width;

        //只有一张图片
        //当图片宽度小于等于控件宽度时，原尺寸显示
        //当图片宽度大于控件宽度时，按控件宽度等比例缩放
        if(childrenCount==1) {
            GifImageView childrenView = (GifImageView) getChildAt(0);
            Image image = images.get(0);
            childrenView.setImage(image);

            if(image.width > maxWidth) {
                float ratio = (float) maxWidth/image.width;
                params.height = (int) (image.height * ratio);
                setLayoutParams(params);
            }
            else {
                //为了保持控件大小不变，更改view的填充方式
                //childrenView.setScaleType(ImageView.ScaleType.FIT_START);

                //先采用控件和图片等大的方式
                params.width = image.width;
                params.height = image.height;
                setLayoutParams(params);
            }
            childrenView.layout(0,0,params.width,params.height);
        }

        //多张图片，每张图片显示固定大小
        else {
            int singleWidth = (maxWidth - gap * (3 - 1)) / 3;
            int singleHeight = singleWidth;

            //根据子view数量确定/*宽度*/和高度
            //params.width = singleWidth * columns + gap * (columns -1);
            params.height = singleHeight * rows + gap * (rows - 1);
            setLayoutParams(params);

            for (int i = 0; i < childrenCount; i++) {
                GifImageView childrenView = (GifImageView) getChildAt(i);
                childrenView.setImage(images.get(i));

                int[] position = findPosition(i);
                int left = (singleWidth + gap) * position[1];
                int top = (singleHeight + gap) * position[0];
                int right = left + singleWidth;
                int bottom = top + singleHeight;

                childrenView.layout(left, top, right, bottom);
            }
        }

    }

    //为子view定位
    private int[] findPosition(int childNum) {
        int[] position = new int[2];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if ((i * columns + j) == childNum) {
                    position[0] = i;//行
                    position[1] = j;//列
                    break;
                }
            }
        }
        return position;
    }

    //获取间距
    public int getGap() {
        return gap;
    }

    //设置间距
    public void setGap(int gap) {
        this.gap = gap;
    }

    //为控件填充数据
    public void setImages(List<Image> list) {
        if (list == null || list.isEmpty()) {
            return;
        }
        if(list.size()>9) {
            throw new IllegalArgumentException("the number of picture is must between 1 and 9");
        }
        //初始化布局
        generateChildrenLayout(list.size());

        //添加子view及其LayoutParams到viewGroup中
        for (int i=0;i<list.size();i++) {
            GifImageView giv = generateImageView();
            giv.setTag(i);
            giv.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(onItemClickListener!=null)
                        onItemClickListener.onItemClick(v,(int) v.getTag());
                }
            });
            addView(giv, generateDefaultLayoutParams());
        }
        this.images = list;
        layoutChildrenView();
    }

    public void recycle() {
        for(int i=0;i<images.size();i++) {
            ((GifImageView) getChildAt(i)).recycle();
        }
    }

    /**
     * 根据图片个数确定行列数量
     * 对应关系如下
     * num        row        column
     * 1           1        1
     * 2           1        2
     * 3           1        3
     * 4           2        2
     * 5           2        3
     * 6           2        3
     * 7           3        3
     * 8           3        3
     * 9           3        3
     *
     * @param length
     */
    private void generateChildrenLayout(int length) {
        if (length <= 3) {
            rows = 1;
            columns = length;
        } else if (length <= 6) {
            rows = 2;
            columns = 3;
            if (length == 4) {
                columns = 2;
            }
        } else {
            rows = 3;
            columns = 3;
        }
    }

    private GifImageView generateImageView() {
        GifImageView giv = new GifImageView(getContext());
        giv.setScaleType(ImageView.ScaleType.FIT_XY);
        giv.setBackgroundColor(getResources().getColor(R.color.colorBaseBackground));
        return giv;
    }
}