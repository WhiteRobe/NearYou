package edu.xd.jiaoyou.data;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Binder;
import android.os.IBinder;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.tools.MessageTool;
import edu.xd.jiaoyou.tools.TimeManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.security.KeyStore;
import java.util.List;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;

/**
 * -Version 1.0
 * -2017.6.23
 * -create by dai
 */
public class DataService extends Service {
    private ServiceBinder serviceBinder=new ServiceBinder();
    private UICallback uiCallback=null;

    public class ServiceBinder extends Binder {
        public DataService getDataService(){
            return DataService.this;
        }
    }
    public void setUICallback(UICallback UICALLBACK){
        this.uiCallback=UICALLBACK;
    }

    //---------Handler-----------//
    //private Handler msgOutHandler=new Handler();

    //---------交互操作函数--------//
    //脸部确认成功，可登陆
    public void faceCheked(String id,String pw){
        userID=id;userPw=pw;
        wirteKeyDB(id,pw);
    }
    //发送登陆信息
    public boolean login(String id,String pw){
        if(!isGaodeSDKAvaliable())return false;
        JSONObject msgOut=MessageTool.mkLoginJSMsg(id,pw,getMID(),gd);
        sendJsonMsg(msgOut);
        return true;
    }
    //发送注册信息
    public boolean register(String id,String pw){
        if(!isGaodeSDKAvaliable())return false;
        JSONObject msgOut=MessageTool.mkRegisterJSMsg(id,pw,getMID(),gd);
        sendJsonMsg(msgOut);
        return true;
    }
    //发送更改密码请求
    public boolean resetPW(String oldPW,String newPW){
        userPw=newPW;
        JSONObject msgOut=MessageTool.mkResetPWJSMsg(userID,getMID(),oldPW,newPW);
        sendJsonMsg(msgOut);
        return true;
    }
    //发送文本消息
    public boolean sendTxtMessage(String targetId,String text){
        if(!isGaodeSDKAvaliable())return false;
        JSONObject msgOut=MessageTool.mkMessageJSMsg(userID,targetId,getMID(),"TXT",".txt",text,gd);
        sendJsonMsg(msgOut);
        return true;
    }
    //发送图片消息
    public boolean sendPicMessage(String targetId,String picURL){
        String filename=new File(picURL).getName();//不检查picURL是否合法了，前台控制
        sendFile(picURL);//发送图片到服务器
        if(!isGaodeSDKAvaliable())return false;
        JSONObject msgOut=MessageTool.mkMessageJSMsg(userID,targetId,getMID(),"PIC",MessageTool.getType(filename),TimeManager.getTimeSys(),gd);
        sendJsonMsg(msgOut);
        return true;
    }
    //发送任意多媒体文件消息
    public boolean sendMediaMessage(String targetId,String fileURL,String fileType){
        String filename=new File(fileURL).getName();//不检查picURL是否合法了，前台控制
        sendFile(fileURL);//发送文件到服务器
        if(!isGaodeSDKAvaliable())return false;
        JSONObject msgOut=MessageTool.mkMessageJSMsg(userID,targetId,getMID(),fileType,MessageTool.getType(filename),TimeManager.getTimeSys(),gd);
        sendJsonMsg(msgOut);
        return true;
    }
    //通过好友id查询用户
    public boolean searchFriendsByid(String targetId){
        JSONObject msgOut=MessageTool.mkSearchFriensByIdJSMsg(userID,targetId,getMID());
        sendJsonMsg(msgOut);
        return true;
    }
    //通过好友昵称查询用户
    public boolean searchFriendsByNickname(int begin,String nickname){
        JSONObject msgOut=MessageTool.mkSearchFriensByNicknameJSMsg(begin,userID,nickname,getMID());
        sendJsonMsg(msgOut);
        return true;
    }
    //通过附近信息查询用户
    public boolean searchFriendsNearby(int begin){
        if(!isGaodeSDKAvaliable())return false;
        JSONObject msgOut=MessageTool.mkSearchFriensNearbyJSMsg(begin,userID,gd.getAdCode()+"",getMID());
        sendJsonMsg(msgOut);
        return true;
    }
    //获取附近动态
    public boolean getMomentsNearby(int begin){
        if(!isGaodeSDKAvaliable())return false;
        JSONObject msgOut=MessageTool.mkGetMomentsNearbyJSMsg(begin,userID,gd.getAdCode()+"",getMID());
        sendJsonMsg(msgOut);
        return true;
    }
    //获取所有好友的动态，但服务器未实现
    public boolean getMomentsByFriends(String targetId){
        JSONObject msgOut=MessageTool.mkGetMomentsFriendsJSMsg(userID,getMID());
        sendJsonMsg(msgOut);
        return true;
    }
    //获取特定用户动态-最多五条
    public boolean getMomentsByid(String targetId){
        JSONObject msgOut=MessageTool.mkGetMomentsByidJSMsg(userID,targetId,getMID());
        sendJsonMsg(msgOut);
        return true;
    }
    //发送动态 带多张图片
    public boolean sendMomentWithMultiPic(List<String> picURLs, int picNum, String text, boolean privacy){
        if(!isGaodeSDKAvaliable())return false;
        JSONObject msgOut=MessageTool.mkMommentJSMsg(userID,getMID(),text,privacy,picNum,".mulit",gd);
        sendJsonMsg(msgOut);
        for(String picURL:picURLs){
            if(picURL!=null){
                sendFile(picURL);
            }
        }
        System.out.println("DLog:多张图片发送完毕");
        return true;
    }
    //发送动态 带一张图片
    public boolean sendMomentWithPic(String picURL,String text,boolean privacy){
        String fileName=null;
        if(picURL!=null){
            File file=new File(picURL);
            sendFile(picURL);
            fileName=file.getName();
        }
        if(!isGaodeSDKAvaliable())return false;
        JSONObject msgOut=MessageTool.mkMommentJSMsg(userID,getMID(),text,privacy,1,MessageTool.getType(fileName),gd);
        sendJsonMsg(msgOut);
        return true;
    }
    //发送动态 不带图片
    public boolean sendMomentWithoutPic(String text,boolean privacy){
        if(!isGaodeSDKAvaliable())return false;
        JSONObject msgOut=MessageTool.mkMommentJSMsg(userID,getMID(),text,privacy,0,null,gd);
        sendJsonMsg(msgOut);
        return true;
    }
    //发送动态评论
    public boolean sendComment(int momentId,String userId,String text,boolean privacy){
        if(!isGaodeSDKAvaliable())return false;
        JSONObject msgOut=MessageTool.mkCommentJSMsg(momentId,userId,getMID(),text,privacy,gd);
        sendJsonMsg(msgOut);
        return true;
    }
    //更新个人资料
    public boolean sendProfile(JSONObject msgOut,String picURL){
        sendJsonMsg(msgOut);
        if(picURL!=null){
            sendFile(picURL);
        }
        return true;
    }
    //发送添加好友请求
    public boolean sendAddFriendJs(String targetId,String brief,boolean isLike){
        JSONObject msgOut=MessageTool.mkAddFRriendMsg(userID,targetId,nickName,brief,getMID());
        sendJsonMsg(msgOut);
        return true;
    }
    //为某条动态点赞
    public boolean sendMomentLike(String targetId,String moment_no,boolean isLike){
        JSONObject msgOut=MessageTool.mkMomentLikeMsg(userID,targetId,nickName,isLike,moment_no,getMID());
        sendJsonMsg(msgOut);
        return true;
    }
    //发送下线消息
    public boolean sendOfflineMsg(){
        JSONObject msgOut=MessageTool.mkOfflineJSMsg(userID,getMID());
        sendJsonMsg(msgOut);
        userID=InfoValue.PackageConstants.CLIENT_ID;
        userPw="000000";
        nickName=InfoValue.PackageConstants.CLIENT_ID;
        return true;
    }

    //清空Cache文件夹
    public boolean clearAllCache(){
        try{
            String url=rootURL+"Cache/";
            File dirUrl=new File(url);
            if(!dirUrl.exists()){
                System.out.println("DLog:Cache 文件夹不存在");
            }else{
                deleteDir(dirUrl);
            }
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("DLog:清空All Cache文件夹失败");
            return false;
        }
        createCacheDir();
        return true;
    }

    //获取当前用户名
    public String getUserID(){
        return userID;
    }
    //获取当前用户昵称
    public String getNickName(){
        return nickName;
    }
    //获取消息序号
    private int autoIncNum=0;
    public String getMID(){
        if(autoIncNum>65535){
            autoIncNum=0;
        }
        autoIncNum++;
        return autoIncNum+"";
    }

    //---------DataBase--------//
    private String userID=InfoValue.PackageConstants.CLIENT_ID;
    private String userPw="000000";
    private String nickName=InfoValue.PackageConstants.CLIENT_ID;
    private SQLiteDatabase userDB;
    //建立本地秘钥库
    private boolean tryToReachKeyDB(){
        SQLiteDatabase keyDB = openOrCreateDatabase("key.db", Context.MODE_PRIVATE, null);
        if(keyDB.isOpen()){
            //keyDB.execSQL("DROP TABLE if not EXISTS localkey");
            try{
                //若是第一次启动，则创建这些库
                keyDB.execSQL("create table localkey (id varchar(31) not null primary key,password varchar(21) not null );");
            }catch (Exception e){
                System.out.println("DLog:本地秘钥库已存在");
            }
            //keyDB.execSQL("insert into localkey (id,password) values(?,?);",new String[]{"dai","800708"});//输入测试
            String[] selectionArgs={};
            Cursor c=keyDB.rawQuery("select * from localkey;",selectionArgs);
            if(c.moveToFirst()){
                //only one data
                System.out.println("DLog:找到本地秘钥数据");
                /*userID=c.getString(c.getColumnIndex("id"));
                userPw=c.getString(c.getColumnIndex("password"));
                System.out.println(userID+":"+userPw);*/
                System.out.println("DLog:秘钥库里共有："+c.getCount()+"条数据");
                return true;
            }
            else {
                System.out.println("DLog:本地秘钥数据为空");
            }
        }
        else {
            System.out.println("DLog:本地秘钥库打开失败");
        }
        keyDB.close();
        return false;
    }
    //登陆成功，向数据库里写数据
    private boolean wirteKeyDB(String id,String pw){
        SQLiteDatabase keyDB = openOrCreateDatabase("key.db", Context.MODE_PRIVATE, null);
        if(keyDB.isOpen()){
            try{
                keyDB.execSQL("insert into localkey (id,password) values(?,?);",new String[]{id,pw});
            }catch (Exception e){}
            finally {
                userID=id;
                userPw=pw;
            }
        }
        else {
            System.out.println("DLog:本地秘钥库登陆失败");
        }
        keyDB.close();
        tryToReachUserDB();//登陆并创建用户数据库
        initUIDDir();//创建用户文件夹
        return false;
    }
    //重置本地秘钥库里的秘钥 重置密码的组件
    private void resetLocalKey(){
        SQLiteDatabase keyDB = openOrCreateDatabase("key.db", Context.MODE_PRIVATE, null);
        keyDB.execSQL("update localkey set password='"+userPw+"' where id='"+userID+"';");
        keyDB.close();
    }
    //写入 聊天记录 数据库
    private void writeRecord(JSONObject data,String sourceUID){
        if(userDB.isOpen()){
            try{
                String[] sql=new String[]{sourceUID,data.getString("Class"),data.getString("type"),data.getString("Address"),data.getString("Value"),data.getString("Time"),data.getString("Day")};
                userDB.execSQL("insert into record (id,class,type,address,text,time,date) values(?,?,?,?,?,?,?);",sql);
            }catch (Exception e){
                System.out.println("DLog:写入Record失败");
            }
        }
        else {
            System.out.println("DLog:用户数据库未打开");
        }
    }
    //写入 好友列表 数据库
    private void writeFriends(JSONObject data){
        if(userDB.isOpen()){
            try{
                JSONObject value=data.getJSONObject("Value");
                String id=value.getString("Id");
                String[] sql=new String[]{id,id,"/sdcrad/Myapp/default_avatar.jpg"};
                userDB.execSQL("insert into friends (id,remark,avatar) values(?,?,?);",sql);
            }catch (Exception e){
                System.out.println("DLog:写入Freind失败");
            }
        }
        else {
            System.out.println("DLog:用户数据库未打开");
        }
    }
    //建立本地数据库
    private boolean tryToReachUserDB(){
        userDB = openOrCreateDatabase(userID+".db",Context.MODE_PRIVATE, null);
        try{
            userDB.execSQL("create table friends (" +
                    "id varchar(31) not null primary key," +
                    "remark varchar(21) character set utf8," +
                    "avatar varchar(100) default '/sdcrad/Myapp/default_avatar.jpg'"+
                    ");");
        }catch (Exception e){}
        try{
            userDB.execSQL("create table blacklist (id varchar(31) not null primary key);");
        }catch (Exception e){}
        try{
            userDB.execSQL("create table record (" +
                    "id varchar(31) not null primary key," +
                    "class varchar(10) not null," +
                    "type varchar(10) not null default '.txt'," +
                    "city varchar(20) not null character set utf8"+
                    "stress varchar(180) not null character set utf8"+
                    "address varchar(200) not null character set utf8"+
                    "text varchar(500) not null character set utf8"+
                    "time varchar(20) not null character set utf8"+
                    "date varchar(20) not null character set utf8"+
                    ");");
        }catch (Exception e){
        }
        return false;
    }
    //清除一切本地数据库数据-调试方法
    public void dropAllLocalDb(){
        try{
            userDB.execSQL("drop table record");
        }catch (Exception e){}
        try{
            userDB.execSQL("drop table blacklist");
        }catch (Exception e){}
        try{
            userDB.execSQL("drop table friends");
        }catch (Exception e){}
        try{
            userDB.execSQL("drop table localkey");
        }catch (Exception e){}
    }
    //初始化系统文件夹
    private String rootURL="/sdcard/MYclient/";
    private void initUIDDir(){
        String URL=rootURL+userID+"/";
        String[] url=new String[2];
        url[0]="picture";url[1]="txt";
        File f=new File(rootURL);
        try{
            if(!f.exists()){
                f.mkdir();
                System.out.println("DLog:已创建:"+rootURL);
            }
            f=new File(rootURL+userID+"/");
            if(!f.exists()){
                f.mkdir();
                System.out.println("DLog:已创建:"+rootURL+userID);
            }
            for(String s:url){
                f=new File(URL+s);
                if(!f.exists()){
                    f.mkdir();
                    System.out.println("DLog:已创建:"+s);
                }
                System.out.println("DLog:创建用户文件夹成功或已存在");
           }
        }catch(Exception e){
            System.out.println("DLog:创建文件夹失败");
        }
    }
    //创建Cache文件夹
    private int nowDays=1;
    private void createCacheDir(){
        File f=new File(rootURL);
        try{
            if(!f.exists()){
                f.mkdir();
                System.out.println("DLog:已创建:"+rootURL);
            }
            f=new File(rootURL+"Cache/");
            if(!f.exists()){
                f.mkdir();
                System.out.println("DLog:已创建:"+rootURL+"Cache");
            }
            f=new File(rootURL+"Cache/"+TimeManager.getSqlDate()+"/");
            if(!f.exists()){
                f.mkdir();
                System.out.println("DLog:已创建:"+rootURL+"Cache/"+TimeManager.getSqlDate());
            }
            System.out.println("DLog:创建Cache文件夹成功或已存在");
        }catch(Exception e){
            System.out.println("DLog:创建Cache文件夹失败");
        }
    }
    //返回当日Cache文件夹是否完成建立的状态
    public boolean isDirExist(){
        try{
            String URL=rootURL+"Cache/"+ TimeManager.getSqlDate();
            if(new File(URL).exists()){
                System.out.println("DLog:当日Cache文件目录已存在");
            }
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("DLog:当日Cache文件目录不存在或其他错误");
            return false;
        }
        createCacheDir();//重建Cache目录
        return true;
    }
    //删除一个文件夹
    public boolean deleteDir(File dirUrl){
        File[] files = dirUrl.listFiles();
        for(File f:files){
            if(f.isFile())f.delete();
            else{
                deleteDir(f);//递归
            }
        }//不考虑并发操作
        dirUrl.delete();//删除自身
        return true;
    }

    //---------NetWork--------//
    //private Socket socket;
    //private final String TestIP="192.168.1.103";
    private final String TestIP="120.24.92.213";
    private final int PORT=12345;
    private int FILE_PORT=12344;
    private int retryTime=3000;//3000ms
    private JSONObject jsonToSend =null;
    private String fileURLToSend=null;
    private boolean isConnected=false;
    //获得一个相应类型的JS数据头
    public JSONObject getJsonEntity(String msgType){
        JSONObject msgOut=new JSONObject();
        try {
            msgOut.put("MsgType",msgType);
            msgOut.put("MsgId",getMID());
            msgOut.put("UID",userID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return msgOut;
    }
    //返回当前网络连接状况
    public boolean isConnected() {
        return isConnected;
    }
    //发送文件入口
    public synchronized void sendFile(String URL){
        this.fileURLToSend=URL;
        new Thread(sendFileRunable).start();
        try{
            Thread.sleep(500);
        }catch (Exception e){
        }
    }
    //发送Json数据入口
    public synchronized void sendJsonMsg(JSONObject json){
        this.jsonToSend=json;
        new Thread(sendJsonMsgRunable).start();
        try{
            Thread.sleep(500);
        }catch (Exception e){
        }
    }
    //发送测试空包数据入口
    public void sendJsonMsgEmpty(){
        JSONObject msgOut=getJsonEntity(InfoValue.MsgType.EMPTY);
        this.jsonToSend=msgOut;
        new Thread(sendJsonMsgRunable).start();
    }
    Runnable retryConnect=new Runnable() {
        @Override
        public void run() {
            try{
                Thread.sleep(retryTime);
                retryTime+=3000;//3s
                if(retryTime>10000)retryTime=10000;//10s
                //new Thread(TCPConnectRunnable).start();
                new Thread(TCPConSSLRunnable).start();
            }catch (Exception e){
                //e.printStackTrace();
                System.out.println("Error:睡眠被打断");
            }
        }
    };
    Runnable TCPConSSLRunnable=new Runnable() {
        @Override
        public void run() {
            try{
                initSSL();
                System.out.println("DLog:已连接服务器:"+sslSocket.getInetAddress());
                isConnected=true;
                retryTime=0;//重置重连延迟
                new Thread(messageListenerRunnable).start();//启用服务器消息循环监听
                //new Thread(updateGeoDate).start();//启动自动上报地理位置 - 未启用 2017.6.21
                //new Thread(keepBeatingRunnable).start();//启动心跳包- SSL更新，已废弃
                //new Thread(Timmer).start();//发送登录数据 - 已废弃 交由前台处理
            }catch (Exception e){
                new Thread(retryConnect).start();
                System.out.println("DLog:Warning!未连接上服务器:"+sslSocket.getInetAddress()+";"+retryTime/1000+"秒后重试");
            }
        }
    };
    Runnable sendFileRunable=new Runnable() {
        @Override
        public void run() {
            try{
                Socket fileSocket = new Socket();
                SocketAddress ipAddress = new InetSocketAddress(TestIP,FILE_PORT);
                fileSocket.connect(ipAddress,3000);//超时3秒
                fileSocket.setTcpNoDelay(true);
                System.out.println("DLog:已连接文件传输服务器:"+sslSocket.getInetAddress());
                OutputStream out=fileSocket.getOutputStream();
                FileInputStream fis=new FileInputStream(new File(fileURLToSend));
                byte[] buf =new byte[1024];
                int len;
                while((len=fis.read(buf))!=-1){
                    out.write(buf,0,len);
                }
                out.flush();out.close();fileSocket.close();
                System.out.println("DLog:发送文件完毕: "+fileURLToSend);
            }
            catch (Exception e){
                isConnected=false;
                System.out.println("DLog:发送文件失败:"+fileURLToSend);
            }
            finally{
                if(!isConnected){//掉线重连
                    retryTime=0;
                    //new Thread(retryConnect).start();
                }
            }
        }
    };
    Runnable sendJsonMsgRunable=new Runnable() {
        @Override
        public void run() {
            //if (!sslSocket.isClosed())System.out.println("还没关闭");
            try{
                synchronized (this){
                    BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sslSocket.getOutputStream(),"UTF-8"));
                    out.write(jsonToSend.toString()+"\n");out.flush();
                    System.out.println("DLog:发送消息成功:\n  - "+jsonToSend.toString());
                }
            }catch (Exception e){
                e.printStackTrace();
                System.out.println("DLog:发送Json消息失败:\n  - "+jsonToSend.toString());
                if(!isConnected){//掉线重连
                    retryTime=0;
                    //new Thread(retryConnect).start();
                }
            }
            //if(sslSocket.isClosed())System.out.println("关闭了");//test-info
        }
    };
    private int num=0;
    Runnable messageListenerRunnable=new Runnable() {
        @Override
        public void run() {
            System.out.println("DLog:开始侦听:"+num);
            try{
                BufferedReader in = new BufferedReader(new InputStreamReader(sslSocket.getInputStream(),"UTF-8"));
                while(isConnected) {//连接中
                     if(true) {
                        String readIn = in.readLine();
                        //System.out.println("服务器消息："+readIn);
                        JSONObject msgIn=new JSONObject(readIn);
                        dealMessage(msgIn);
                        Thread.sleep(500);//间隔缓冲
                        //System.out.println("等待服务器数据....");
                   }
                }
            }catch (Exception e){
                isConnected=false;
                uiCallback.localMsg("DIAOXIAN");//临时本地通信消息字，通知前台掉线
                System.out.println("DLog:Warning!侦听失败或掉线");
            }

            //无论如何，只要停止侦听，就选择掉线重连
            System.out.println("DLog:侦听失败或掉线:尝试重连中...");
            new Thread(retryConnect).start();
            System.out.println("DLog:停止侦听:"+num++);
        }
    };
    //自动更新地理信息，数值类型还要调整 2017.6.4
    private int updateType=1;
    Runnable updateGeoDate=new Runnable() {
        @Override
        public void run() {
            try{
                JSONObject msgOut,value;
                while (isConnected){
                    //System.out.println("新的等待");
                    Thread.sleep(1000*10*2);//睡眠十五分钟
                    switch (updateType){
                        case 1:
                            value=new JSONObject();
                            value.put("Type","1");
                            value.put("GeoData",gd.getAdCode()+"");
                            msgOut=MessageTool.mkGeoJSMsg(getJsonEntity(InfoValue.MsgType.CLIENT_PUSH),value);
                            sendJsonMsg(msgOut);
                        case 2:
                            value=new JSONObject();
                            value.put("Type","2");
                            value.put("GeoData",gd.getAddress()+"");
                            msgOut=MessageTool.mkGeoJSMsg(getJsonEntity(InfoValue.MsgType.CLIENT_PUSH),value);
                            sendJsonMsg(msgOut);
                        case 3:
                            value=new JSONObject();
                            value.put("Type","3");
                            value.put("GeoData",gd.getAdCode()+"");
                            value.put("GeoDataX",gd.getLongitude()+"");value.put("GeoDataY",gd.getLatitude()+"");
                            msgOut=MessageTool.mkGeoJSMsg(getJsonEntity(InfoValue.MsgType.CLIENT_PUSH),value);
                            sendJsonMsg(msgOut);
                            break;
                        default:break;
                    }
                    if(++updateType==4)updateType=1;//15分钟获取经纬度 30分钟获取详细位置 45分钟获取区号
                }
            }catch (Exception e){
                System.out.println("DLog:地理信息发送失败");
                try{
                    mLocationClient.stopLocation();
                }catch (Exception e1){}
                loadAmpLocation();//重启地理定位器
            }
        }
    };
    //---------Location-------//
    private AMapLocationClient mLocationClient = null;
    private AMapLocationClientOption mLocationOption = null;
    private AMapLocation gd = null;
    private void loadAmpLocation(){
        mLocationClient = new AMapLocationClient(getApplicationContext());//实例化客户端
        mLocationOption = new AMapLocationClientOption();
        mLocationOption.setInterval(60000);//60s刷新一次
        mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Battery_Saving);//省电模式
        mLocationClient.setLocationOption(mLocationOption);//设置客户端
        mLocationClient.setLocationListener(mAMapLocationListener);//设置定位回调监听
        mLocationClient.startLocation();//启动定位
    }
    public boolean isGaodeSDKAvaliable(){
        return gd!=null;
    }
    //获取高德地图客户端对象
    public AMapLocation getGdMap(){
        return gd;
    }

    AMapLocationListener mAMapLocationListener = new AMapLocationListener() {
        @Override
        public void onLocationChanged(AMapLocation amapLocation) {
            if (amapLocation != null) {
                if (amapLocation.getErrorCode() == 0) {
                    //解析定位结果
                    gd=amapLocation;
                    System.out.println("DLog:高德地图已更新");
                }
                else {
                    gd=null;
                    System.out.println("DLog:Warning!高德地图SDK错误码"+amapLocation.getErrorCode());
                }
            }
        }
    };
    //---------MessageDeal--------//
    private JSONObject JSONtoDeal=null;
    private void dealMessage(JSONObject msgIn) throws Exception{
        JSONtoDeal=msgIn;
        new Thread(dealMessageRunnable).start();//服务内分发消息
        new DisspatcServerMsg().dispatch(JSONtoDeal, uiCallback);//分发消息，回调视觉表现层
    }
    Runnable dealMessageRunnable=new Runnable() {
        @Override
        public void run() {
            try{
                String msgType=JSONtoDeal.getString("MsgType");
                //String msgId=JSONtoDeal.getString("MsgId");
                //String UID=JSONtoDeal.getString("UID");
                //System.out.println("分发消息中...");
                if(msgType.equals(InfoValue.MsgType.BEAT)){
                    //System.out.println("收到服务器心跳消息:"+TimeManager.getTime());
                    return;
                }
                JSONObject data=JSONtoDeal.getJSONObject("Data");
                if(msgType.equals(InfoValue.MsgType.SERVER_RES)){
                    dealMessageRes(data);
                }
                else if(msgType.equals(InfoValue.MsgType.SERVER_PUSH)){
                    dealMessagePush(data);
                }
                else if(msgType.equals(InfoValue.MsgType.MESSAGE)){
                    dealMessageSend(data,JSONtoDeal.getString("UID"));
                }
                else System.out.println("DLog:收到未知的后台处理消息类型 \n  - "+MessageTool.getMsgTypeName(msgType));
            }catch (Exception e){e.printStackTrace();}
        }
    };
    private void dealMessagePush(JSONObject data)throws Exception{
        String classs=data.getString("Class");
        String Day=data.getString("Day");
        String Time=data.getString("Time");
        if(classs.equals(InfoValue.MsgPush.Success)){
            System.out.println("DLog:本次一般性功能操作成功");
        }
        else if(classs.equals(InfoValue.MsgPush.Fail)){
            System.out.println("DLog:本次一般性功能操作失败");
        }
        else if(classs.equals(InfoValue.MsgPush.LoginSuccess)){
            System.out.println("DLog:登陆成功");
            userID=data.getString("UserID");
            userPw=data.getString("Password");
            nickName=data.getString("NickName");
            wirteKeyDB(userID,userPw);
        }
        else if(classs.equals(InfoValue.MsgPush.LoginFailed)){
            System.out.println("DLog:登陆失败");
        }
        else if(classs.equals(InfoValue.MsgPush.RegisterSuccess)){
            System.out.println("DLog:注册成功");
            userID=data.getString("UserID");
            userPw=data.getString("Password");
            nickName=data.getString("NickName");
            wirteKeyDB(userID,userPw);
        }
        else if(classs.equals(InfoValue.MsgPush.RegisterFailed)){
            System.out.println("DLog:注册失败");
        }
        else if(classs.equals(InfoValue.MsgPush.ResetPWSuccess)){
            System.out.println("DLog:重设密码成功");resetLocalKey();
        }
        else if(classs.equals(InfoValue.MsgPush.ResetPWFailed)){
            System.out.println("DLog:重设密码失败");
        }
        else if(classs.equals(InfoValue.MsgPush.ACK)){
            System.out.println("DLog:服务器已收到ACK:"+Day+" "+Time);
        }
        else if(classs.equals(InfoValue.MsgPush.ValicodeWrong)){
            System.out.println("DLog:验证码错误");
        }
        else{
            System.out.println("DLog:未知类型或其他推送类型:\n - "+MessageTool.getMsgPushName(classs));
        }
    }
    private void dealMessageRes(JSONObject data)throws Exception{
        String classs=data.getString("Class");
        //String Day=data.getString("Day");
        //String Time=data.getString("Time");
        if(classs.equals(InfoValue.MsgRes.AcceptFriend)){
            writeFriends(data);
            //待补充
        }
        else if(classs.equals(InfoValue.MsgRes.ProfileResponse)){
            /*
            System.out.println("个人资料获取-图片");
            JSONObject value=data.getJSONObject("Value");
            String filename=value.getString("Avatar");
            try{
                Socket fileSocket = new Socket();
                SocketAddress ipAddress = new InetSocketAddress(TestIP,FILE_PORT);
                fileSocket.connect(ipAddress,3000);//超时3秒
                fileSocket.setTcpNoDelay(true);
                System.out.println("已连接文件传输服务器:"+fileSocket.getInetAddress());
                InputStream in = fileSocket.getInputStream();
                FileOutputStream fw=new FileOutputStream(new File(rootURL+userID+"/picture/"+filename));
                byte[] buf=new byte[1024];
                int len=0;
                while((len=in.read(buf))!=-1){
                    fw.write(buf,0,len);
                }System.out.println("个人头像文件接收完毕");
                uiCallback.localMsg(filename);//告知前台
                //fw.flush();fw.close();fileSocket.close();
            }catch (SocketTimeoutException e0){
                System.out.println("连接超时");
            }catch(Exception e){
                System.out.println("发送失败");
            }
            //此处发送图片到达消息*/
        }
        else if(classs.equals(InfoValue.MsgRes.MomentResponse)){
            /*System.out.println("动态资料获取-图片");
            JSONObject value=data.getJSONObject("Value");
            String filename=value.getString("Pic");
            if(filename.equals("null")){
                System.out.println("动态资料获取完毕-没有图片");
                return;
            }
            try{
                Socket fileSocket = new Socket();
                SocketAddress ipAddress = new InetSocketAddress(TestIP,FILE_PORT);
                fileSocket.connect(ipAddress,3000);//超时3秒
                fileSocket.setTcpNoDelay(true);
                System.out.println("已连接文件传输服务器:"+fileSocket.getInetAddress());
                InputStream in = fileSocket.getInputStream();
                FileOutputStream fw=new FileOutputStream(new File(rootURL+userID+"/picture/"+filename));
                byte[] buf=new byte[1024];
                int len=0;
                while((len=in.read(buf))!=-1){
                    fw.write(buf,0,len);
                }System.out.println("动态图片接收完毕");
                uiCallback.localMsg(filename);//告知前台
                //fw.flush();fw.close();fileSocket.close();
            }catch (SocketTimeoutException e0){
                System.out.println("连接超时");
            }catch(Exception e){
                System.out.println("接收失败");
            }
            //此处发送图片到达消息*/
        }
    }
    private void dealMessageSend(JSONObject data,String sourceUID)throws Exception{
        String classs=data.getString("Class");
        //String Day=data.getString("Day");
        //String Time=data.getString("Time");
        if(classs.equals("TXT")){
            writeRecord(data,sourceUID);
        }
        else if(classs.equals("PIC")){
            System.out.println("DLog:图片传输暂未实现");
        }
        else if(classs.equals("FILE")){
            System.out.println("DLog:文件传输暂未实现");
        }
    }

    //---------Service--------//
    public DataService() {
        System.out.println("DLog:数据服务实体初始化结束");
        createCacheDir();//每天新建一个Cache缓存文件夹
    }

    //--------SSL Socket------//
    private SSLSocket sslSocket;
    public void initSSL() throws  Exception{
        //取得SSL的SSLContext实例
        SSLContext sslContext = SSLContext.getInstance("TLS");
        //取得KeyManagerFactory和TrustManagerFactory的X509密钥管理器实例
        KeyManagerFactory keyManager = KeyManagerFactory.getInstance("X509");
        TrustManagerFactory trustManager = TrustManagerFactory.getInstance("X509");
        //取得BKS密库实例
        KeyStore kks= KeyStore.getInstance("BKS");
        KeyStore tks = KeyStore.getInstance("BKS");
        //加客户端载证书和私钥,通过读取资源文件的方式读取密钥和信任证书
        kks.load(getBaseContext()
                .getResources()
                .openRawResource(R.raw.client),"client".toCharArray());
        tks.load(getBaseContext()
                .getResources()
                .openRawResource(R.raw.tserver),"client".toCharArray());
        //初始化密钥管理器
        keyManager.init(kks,"client".toCharArray());
        trustManager.init(tks);
        //初始化SSLContext
        sslContext.init(keyManager.getKeyManagers(),trustManager.getTrustManagers(),null);
        //生成SSLSocket
        SocketAddress ipAddress = new InetSocketAddress(TestIP,PORT);
        sslSocket = (SSLSocket) sslContext.getSocketFactory().createSocket();
        sslSocket.connect(ipAddress,3000);
        sslSocket.setTcpNoDelay(true);
    }

    //------------------------//
    @Override
    public void onCreate() {
        super.onCreate();

        tryToReachKeyDB();
        loadAmpLocation();
        //new Thread(TCPConnectRunnable).start();
        new Thread(TCPConSSLRunnable).start();//SSL
        System.out.println("DLog:服务已启动");

    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }
    @Override
    public IBinder onBind(Intent intent) {
        //return Binder
        return serviceBinder;
    }
    @Override
    public boolean onUnbind(Intent intent) {
        //System.out.println("解绑");
        return super.onUnbind(intent);
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        //sendJsonMsg(MessageTool.mkOfflienJSMsg(userID,getMID()));//发送下线消息
        System.out.println("DLog:数据服务已关闭");
    }
}
/*原TCP连接方式
    Runnable TCPConnectRunnable=new Runnable() {
        @Override
        public void run() {
            try{
                socket = new Socket();
                SocketAddress ipAddress = new InetSocketAddress(TestIP,PORT);
                socket.connect(ipAddress,3000);//超时3秒
                socket.setTcpNoDelay(true);
                System.out.println("已连接服务器:"+socket.getInetAddress());
                isConnected=true;

                new Thread(messageListenerRunnable).start();//启用服务器消息循环监听
                new Thread(updateGeoDate).start();//启动自动上报地理位置
                new Thread(keepBeatingRunnable).start();//启动心跳包
                //new Thread(Timmer).start();//发送登录数据
            }catch (Exception e){
                new Thread(retryConnect).start();
                System.out.println("未连接上服务器:"+socket.getInetAddress()+";"+retryTime/1000+"秒后重试");
            }
            //System.out.println("尝试连接结束");
        }
    };*/
/*
    //心跳-废弃
    Runnable keepBeatingRunnable=new Runnable() {
        @Override
        public void run() {
            while (isConnected){
                //System.out.println("心跳开始");
                try{
                    //System.out.println("心跳开始2");
                    //sendJsonMsgEmpty();
                    //Thread.sleep(10000);
                    //sslSocket.sendUrgentData(0xFF);
                    //System.out.println("发送心跳包");
                }catch (Exception e){
                    isConnected=false;
                    //System.out.println("心跳开始3");
                    e.printStackTrace();
                    //sendJsonMsg(MessageTool.mkOfflienJSMsg(userID,getMID()));
                }
                //System.out.println("心跳开始4");
            }
        }
    };*/
    /*自动登录方法 废弃-2017.6.21
    Runnable Timmer=new Runnable() {
        @Override
        public void run() {
            try{
                Thread.sleep(2500);
                if(!userID.equals(InfoValue.PackageConstants.CLIENT_ID) && !userPw.equals("000000") && gd!=null){
                    //重连自动发送登陆信息
                    System.out.println("自动发送秘钥");
                    JSONObject msgOut=getJsonEntity(InfoValue.MsgType.LOGIN);
                    JSONObject data=new JSONObject();
                        data.put("Account",userID);data.put("Password",userPw);
                        data.put("Longitude",gd.getLongitude()+"");data.put("Latitude",gd.getLatitude()+"");data.put("Address",gd.getAddress()+"");
                        data.put("Adcode",gd.getAdCode()+"");data.put("Valicode","empty");
                    msgOut.put("Data",data);
                    sendJsonMsg(msgOut);
                }
            }catch (Exception e){
            }
        }
    };*/