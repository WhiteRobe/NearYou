package edu.xd.jiaoyou.view;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.support.percent.PercentRelativeLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import org.json.JSONException;
import org.json.JSONObject;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.StringToInteger;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.InfoValue;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.custom.CustomToast;
import edu.xd.jiaoyou.view.main.MainActivity;

/**
 * Created by ZhengXi on 2017/5/14.
 */

public class RegisterActivity extends AppCompatActivity {

    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;

    private UICallback uiCallback=new UICallback() {
        @Override
        public void dealServerRes(JSONObject msgIn) {}

        @Override
        public void dealServerPush(JSONObject msgIn) {
            String response = null;
            try {
                JSONObject data=msgIn.getJSONObject("Data");
                response = data.getString("Class");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if(response.equals(InfoValue.MsgPush.RegisterSuccess)) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        CustomToast.makeText(RegisterActivity.this,"注册成功",
                                CustomToast.LENGTH_SHORT).show();
                        //将登陆账号密码写入数据库
                        SharedPreferences preferences = getSharedPreferences("ACCOUNT",MODE_PRIVATE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putString("userId",dataService.getUserID());
                        editor.putString("account",phoneNumber);
                        editor.putString("password",password);
                        editor.commit();
                    }
                });
                Intent intent = new Intent(RegisterActivity.this,UserInfoActivity.class);
                intent.putExtra("userId", StringToInteger.StringToInteger(dataService.getUserID()));
                startActivity(intent);
            }
            else if(response.equals(InfoValue.MsgPush.RegisterFailed)) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        CustomToast.makeText(RegisterActivity.this,"注册失败，未连接上服务器",
                                CustomToast.LENGTH_SHORT).show();
                    }
                });
            }
        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {}

        @Override
        public void localMsg(String msg) {
            if (msg.equals("DIAOXIAN"))
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        CustomToast.makeText(RegisterActivity.this,"与服务器断开连接",
                                CustomToast.LENGTH_SHORT).show();
                    }
                });
        }
    };

    private ServiceConnection connection=new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
            dataService.setUICallback(uiCallback);
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };

    private ImageView logo;
    private PercentRelativeLayout rlPhone;
    private PercentRelativeLayout rlPassword;
    private PercentRelativeLayout rlConfirm;
    private EditText etPhone;
    private EditText etPassword;
    private EditText etConfirm;
    private Button btnRegister;
    private ImageView imgCheck;

    private String phoneNumber = "";
    private String password = "";
    private String confirm = "";

    private static final int TYPE_DISAPPEAR = 0x0000; //logo消失类型
    private static final int TYPE_RESET     = 0x0001; //重置类型
    private float translationY; //平移距离
    private float startAlpha;   //动画起始alpha
    private int state = TYPE_RESET; //当前状态：disappear or no

    private static float sTvSize = -1.0f;
    private static final float RATIO = 0.30769231f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Intent bindIntent = new Intent(RegisterActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        init();
    }

    @Override
    protected void onResume() {
        if(getRequestedOrientation()!= ActivityInfo.SCREEN_ORIENTATION_PORTRAIT){
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
        initTextSize();
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        unbindService(connection);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (state == TYPE_DISAPPEAR) setAnimator(TYPE_RESET);
        else super.onBackPressed();
    }

    private void init() {
        logo = (ImageView) findViewById(R.id.img_register_logo);

        rlPhone = (PercentRelativeLayout) findViewById(R.id.rLayout_register_phoneNumber);
        rlPassword = (PercentRelativeLayout) findViewById(R.id.rLayout_register_password);
        rlConfirm = (PercentRelativeLayout) findViewById(R.id.rLayout_register_confirm);

        imgCheck = (ImageView) findViewById(R.id.img_register_check);

        etPhone = (EditText) findViewById(R.id.editText_register_phoneNumber);
        etPhone.setLongClickable(false); //不允许其长按复制粘贴
        etPhone.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) setOnFocused(0);
            }
        });
        etPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (state == TYPE_RESET) setAnimator(TYPE_DISAPPEAR);
            }
        });

        etPassword = (EditText) findViewById(R.id.editText_register_password);
        etPassword.setLongClickable(false);
        etPassword.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) setOnFocused(1);
                if (state == TYPE_RESET) setAnimator(TYPE_DISAPPEAR);
            }
        });
        etPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!etConfirm.getText().toString().equals(""))
                    etConfirm.setText("");
            }

            @Override
            public void afterTextChanged(Editable s) {
                password = etPassword.getText().toString();
            }
        });

        etConfirm = (EditText) findViewById(R.id.editText_register_confirm);
        etConfirm.setLongClickable(false);
        etConfirm.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) setOnFocused(2);
                if (state == TYPE_RESET) setAnimator(TYPE_DISAPPEAR);
            }
        });
        etConfirm.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                confirm = etConfirm.getText().toString();
                if(confirm.equals("")) imgCheck.setVisibility(View.INVISIBLE);
                else if(confirm.equals(password)) {
                    imgCheck.setVisibility(View.VISIBLE);
                    imgCheck.setImageDrawable(getDrawable(R.drawable.right));
                }
                else {
                    imgCheck.setVisibility(View.VISIBLE);
                    imgCheck.setImageDrawable(getDrawable(R.drawable.wrong));
                }
            }
        });

        btnRegister = (Button) findViewById(R.id.btn_register_register);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etPhone.getText().toString().equals(""))
                    CustomToast.makeText(RegisterActivity.this,"请输入手机号",
                            CustomToast.LENGTH_SHORT).show();
                else if(password.equals(""))
                    CustomToast.makeText(RegisterActivity.this,"请输入密码",
                            CustomToast.LENGTH_SHORT).show();
                else if(confirm.equals(""))
                    CustomToast.makeText(RegisterActivity.this,"请确认输入密码",
                            CustomToast.LENGTH_SHORT).show();
                else if(!confirm.equals(password))
                    CustomToast.makeText(RegisterActivity.this,"两次输入密码不一致",
                            CustomToast.LENGTH_SHORT).show();
                else {
                    if (!dataService.register(etPhone.getText().toString(),etPassword.getText().toString())) {
                        CustomToast.makeText(RegisterActivity.this,"获取地理位置权限失败",CustomToast.LENGTH_SHORT)
                                .show();
                    }
                }
            }
        });

    }

    //设置logo消失/出现的动画
    private void setAnimator(int type) {
        if (type == TYPE_DISAPPEAR) {
            startAlpha = 1f;
            translationY = getResources().getDimension(R.dimen.y420);
            state = TYPE_DISAPPEAR;
        }
        else {
            startAlpha = 0f;
            translationY = 0;
            state = TYPE_RESET;
        }

        ObjectAnimator alpha = ObjectAnimator.ofFloat(logo,"alpha",startAlpha,1f-startAlpha);
        alpha.setDuration(150);
        ObjectAnimator translateLogo = ObjectAnimator.ofFloat(logo,"translationY",logo.getTranslationY()
                ,-translationY);
        translateLogo.setDuration(150);
        ObjectAnimator translateR1 = ObjectAnimator.ofFloat(rlPhone,"translationY",rlPhone.getTranslationY(),
                -translationY);
        translateR1.setDuration(150);
        ObjectAnimator translateR2 = ObjectAnimator.ofFloat(rlPassword,"translationY",rlPassword.getTranslationY(),
                -translationY);
        translateR1.setDuration(150);
        ObjectAnimator translateR3 = ObjectAnimator.ofFloat(rlConfirm,"translationY",rlConfirm.getTranslationY(),
                -translationY);
        translateR1.setDuration(150);
        ObjectAnimator translateBtn = ObjectAnimator.ofFloat(btnRegister,"translationY",btnRegister.getTranslationY(),
                -translationY);
        translateR1.setDuration(150);

        AnimatorSet set = new AnimatorSet();
        set.playTogether(alpha,translateLogo,translateR1,translateR2,translateR3,translateBtn);
        set.start();
    }

    private void setOnFocused(int focused) {
        if (focused == 0) {
            rlPhone.setBackground(getDrawable(R.drawable.shape_login_edittext_focused));
            rlPassword.setBackground(getDrawable(R.drawable.shape_login_edittext_unfocused));
            rlConfirm.setBackground(getDrawable(R.drawable.shape_login_edittext_unfocused));
        }
        else if (focused == 1) {
            rlPhone.setBackground(getDrawable(R.drawable.shape_login_edittext_unfocused));
            rlPassword.setBackground(getDrawable(R.drawable.shape_login_edittext_focused));
            rlConfirm.setBackground(getDrawable(R.drawable.shape_login_edittext_unfocused));
        }
        else if (focused == 2) {
            rlPhone.setBackground(getDrawable(R.drawable.shape_login_edittext_unfocused));
            rlPassword.setBackground(getDrawable(R.drawable.shape_login_edittext_unfocused));
            rlConfirm.setBackground(getDrawable(R.drawable.shape_login_edittext_focused));
        }
    }

    private void initTextSize() {
        btnRegister.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                sTvSize = btnRegister.getHeight()*RATIO;
                btnRegister.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                if(sTvSize!=-1.0f) {
                    RegisterActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            btnRegister.setTextSize(TypedValue.COMPLEX_UNIT_PX,sTvSize);
                            etPhone.setTextSize(TypedValue.COMPLEX_UNIT_PX,sTvSize);
                            etPassword.setTextSize(TypedValue.COMPLEX_UNIT_PX,sTvSize);
                            etConfirm.setTextSize(TypedValue.COMPLEX_UNIT_PX,sTvSize);
                        }
                    });
                }
            }
        });
    }

}
