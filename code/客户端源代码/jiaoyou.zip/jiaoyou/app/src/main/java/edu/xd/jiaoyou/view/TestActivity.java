package edu.xd.jiaoyou.view;

import android.os.Bundle;

import edu.xd.jiaoyou.R;

public class TestActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.test);

        init();
    }

    private void init() {

    }

}
