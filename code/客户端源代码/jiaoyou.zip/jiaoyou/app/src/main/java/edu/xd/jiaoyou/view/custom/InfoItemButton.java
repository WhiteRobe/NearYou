package edu.xd.jiaoyou.view.custom;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.view.LoginActivity;

/**
 * Created by ZhengXi on 2017/6/4.
 */

public class InfoItemButton extends RelativeLayout {

    private TextView mTitle;
    private TextView mText;
    private ImageView mImage;

    public InfoItemButton(Context context) {
        super(context);
    }

    public InfoItemButton(Context context, AttributeSet attrs) {
        super(context,attrs);
        LayoutInflater.from(context).inflate(R.layout.custom_infoitem_button,this,true);
        mTitle = (TextView) findViewById(R.id.title);
        mText = (TextView) findViewById(R.id.text);
        mImage = (ImageView) findViewById(R.id.image);

        TypedArray mArray = context.obtainStyledAttributes(attrs,R.styleable.InfoItemButton);
        if(mArray.getBoolean(R.styleable.InfoItemButton_isImage,false)) {
            //默认TexView显示，ImageView隐藏
            mText.setVisibility(GONE);
            mImage.setImageDrawable(mArray.getDrawable(R.styleable.ImageTextButton_src));
        }
        else {
            mImage.setVisibility(GONE);
            mText.setText(mArray.getText(R.styleable.InfoItemButton_text));
        }
        mTitle.setText(mArray.getText(R.styleable.InfoItemButton_item_title));
    }

    public void setTitle(CharSequence title) {
        mTitle.setText(title);
    }

    public void setText(CharSequence text) {
        mText.setText(text);
    }

    public void setImageDrawable(Drawable drawable) {
        mImage.setImageDrawable(drawable);
    }

    public void setImageResource(int resID) {
        mImage.setImageResource(resID);
    }

    public void setImageBitmap(Bitmap bitmap) {
        mImage.setImageBitmap(bitmap);
    }

    public CharSequence getTitle() {
        return mTitle.getText();
    }

    public CharSequence getText() {
        return mText.getText();
    }
}
