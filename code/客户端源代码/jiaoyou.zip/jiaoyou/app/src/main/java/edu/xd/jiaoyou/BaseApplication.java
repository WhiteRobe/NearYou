package edu.xd.jiaoyou;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.util.HashMap;
import java.util.List;

import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.tools.CacheTool;
import edu.xd.jiaoyou.tools.Create;
import edu.xd.jiaoyou.view.main.ChatMessageModel;
import edu.xd.jiaoyou.view.main.FriendModel;
import edu.xd.jiaoyou.view.main.MomentModel;
import edu.xd.jiaoyou.view.main.WordMessageModel;
import github.imageselector.ImageConfig;
import github.imageselector.ImageLoader;

/**
 * Created by ZhengXi on 2017/6/15.
 */

public class BaseApplication extends Application {

    private static final String CAMERA_PATH  = "/sdcard/MYclient/pictures/";//照片路径
    private static final String FRIENDS      = "/sdcard/MYclient/friends";
    private static final String CHATS        = "/sdcard/MYclient/chats/";
    private static final String COMMENTS     = "/sdcard/MYclient/comments/";
    private static final String NEARBY_PATH  = "/sdcard/MYclient/Cache/nearby";
    private static final String FRIEND_PATH  = "/sdcard/MYclient/Cache/friend";
    private static final String CHAT_PATH    = "/sdcard/MYclient/Cache/chat";
    private static final String WORD_PATH    = "/sdcard/MYclient/Cache/word";

    private ImageConfig imageConfig;

    private String userId;   //id
    private String account;  //登录账号
    private String password; //密码

    //整个应用程序的入口
    @Override
    public void onCreate() {
        super.onCreate();

        //启动服务
        Intent startIntent = new Intent(BaseApplication.this,DataService.class);
        startService(startIntent);

        //读取配置文件中的账号密码信息
        SharedPreferences preferences = getSharedPreferences("ACCOUNT",MODE_PRIVATE);
        userId = preferences.getString("userId","null");
        account = preferences.getString("account","null");
        password = preferences.getString("password","null");

        new Thread(new Runnable() {
            @Override
            public void run() {
                initData();
                Log.v("BaseApplication","Application data initialized");
            }
        }).start();
    }

    //是否存在登录过的账号
    public boolean hasAccount() {
        return !(account.equals("null") || password.equals("null"));
    }

    public String getAccount() {
        return account;
    }

    public String getPassword() {
        return password;
    }

    public String getUserId() {
        return userId;
    }

    //ImageSelector 选择单个图片的模式
    public ImageConfig getSingleSelect() {
        /*返回文件的url会抛出异常 exposed beyond app through Intent.getData()
        imageConfig = new ImageConfig.Builder(
                new GlideLoader())
                .singleSelect()
                .showCamera()
                .filePath(CAMERA_PATH)
                .crop()
                .build();
        return imageConfig;
        */
        return getMultiSelect(1);
    }

    //ImageSelector 选择多个图片的模式
    public ImageConfig getMultiSelect() {
        imageConfig = new ImageConfig.Builder(
                new GlideLoader())
                .mutiSelect()
                .mutiSelectMaxSize(9)
                .showCamera()
                .filePath(CAMERA_PATH)
                .build();
        return imageConfig;
    }

    //ImageSelector 选择多个图片的模式
    public ImageConfig getMultiSelect(int maxImages) {
        imageConfig = new ImageConfig.Builder(
                new GlideLoader())
                .mutiSelect()
                .mutiSelectMaxSize(maxImages)
                .showCamera()
                .filePath(CAMERA_PATH)
                .build();
        return imageConfig;
    }

    //初始化界面数据
    private void initData() {
        //Create.writeCache();
        Constant.AppData.nearbyMoments = (List<MomentModel>) CacheTool.readObjectFromFile(NEARBY_PATH);
        Constant.AppData.friendMoments = (List<MomentModel>) CacheTool.readObjectFromFile(FRIEND_PATH);
        Constant.AppData.chatMessages = (List<ChatMessageModel>) CacheTool.readObjectFromFile(CHAT_PATH);
        Constant.AppData.wordMessages = (List<WordMessageModel>) CacheTool.readObjectFromFile(WORD_PATH);
        Constant.AppData.friends = (List<FriendModel>) CacheTool.readObjectFromFile(FRIENDS);
        Constant.AppData.comments = (HashMap) CacheTool.readObjectFromFile(COMMENTS);
        Constant.AppData.chats = (HashMap) CacheTool.readObjectFromFile(CHATS);
    }

    public class GlideLoader implements ImageLoader {
        @Override
        public void displayImage(Context context, String path, ImageView imageView) {
            Glide.with(context)
                    .load(path)
                    //默认图片
                    .placeholder(R.mipmap.imageselector_photo)
                    .centerCrop()
                    .into(imageView);
        }
    }

}
