/**
 * Copyright (C), 2017-2018, Xidian University, Xian, China
 *
 * @author Dai
 * @date 2017-4-23
 */
package com.xidian.tools;
class PackageInfo{  
    public void common(){  
        System.out.println("Cteate by Dai on 2017-4-23");  
    }  
} 

class PackageConstants{
	public static final String ESCAPE_STRING="}(]";
	public static final String ESCAPE_STRING_TRANS_VALUE="mY3}(#]sElFvAluE";
    public static final int ESC_STRING_LENGTH=ESCAPE_STRING.length();
}
