package edu.xd.jiaoyou.view.main;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.StringToInteger;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.UserPageActivity;
import edu.xd.jiaoyou.view.custom.CustomToast;
import edu.xd.jiaoyou.view.custom.RecycleViewDivider;
import edu.xd.jiaoyou.view.momentdetail.MomentDetailActivity;
import edu.xd.jiaoyou.view.photoviewer.PhotoViewerActivity;
import in.srain.cube.views.ptr.PtrClassicDefaultHeader;
import in.srain.cube.views.ptr.PtrDefaultHandler;
import in.srain.cube.views.ptr.PtrFrameLayout;

/**
 * Created by ZhengXi on 2017/6/19.
 */

public class NearbyMomentFragment extends Fragment {

    private DataService dataService = null;
    private UICallback uiCallback = null;

    private Context mContext;
    private View mView;
    private PtrFrameLayout mPtrFrameLayout;
    private RecyclerView mRecyclerView;
    private MomentAdapter mAdapter;

    private boolean loadSuccess = false;//是否加载成功，用于检测加载超时

    //recyclerView分割线
    private int dividerHeight;
    private int dividerColor;

    private int loadedNumber = 0; //记录每个item已加载的图片数

    //绑定到activity
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.mContext = context;

        //获得绑定的服务
        //第一个fragment，可能此时activity还没有绑定服务完成
        //使用线程监听activity的绑定情况
        uiCallback = new NearbyMomentFragment.UICallBack();
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(!((MainActivity) getActivity()).isConnected()) {}
                dataService = ((MainActivity) getActivity()).getDataService();
                dataService.setUICallback(uiCallback);
            }
        }).start();
        //初始化分割线参数
        dividerHeight = (int) mContext.getResources().getDimension(R.dimen.y24);
        dividerColor = Color.rgb(242,242,242); //R.color.colorBaseBackground
        //初始化mAdapter
        mAdapter = new MomentAdapter();
        //setOnClickEvent();
    }

    //绘制fragment
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.pager_moment_near,container,false);

        mPtrFrameLayout = (PtrFrameLayout) mView.findViewById(R.id.ptrLayout);
        PtrClassicDefaultHeader header = new PtrClassicDefaultHeader(mContext);
        mPtrFrameLayout.setHeaderView(header);
        mPtrFrameLayout.addPtrUIHandler(header);
        mPtrFrameLayout.setPtrHandler(new PtrDefaultHandler() {
            //刷新事件
            @Override
            public void onRefreshBegin(PtrFrameLayout frame) {
                loadSuccess = false;
                loadServiceData();
                //5秒之后提示超时
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(5000);
                            if (!loadSuccess)
                                mView.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        CustomToast.makeText(mContext,"连接服务器超时",
                                                CustomToast.LENGTH_SHORT).show();
                                        stopRefresh();
                                    }
                                });
                        } catch (Exception e) {

                        }
                    }
                }).start();
            }
        });

        mRecyclerView = (RecyclerView) mView.findViewById(R.id.rcyView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mContext));
        mRecyclerView.addItemDecoration(new RecycleViewDivider(mContext,LinearLayoutManager.HORIZONTAL,
                dividerHeight,dividerColor));
        mRecyclerView.addOnScrollListener(new NearbyMomentFragment.OnScrollListener());
        mRecyclerView.setAdapter(mAdapter);

        //loadLocalCache();
        setOnClickEvent();
        return mView;
    }

    //自动刷新
    public void autoRefresh() {
        mPtrFrameLayout.postDelayed(new Runnable() {
            @Override
            public void run() {
                mPtrFrameLayout.autoRefresh();
            }
        },100);
    }

    //停止刷新
    public void stopRefresh() {
        mPtrFrameLayout.post(new Runnable() {
            @Override
            public void run() {
                mPtrFrameLayout.refreshComplete();
            }
        });
    }

    //加载本地cache数据
    private void loadLocalCache() {
        mAdapter.add(Constant.AppData.nearbyMoments);
    }

    //加载服务器返回的数据
    private void loadServiceData() {
        dataService.setUICallback(uiCallback);
        dataService.getMomentsNearby(0);
    }

    //设置点击事件
    private void setOnClickEvent() {
        //点击Item事件
        /*mAdapter.setOnItemClickListener(new MomentAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent intent = new Intent(view.getContext(), MomentDetailActivity.class);
                intent.putExtra("momentID",mAdapter.getMomentId(position));
                mContext.startActivity(intent);
            }
        });
        */
        //点击点赞，评论事件
        mAdapter.setOnButtonClickListener(new MomentAdapter.OnButtonClickListener() {
            @Override
            public void onButtonClick(View view, String viewTag, int position) {
                if (viewTag.equals("profile")) {
                    Intent intent = new Intent(mContext, UserPageActivity.class);
                    intent.putExtra("userId",mAdapter.getItemByPosition(position).userId);
                    startActivity(intent);
                }

                if (viewTag.equals("like")) {
                    dataService.sendMomentLike(String.valueOf(mAdapter.getItemByPosition(position).userId),
                            String.valueOf(mAdapter.getMomentId(position)),true);
                }
                if (viewTag.equals("unlike")) {
                    dataService.sendMomentLike(String.valueOf(mAdapter.getItemByPosition(position).userId),
                            String.valueOf(mAdapter.getMomentId(position)),false);
                }

            }
        });

        //点击图片事件
        mAdapter.setOnImageClickListener(new MomentAdapter.OnImageClickListener() {
            @Override
            public void onImageClick(View view, int imageId, int position) {
                Intent intent = new Intent(mContext, PhotoViewerActivity.class);
                intent.putExtra("current_item",imageId);
                intent.putExtra("image_list",(Serializable) mAdapter.getMomentImages(position));
                startActivity(intent);
            }
        });
    }

    //recyclerView滑动监听
    private class OnScrollListener extends RecyclerView.OnScrollListener {
        int mScrollThreshold = 6;  //滑动敏感值
        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
            //判断是当前layoutManager是否为LinearLayoutManager(默认)
            //只有LinearLayoutManager才有查找第一个和最后一个可见view位置的方法
            if (layoutManager instanceof LinearLayoutManager) {
                LinearLayoutManager linearManager = (LinearLayoutManager) layoutManager;
                //获取最后一个可见view的位置
                int lastItemPosition = linearManager.findLastVisibleItemPosition();
                //获取第一个可见view的位置
                int firstItemPosition = linearManager.findFirstVisibleItemPosition();
                //System.out.println("near"+lastItemPosition + "   " + firstItemPosition);
                //执行上滑刷新
                if (lastItemPosition == mAdapter.getItemCount() - 1 && mAdapter.hasFootView()) {
                    System.out.println("上滑刷新");
                }
            }
            boolean isSignificantDelta = Math.abs(dy) > mScrollThreshold;
            if (isSignificantDelta) {
                if (dy > 0) {
                    onScrollUp();
                } else {
                    onScrollDown();
                }
            }
        }

        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        //下滑
        private void onScrollDown() {
            System.out.println("down");
            ((MomentFragment) getParentFragment()).setFabState(0);
        }

        //上滑
        private void onScrollUp() {
            System.out.println("up");
            ((MomentFragment) getParentFragment()).setFabState(1);
        }

        public void setScrollThreshold(int scrollThreshold) {
            mScrollThreshold = scrollThreshold;
        }

    }

    //回调接口
    private class UICallBack implements UICallback {
        int id,userId,pictures,likes,comments,width,height;;
        String name,profile,content,time,date,place,pictureName;
        boolean isLike;
        List<String> images = new ArrayList<>();
        @Override
        public void dealServerRes(JSONObject msgIn) {
            try {
                JSONObject data = msgIn.getJSONObject("Data");
                JSONObject value = data.getJSONObject("Value");
                System.out.println("NearbyMoments:"+data);
                id = StringToInteger.StringToInteger(value.getString("MomentsNo"));
                userId = StringToInteger.StringToInteger(value.getString("Id"));
                name = value.getString("NickName");
                profile = Constant.SERVICE_IP+"/avatar/"+"123"+"_avatar";;
                pictures = value.getInt("PicNum");
                likes = value.getInt("Liked");
                comments = value.getInt("Comments");
                pictureName = value.getString("Pic");
                content = value.getString("Text");
                time = value.getString("Time");
                date = value.getString("Date");
                place = value.getString("Location");
                isLike = value.getInt("IsLike")==0 ? false : true;

                images.clear();
                StringBuffer buffer = new StringBuffer(pictureName);
                if (pictures == 0) {
                    width = 0;height = 0;
                }
                else if (pictures == 1) {
                    width = 996;height = 996 ;
                    images.add(Constant.SERVICE_IP+"/momentpic/"+pictureName);
                    System.out.println("ImagePath:"+pictureName);
                }
                else if (pictures>1){
                    width = 0;height = 0;
                    for (int i=0;i<pictures;i++) {
                        String path = buffer.replace(0,1,String.valueOf(i+1)).toString();
                        System.out.println("ImagePath:"+path);
                        images.add(Constant.SERVICE_IP+"/momentpic/"+
                                        buffer.replace(0,1,String.valueOf(i+1)).toString());
                    }
                }
                //更新UI
                mView.post(new Runnable() {
                    @Override
                    public void run() {
                        mAdapter.insert(0,new MomentModel(id,userId,name,profile,content,pictures,width,height
                        ,time,place,likes,comments,isLike,images));
                        //加载一条就停止刷新动画
                        stopRefresh();
                        loadSuccess = true;
                    }
                });
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void dealServerPush(JSONObject msgIn) {

        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {}

        @Override
        public void localMsg(String msg) {
            if (msg == null) return;
            if (msg.equals("DIAOXIAN")) {
                return;
            }
        }
    }

}
