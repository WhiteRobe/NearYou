package edu.xd.jiaoyou.tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import edu.xd.jiaoyou.view.chat.ChatModel;
import edu.xd.jiaoyou.view.main.ChatMessageModel;
import edu.xd.jiaoyou.view.main.FriendModel;
import edu.xd.jiaoyou.view.main.MomentModel;
import edu.xd.jiaoyou.view.main.WordMessageModel;
import edu.xd.jiaoyou.view.momentdetail.CommentModel;

/**
 * Created by ZhengXi on 2017/6/21.
 */

public class Create {

    public static final String ROOT_PATH = "/sdcard/MYclient/Cache/";
    public static final String AVATAR_PATH = "/sdcard/MYclient/avatar/";
    public static final String PICTURE_PATH = "/sdcard/MYclient/pictures/";
    public static final String FRIENDS = "/sdcard/MYclient/friends/";
    public static final String CHATS = "/sdcard/MYclient/chats/";
    public static final String COMMENTS = "/sdcard/MYclient/comments/";
    public static final String NEARBY_PATH = "/sdcard/MYclient/Cache/nearby/";
    public static final String FRIEND_PATH = "/sdcard/MYclient/Cache/friend/";
    public static final String CHAT_PATH = "/sdcard/MYclient/Cache/chat/";
    public static final String WORD_PATH = "/sdcard/MYclient/Cache/word/";

    public static List<MomentModel> nearbyMoments;
    public static List<MomentModel> friendMoments;
    public static List<ChatMessageModel> chatMessages;
    public static List<WordMessageModel> wordMessages;
    public static List<FriendModel> friends;
    public static List<CommentModel> comments;
    public static List<ChatModel> chats;

    public static void writeCache() {
        List<String> images = new ArrayList<>();

        nearbyMoments = new ArrayList<>();
        images.add(PICTURE_PATH + "00.jpg");
        nearbyMoments.add(new MomentModel(0, 4, "小明", AVATAR_PATH + "4.jpg",
                "我也是要成为海贼王的男人", images.size(), 994, 610, "刚刚", "西安·西安电子科技大学海棠8#",
                0, 0, false, images));
        images.clear();

        images.add(PICTURE_PATH + "10.jpg");
        images.add(PICTURE_PATH + "11.jpg");
        images.add(PICTURE_PATH + "12.jpg");
        images.add(PICTURE_PATH + "13.jpg");
        images.add(PICTURE_PATH + "14.jpg");
        images.add(PICTURE_PATH + "15.jpg");
        images.add(PICTURE_PATH + "16.jpg");
        images.add(PICTURE_PATH + "17.jpg");
        images.add(PICTURE_PATH + "18.jpg");
        nearbyMoments.add(new MomentModel(1, 10, "西安电子科技大学", AVATAR_PATH + "10.jpg",
                "我电一直美美哒", images.size(), 0, 0, "刚刚", "西安·西安电子科技大学B楼",
                32, 24, true, images));
        images.clear();

        images.add(PICTURE_PATH + "20.gif");
        nearbyMoments.add(new MomentModel(2, 9, "郑茜", AVATAR_PATH + "9.jpg",
                "这天气要热死人了", images.size(), 299, 220, "12：20", "西安·西安电子科技大学海棠8#",
                0, 0, false, images));
        images.clear();
        CacheTool.writeObjectToFile(nearbyMoments, ROOT_PATH + "nearby");

        friendMoments = new ArrayList<>();
        images.add(PICTURE_PATH + "00.jpg");
        friendMoments.add(new MomentModel(0, 4, "小明", AVATAR_PATH + "4.jpg",
                "我也是要成为海贼王的男人", images.size(), 994, 610, "刚刚", "西安·西安电子科技大学海棠8#",
                0, 0, false, images));
        images.clear();

        images.add(PICTURE_PATH + "10.jpg");
        images.add(PICTURE_PATH + "11.jpg");
        images.add(PICTURE_PATH + "12.jpg");
        images.add(PICTURE_PATH + "13.jpg");
        images.add(PICTURE_PATH + "14.jpg");
        images.add(PICTURE_PATH + "15.jpg");
        images.add(PICTURE_PATH + "16.jpg");
        images.add(PICTURE_PATH + "17.jpg");
        images.add(PICTURE_PATH + "18.jpg");
        friendMoments.add(new MomentModel(1, 10, "西安电子科技大学", AVATAR_PATH + "10.jpg",
                "我电一直美美哒", images.size(), 0, 0, "刚刚", "西安·西安电子科技大学B楼",
                32, 24, true, images));
        images.clear();

        images.add(PICTURE_PATH + "20.gif");
        friendMoments.add(new MomentModel(2, 9, "郑茜", AVATAR_PATH + "9.jpg",
                "这天气要热死人了", images.size(), 299, 220, "12：20", "西安·西安电子科技大学海棠公寓8#",
                0, 0, false, images));
        images.clear();
        CacheTool.writeObjectToFile(friendMoments, ROOT_PATH + "friend");

        chatMessages = new ArrayList<>();
        chatMessages.add(new ChatMessageModel(123, "郑茜", AVATAR_PATH + "9.jpg",
                "", "08:50"));
        chatMessages.add(new ChatMessageModel(0, "戴宏", AVATAR_PATH + "0.jpg",
                "", "08:50"));
        chatMessages.add(new ChatMessageModel(1, "丁泽楠", AVATAR_PATH + "1.jpg",
                "晚上来一次实验室", "昨天  20:55"));
        chatMessages.add(new ChatMessageModel(2, "李喜林", AVATAR_PATH + "2.jpg",
                "好", "6月20日  18:35"));
        CacheTool.writeObjectToFile(chatMessages, ROOT_PATH + "chat");

        wordMessages = new ArrayList<>();
        wordMessages.add(new WordMessageModel(2, 0, "戴宏", AVATAR_PATH + "0.jpg", "12:21",
                "这天气要热死人了", "赞了你"));
        wordMessages.add(new WordMessageModel(2, 2, "李喜林", AVATAR_PATH + "2.jpg", "12:21",
                "这天气要热死人了", "留言：我在宿舍吹空调呢"));
        CacheTool.writeObjectToFile(wordMessages, ROOT_PATH + "word");

        friends = new ArrayList<>();
        friends.add(new FriendModel(0, "戴宏", AVATAR_PATH + "0.jpg", "D"));
        friends.add(new FriendModel(1, "丁泽楠", AVATAR_PATH + "1.jpg", "D"));
        friends.add(new FriendModel(2, "李喜林", AVATAR_PATH + "2.jpg", "L"));
        friends.add(new FriendModel(3, "马明旭", AVATAR_PATH + "3.jpg", "M"));
        friends.add(new FriendModel(4, "明瑞泉", AVATAR_PATH + "4.jpg", "M"));
        friends.add(new FriendModel(5, "汤子文", AVATAR_PATH + "5.jpg", "T"));
        friends.add(new FriendModel(6, "王稼伟", AVATAR_PATH + "6.jpg", "W"));
        friends.add(new FriendModel(7, "王鑫然", AVATAR_PATH + "7.jpg", "W"));
        friends.add(new FriendModel(8, "吴环宇", null, "W"));
        friends.add(new FriendModel(123, "郑茜", AVATAR_PATH + "9.jpg", "Z"));
        CacheTool.writeObjectToFile(friends, FRIENDS);

        comments = new ArrayList<>();
        HashMap<Integer,List<CommentModel>> h1= new HashMap<>();
        comments.add(new CommentModel(0,AVATAR_PATH+"2.jpg","李喜林","我在宿舍吹空调呢","昨天  12:21"));
        h1.put(2, comments);
        comments.clear();

        comments.add(new CommentModel(0,AVATAR_PATH+"5.jpg","汤子文","欢迎报考西安电子科技大学","08：20"));
        h1.put(1, comments);
        CacheTool.writeObjectToFile(h1, COMMENTS);

        chats = new ArrayList<>();
        HashMap<Integer,List<ChatModel>> h2 = new HashMap<>();
        //chats.add(new ChatModel(AVATAR_PATH+"9.jpg","今天天气真不错",null,"08:50",1));
        h2.put(123, chats);

        chats = new ArrayList<>();
        h2.put(0, chats);

        chats = new ArrayList<>();
        chats.add(new ChatModel(AVATAR_PATH+"1.jpg","想想咱们需要U盘么",null,"昨天  18:10",1));
        chats.add(new ChatModel(AVATAR_PATH+"9.jpg","应该需要吧",null,"昨天  20:55",2));
        chats.add(new ChatModel(AVATAR_PATH+"1.jpg","你写的那些给我发一个",null,"昨天  20:53",1));
        chats.add(new ChatModel(AVATAR_PATH+"1.jpg","在QQ上",null,null,1));
        chats.add(new ChatModel(AVATAR_PATH+"9.jpg","给你发过去了",null,"昨天  20:55",2));
        chats.add(new ChatModel(AVATAR_PATH+"1.jpg","晚上来一次实验室",null,null,1));
        h2.put(1, chats);

        chats = new ArrayList<>();
        chats.add(new ChatModel(AVATAR_PATH+"9.jpg","喜林，给我拍一下软件工程课本的封面",null,"6月20日  14：30",2));
        chats.add(new ChatModel(AVATAR_PATH+"9.jpg","在宿舍吗，我没带钥匙",null,"6月21日  18：30",2));
        chats.add(new ChatModel(AVATAR_PATH+"2.jpg","没，我在实验室，我没锁门，你吃完饭早点回去",null,"6月20日  18：35",1));
        chats.add(new ChatModel(AVATAR_PATH+"9.jpg","好",null,null,2));
        h2.put(2, chats);

        CacheTool.writeObjectToFile(h2, CHATS);
    }

    public static void main(String[] args) {
        writeCache();
    }
}
