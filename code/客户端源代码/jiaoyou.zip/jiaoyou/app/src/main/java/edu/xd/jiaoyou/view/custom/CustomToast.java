package edu.xd.jiaoyou.view.custom;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import edu.xd.jiaoyou.R;

/**
 * Created by ZhengXi on 2017/5/16.
 */

public class CustomToast {

    public static final int LENGTH_SHORT = Toast.LENGTH_SHORT;
    public static final int LENGTH_LONG = Toast.LENGTH_LONG;

    private Toast mToast = null;

    private CustomToast(Context context, CharSequence text, int duration) {
        mToast = new Toast(context);
        View view = LayoutInflater.from(context).inflate(R.layout.custom_toast, null);
        TextView textView = (TextView) view.findViewById(R.id.text);
        textView.setText(text);
        mToast.setDuration(duration);
        mToast.setView(view);
    }

    public static CustomToast makeText(Context context, CharSequence text, int duration) {
        return new CustomToast(context, text, duration);
    }

    public void show() {
        if (mToast != null) {
            mToast.show();
        }
    }

    public void cancel() {
        mToast.cancel();
    }

}
