package edu.xd.jiaoyou;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import edu.xd.jiaoyou.view.chat.ChatModel;
import edu.xd.jiaoyou.view.main.ChatMessageModel;
import edu.xd.jiaoyou.view.main.FriendModel;
import edu.xd.jiaoyou.view.main.MomentModel;
import edu.xd.jiaoyou.view.main.WordMessageModel;
import edu.xd.jiaoyou.view.momentdetail.CommentModel;

/**
 * Created by ZhengXi on 2017/6/12.
 */

public class Constant {

    public static final String SERVICE_IP = "http://120.24.92.213:8080/Myserver";

    public static class ViewTag {
        //标识mainPager中的所有Pager
        public static final int ERROR_TAG      = 0xFFFF;
        public static final int MOM_NEARBY_TAG = 0x0000;
        public static final int MOM_FRIEND_TAG = 0x0001;
        public static final int MSG_CHAT_TAG   = 0x0010;
        public static final int MSG_WORD_TAG   = 0x0011;
        public static final int FRIENDS_TAG    = 0x0020;
        //标识此主页所有者的TAG
        public static final int MINE_HOMEPAGE_TAG     = 0x0000;
        public static final int FRIEND_HOMEPAGE_TAG   = 0x0001;
        public static final int STRANGER_HOMEPAGE_TAG = 0x0002;
    }

    public static class ImageType {
        public static final int COMMON = 0x0000; //普通图片
        public static final int GIF    = 0x0001; //GIF图片
        public static final int LONG   = 0x0002; //长图片，即大于屏幕尺寸
    }

    public static class ChatType {
        public static final int ITEM_TYPE_LEFT  = 0x0001; //消息位于左侧（对方）
        public static final int ITEM_TYPE_RIGHT = 0x0002; //右侧（自己）
    }

    public static class AppPath {
        public static final String ROOT_PATH = "";
        //文件计算方式为类型hash值+日期
        public static final String MOM_NEARBY_PATH = String.valueOf("nearby".hashCode());
        public static final String MOM_FRIEND_PATH = String.valueOf("friend".hashCode());
        public static final String MSG_CHAT_PATH = String.valueOf("chat".hashCode());
        public static final String MSG_WORD_PATH = String.valueOf("word".hashCode());
    }

    public static class AppData {
        public static List<MomentModel> nearbyMoments = new ArrayList<>();
        public static List<MomentModel> friendMoments = new ArrayList<>();
        public static List<ChatMessageModel> chatMessages = new ArrayList<>();
        public static List<WordMessageModel> wordMessages = new ArrayList<>();
        public static List<FriendModel> friends = new ArrayList<>();
        public static HashMap<Integer,List<CommentModel>> comments = new HashMap<>();
        public static HashMap<Integer,List<ChatModel>> chats = new HashMap<>();
    }

    public static class AppCache {

    }
}
