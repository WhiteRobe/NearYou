package edu.xd.jiaoyou.view.momentdetail;

import java.io.Serializable;

/**
 * Created by ZhengXi on 2017/5/23.
 */

public class CommentModel implements Serializable {

    private static final long serialVersionUID = 1L;

    public int userId = -1;         //用户id
    public String profile = null;   //用户头像路径
    public String name = null;      //用户昵称/姓名
    public String content = null;   //评论内容
    public String time = null;      //评论时间

    public CommentModel(int userId,String profile, String name, String content, String time) {
        this.userId = userId;
        this.profile = profile;
        this.name = name;
        this.content = content;
        this.time = time;
    }

    public boolean hasProfile() {
        if(profile == null || profile.equals("")) return false;
        return true;
    }
}
