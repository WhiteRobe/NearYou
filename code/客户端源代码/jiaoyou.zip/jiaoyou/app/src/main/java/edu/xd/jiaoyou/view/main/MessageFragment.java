package edu.xd.jiaoyou.view.main;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import edu.xd.jiaoyou.Constant;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.view.CommonFragmentPagerAdapter;

/**
 * Created by ZhengXi on 2017/6/19.
 */

public class MessageFragment extends Fragment {

    private static final int STATE_OFFLINE = 0x0000; //掉线
    private static final int STATE_TOP     = 0x0001; //recyclerView在最顶部
    private static final int STATE_COMMON  = 0x0002; //滑动之后的状态

    private View mView;
    private Button btnMine;
    private Button btnSearch;
    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    private FragmentPagerAdapter mAdapter = null;
    private ChatMessageFragment chatMessageFragment = null;
    private WordMessageFragment wordMessageFragment = null;
    private OnTitleClickListener onTitleClickListener = null;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        chatMessageFragment = new ChatMessageFragment();
        wordMessageFragment = new WordMessageFragment();
        List<Fragment> fragments = new ArrayList<>();
        fragments.add(chatMessageFragment);
        fragments.add(wordMessageFragment);
        mAdapter = new CommonFragmentPagerAdapter(getChildFragmentManager(),fragments);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_main_messages,container,false);

        btnMine = (Button) mView.findViewById(R.id.btn_main_mine);
        btnSearch = (Button) mView.findViewById(R.id.btn_main_search);

        mTabLayout = (TabLayout) mView.findViewById(R.id.tab_main);

        mViewPager = (ViewPager) mView.findViewById(R.id.viewPager_messages);
        mViewPager.setAdapter(mAdapter);
        mViewPager.addOnPageChangeListener(new TabLayoutOnPageChangeListener(mTabLayout));

        mTabLayout.addTab(mTabLayout.newTab().setText("聊天"));
        mTabLayout.addTab(mTabLayout.newTab().setText("留言"));
        mTabLayout.addOnTabSelectedListener(new OnTabSelectedListener());

        setOnClickEvent();
        return mView;
    }

    //获取当前viewPager页面
    public int getCurrentPage() {
        int current = mViewPager.getCurrentItem();
        if (current == 0) return Constant.ViewTag.MSG_CHAT_TAG;
        else if (current == 1) return Constant.ViewTag.MSG_WORD_TAG;
        return Constant.ViewTag.ERROR_TAG;
    }

    //刷新事件
    public void autoRefresh() {
        int current = mViewPager.getCurrentItem();
    }

    //toolbar点击事件
    public void setOnTitleClickListener(OnTitleClickListener onTitleClickListener) {
        this.onTitleClickListener = onTitleClickListener;
    }

    //设置view点击事件
    private void setOnClickEvent() {
        btnMine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onTitleClickListener!=null)
                    onTitleClickListener.onTitleClick(v,v.getId());
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onTitleClickListener!=null)
                    onTitleClickListener.onTitleClick(v,v.getId());
            }
        });
    }

    //tab监听viewPager滑动事件
    private class TabLayoutOnPageChangeListener extends TabLayout.TabLayoutOnPageChangeListener {
        public TabLayoutOnPageChangeListener(TabLayout tabLayout) {
            super(tabLayout);
        }

        @Override
        public void onPageSelected(int position) {

        }
    }

    //tab选中事件
    private class OnTabSelectedListener implements TabLayout.OnTabSelectedListener {
        @Override
        public void onTabSelected(TabLayout.Tab tab) {
            mViewPager.setCurrentItem(tab.getPosition());
        }
        @Override
        public void onTabUnselected(TabLayout.Tab tab) {}
        @Override
        public void onTabReselected(TabLayout.Tab tab) {}
    }
}
