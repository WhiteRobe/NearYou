package edu.xd.jiaoyou.view.main;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.view.custom.CircleImageView;
import edu.xd.jiaoyou.view.custom.ImageTextButton;
import edu.xd.jiaoyou.view.custom.NineGridView;

/**
 * Created by ZhengXi on 2017/5/23.
 */

public class MomentAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int ITEM_TYPE_CONTENT = 0x0001; //内容
    public static final int ITEM_TYPE_FOOTER  = 0x0002; //尾部

    private Context mContext = null;
    private List<MomentModel> mData = null;
    private View convertView = null;
    private RecyclerView.ViewHolder mHolder = null;

    private OnItemClickListener onItemClickListener = null;
    private OnButtonClickListener onButtonClickListener = null;
    private OnImageClickListener onImageClickListener = null;

    public MomentAdapter() {
        mData = new ArrayList<>();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        mContext = parent.getContext();
        if (viewType == ITEM_TYPE_CONTENT) {
            convertView = LayoutInflater.from(parent.getContext()).inflate
                    (R.layout.item_moments,parent,false);
            mHolder = new ContentViewHolder(convertView);
        }
        else if(viewType == ITEM_TYPE_FOOTER) {
            //inflate()参数只能为 layout,parent,false
            //layout,null   不能居中显示
            //layout,parent 会抛出父view已经包含了其他view的异常
            //{@link http://blog.csdn.net/starry_night123/article/details/52512019}
            convertView = LayoutInflater.from(parent.getContext()).inflate
                    (R.layout.footview_main_moments,parent,false);
            mHolder = new FooterViewHolder(convertView);
        }
        return mHolder;
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        if(holder instanceof ContentViewHolder) {
            final MomentModel item = mData.get(position);
            holder.itemView.setTag(position);
            ((ContentViewHolder) holder).tvName.setText(item.name);
            ((ContentViewHolder) holder).tvContent.setText(item.content);
            ((ContentViewHolder) holder).tvTime.setText(item.time);
            ((ContentViewHolder) holder).tvPlace.setText(item.place);
            if (item.hasProfile())
                loadProfile(item.profile,((ContentViewHolder) holder).cvProfile);
            //((ContentViewHolder) holder).cvProfile.setTag("profile");
            ((ContentViewHolder) holder).cvProfile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(onButtonClickListener!=null)
                        onButtonClickListener.onButtonClick(v,(String) v.getTag(),item.id);
                }
            });

            ((ContentViewHolder) holder).imgPicture.onCreateView(item.pictures,item.width,item.height);
            if (item.hasPicture()) {
                ((ContentViewHolder) holder).imgPicture.setImageFromUrl(item.images);
                //设置图片点击事件
                if (onImageClickListener!=null) {
                    ((ContentViewHolder) holder).imgPicture.setOnItemClickListener(new NineGridView.OnItemClickListener() {
                        @Override
                        public void onItemClick(View view, int index) {
                            onImageClickListener.onImageClick(view,index,item.id);
                        }
                    });
                }

                View view = ((ContentViewHolder) holder).divider;
                RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) view.getLayoutParams();
                int marginTop= (int) view.getContext().getResources().getDimension(R.dimen.y42);
                params.setMargins(0,marginTop,0,0);
                view.setLayoutParams(params);
            }

            if (item.isLike) {
                ((ContentViewHolder) holder).btnLike.setImageResource(R.drawable.like_clicked);
                ((ContentViewHolder) holder).btnLike.setTextColor(Color.rgb(246, 79, 76));
            }
            String likes = "赞", comments = "评论";
            if (item.likes > 0) likes = item.likes + "";
            if (item.comments > 0) comments = item.comments + "";
            ((ContentViewHolder) holder).btnLike.setText(likes);
            //((ContentViewHolder) holder).btnLike.setTag("like");
            //设置点赞事件
            ((ContentViewHolder) holder).btnLike.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(onButtonClickListener!=null)
                        onButtonClickListener.onButtonClick(v,(String) v.getTag(),item.id);
                }
            });

            if (item.isLike) ((ContentViewHolder) holder).btnLike.setTag("like");
            else ((ContentViewHolder) holder).btnLike.setTag("unlike");
            ((ContentViewHolder) holder).btnLike.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (v.getTag().equals("like")) {
                        ((ContentViewHolder) holder).btnLike.setImageDrawable(
                                mContext.getDrawable(R.drawable.like));
                        ((ContentViewHolder) holder).btnLike.setText("0");
                        ((ContentViewHolder) holder).btnLike.setTag("unlike");
                    }
                    else if (v.getTag().equals("unlike")) {
                        ((ContentViewHolder) holder).btnLike.setImageDrawable(
                                mContext.getDrawable(R.drawable.like_clicked));
                        ((ContentViewHolder) holder).btnLike.setText("1");
                        ((ContentViewHolder) holder).btnLike.setTag("unlike");
                    }
                }
            });

            ((ContentViewHolder) holder).btnComments.setText(comments);

            //设置item点击事件
            ((ContentViewHolder) holder).itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onItemClickListener != null)
                        onItemClickListener.onItemClick(v,position);
                }
            });
        }

        else if(holder instanceof FooterViewHolder) {}
    }

    @Override
    public int getItemViewType(int position) {
        //当动态内容大于等于10的时候才显示footview
        if(mData.size()>=10 && position==mData.size())
            return ITEM_TYPE_FOOTER;
        else return ITEM_TYPE_CONTENT;
    }

    @Override
    public int getItemCount() {
        return hasFootView() ? mData.size()+1 :mData.size();
    }

    //判断当前recyclerView中是否显示footView
    public boolean hasFootView() {
        return mData.size()>=10;
    }
    
    //获取指定位置的动态id
    public int getMomentId(int position) {
        return mData.get(position).id;
    }

    //获取指定位置的动态图片
    public List<String> getMomentImages(int position) {
        return mData.get(position).images;
    }

    //获取指定位置的源数据
    public MomentModel getItemByPosition(int position) {
        return mData.get(position);
    }

    //添加数据到原数据末尾
    public void add(MomentModel data) {
        mData.add(data);
        this.notifyDataSetChanged();
    }

    public void add(List<MomentModel> data) {
        mData.addAll(data);
        this.notifyDataSetChanged();
    }

    //在指定位置插入数据
    public void insert(int position,MomentModel data) {
        check(position);
        if(position==getItemCount()) this.add(data);
        else {
            mData.add(position,data);
            this.notifyDataSetChanged();
        }
    }

    public void insert(int position,List<MomentModel> data) {
        check(position);
        if(position==getItemCount()) this.add(data);
        else {
            mData.addAll(position,data);
            this.notifyDataSetChanged();
        }
    }

    private void check(int position) {
        if(position<0||position>mData.size())
            throw new IllegalArgumentException("the position may be illegal");
    }
    
    public interface OnItemClickListener {
        void onItemClick(View view,int position);
    }

    public interface OnButtonClickListener {
        void onButtonClick(View view,String viewTag,int position);
    }

    public interface OnImageClickListener {
        void onImageClick(View view,int imageId,int position);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setOnButtonClickListener(OnButtonClickListener onButtonClickListener) {
        this.onButtonClickListener = onButtonClickListener;
    }

    public void setOnImageClickListener(OnImageClickListener onImageClickListener) {
        this.onImageClickListener = onImageClickListener;
    }

    private void loadProfile(String url,ImageView view) {
        Glide.with(convertView.getContext())
                .load(url)
                .asBitmap()
                .centerCrop()
                .into(view);
    }

    private static class ContentViewHolder extends RecyclerView.ViewHolder {
        public CircleImageView cvProfile = null;
        public TextView tvName = null;
        public TextView tvContent = null;
        public TextView tvTime = null;
        public TextView tvPlace = null;
        public NineGridView imgPicture = null;
        public View divider = null;
        public ImageTextButton btnLike = null;
        public ImageTextButton btnComments = null;
        public ImageTextButton btnEdit = null;

        public ContentViewHolder(View itemView) {
            super(itemView);
            cvProfile = (CircleImageView) itemView.findViewById(R.id.img_moments_profile);
            tvName = (TextView) itemView.findViewById(R.id.textView_moments_name);
            tvContent = (TextView) itemView.findViewById(R.id.textView_moments_content);
            tvTime = (TextView) itemView.findViewById(R.id.textView_moments_time);
            tvPlace = (TextView) itemView.findViewById(R.id.textView_moments_place);
            imgPicture = (NineGridView) itemView.findViewById(R.id.img_moments_picture);
            divider = (View) itemView.findViewById(R.id.view_moments_divider);
            btnLike = (ImageTextButton) itemView.findViewById(R.id.btn_moments_like);
            btnComments = (ImageTextButton) itemView.findViewById(R.id.btn_moments_comments);
            btnEdit = (ImageTextButton) itemView.findViewById(R.id.btn_moments_edit);
        }
    }

    private static class FooterViewHolder extends RecyclerView.ViewHolder {
        public FooterViewHolder(View itemView) {
            super(itemView);
            ImageView gifLoad = (ImageView) itemView.findViewById(R.id.img_load);
            Glide.with(itemView.getContext())
                    .load(R.drawable.load)
                    .asGif()
                    .into(gifLoad);
        }
    }
}
