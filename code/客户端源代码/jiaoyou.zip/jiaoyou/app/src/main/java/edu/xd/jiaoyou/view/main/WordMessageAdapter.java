package edu.xd.jiaoyou.view.main;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.daimajia.swipe.SwipeLayout;

import java.util.ArrayList;
import java.util.List;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.view.custom.CircleImageView;

/**
 * Created by ZhengXi on 2017/5/22.
 */

public class WordMessageAdapter extends RecyclerView.Adapter<WordMessageAdapter.ViewHolder> {

    private List<WordMessageModel> mData = null;
    private View convertView = null;
    private ViewHolder mHolder = null;

    private OnItemClickListener onItemClickListener = null;
    private OnItemLongClickListener onItemLongClickListener = null;
    private SwipeLayout.SwipeListener swipeListener = null;

    public WordMessageAdapter() {
        mData = new ArrayList<>();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent,int viewType) {
        convertView = LayoutInflater.from(parent.getContext()).inflate
                (R.layout.item_message_words,parent,false);
        mHolder = new ViewHolder(convertView);
        return mHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        WordMessageModel item = mData.get(position);//获取信息实体

        if(swipeListener!=null)
            holder.mSwipeLayout.addSwipeListener(swipeListener);

        if(item.hasProfile()) {
            Glide.with(holder.itemView.getContext())
                    .load(item.profile)
                    .asBitmap()
                    .into(holder.cvProfilePhoto);
        }
        holder.tvName.setText(item.name);
        holder.tvContent.setText(item.content);
        holder.tvTime.setText(item.time);
        holder.tvBrief.setText(item.brief);

        //点击事件
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onItemClickListener!=null)
                    onItemClickListener.onItemClick(v,position);
            }
        });
        //长按事件
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if(onItemLongClickListener!=null)
                    onItemLongClickListener.onItemLongClick(v,position);
                return false;
            }
        });

        //删除事件
        holder.tvDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mData.remove(position);
                notifyItemRangeChanged(0,position-1);
                notifyItemRemoved(position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void add(WordMessageModel data) {
        mData.add(data);
        this.notifyDataSetChanged();
    }

    public void add(List<WordMessageModel> data) {
        mData.addAll(data);
        this.notifyDataSetChanged();
    }

    public void insert(int position,WordMessageModel data) {
        check(position);
        if(position==getItemCount()) this.add(data);
        else {
            mData.add(position,data);
            this.notifyDataSetChanged();
        }
    }

    public void insert(int position,List<WordMessageModel> data) {
        check(position);
        if(position==getItemCount()) this.add(data);
        else {
            mData.addAll(position,data);
            this.notifyDataSetChanged();
        }
    }

    private void check(int position) {
        if(position<0||position>mData.size())
            throw new IllegalArgumentException("the position may be illegal");
    }


    public interface OnItemClickListener {
        void onItemClick(View view,int position);
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(View view,int position);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener onItemLongClickListener) {
        this.onItemLongClickListener = onItemLongClickListener;
    }

    public void setSwipeListener(SwipeLayout.SwipeListener swipeListener) {
        this.swipeListener = swipeListener;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        public SwipeLayout mSwipeLayout = null;
        public CircleImageView cvProfilePhoto = null;
        public TextView tvName = null;
        public TextView tvContent = null;
        public TextView tvBrief = null;
        public TextView tvTime = null;
        public TextView tvDelete = null;

        public ViewHolder(View itemView) {
            super(itemView);
            mSwipeLayout = (SwipeLayout) itemView.findViewById(R.id.swipelayout);

            cvProfilePhoto = (CircleImageView) itemView.findViewById
                    (R.id.img_messages_profilePhoto);
            tvName = (TextView) itemView.findViewById(R.id.textView_messages_name);
            tvContent = (TextView) itemView.findViewById(R.id.textView_messages_word);
            tvTime = (TextView) itemView.findViewById(R.id.textView_messages_time);
            tvBrief = (TextView) itemView.findViewById(R.id.textView_messages_momentBrief);

            tvDelete = (TextView) itemView.findViewById(R.id.delete);
        }

    }
}
