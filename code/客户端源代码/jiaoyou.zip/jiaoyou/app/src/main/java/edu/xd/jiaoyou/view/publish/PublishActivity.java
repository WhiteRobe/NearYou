package edu.xd.jiaoyou.view.publish;

import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import edu.xd.jiaoyou.BaseApplication;
import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.InfoValue;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.UserInfoActivity;
import edu.xd.jiaoyou.view.custom.CustomToast;
import edu.xd.jiaoyou.view.main.MainActivity;
import edu.xd.jiaoyou.view.photoviewer.PhotoViewerActivity;
import github.imageselector.ImageConfig;
import github.imageselector.ImageSelector;
import github.imageselector.ImageSelectorActivity;

/**
 * Created by ZhengXi on 2017/6/6.
 */

public class PublishActivity extends AppCompatActivity {

    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;

    private UICallback uiCallback=new UICallback() {
        @Override
        public void dealServerRes(JSONObject msgIn) {}

        @Override
        public void dealServerPush(JSONObject msgIn) {
            System.out.println(msgIn);
            String response = null;
            try {
                JSONObject data = msgIn.getJSONObject("Data");
                response = data.getString("Class");
            } catch (JSONException e){
                e.printStackTrace();
            }
            if(response.equals(InfoValue.MsgPush.Success)) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        CustomToast.makeText(PublishActivity.this,"发送成功",
                                CustomToast.LENGTH_SHORT).show();
                        Intent intent = new Intent(PublishActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                });
            }
        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {

        }

        @Override
        public void localMsg(String msg) {
            System.out.println("msg"+msg);
        }
    };

    private ServiceConnection connection=new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
            dataService.setUICallback(uiCallback);
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
        }
    };

    private Button btnCancel;
    private Button btnSend;
    private EditText editText;
    private TextView tvLocation;
    private TextView tvLength;
    private TextView tvPrivacy;
    private GridView addImage;

    private GridViewAddImagesAdapter mAdapter;
    private String content;
    private List<String> images;
    private boolean success = false; //判断是否上传成功

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publish);

        Intent bindIntent = new Intent(PublishActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (dataService==null) {}
                tvLocation.post(new Runnable() {
                    @Override
                    public void run() {
                        tvLocation.setText(dataService.getGdMap().getCity()+"·"+dataService
                                .getGdMap().getStreet());
                    }
                });
            }
        }).start();
        init();

        event();
    }

    private void init() {
        btnCancel = (Button) findViewById(R.id.btn_cancel);
        btnSend = (Button) findViewById(R.id.btn_send);
        editText = (EditText) findViewById(R.id.editText_publish);
        tvLength = (TextView) findViewById(R.id.text_publish_length);
        tvPrivacy = (TextView) findViewById(R.id.privacy);
        tvLocation = (TextView) findViewById(R.id.text_publish_location);

        addImage = (GridView) findViewById(R.id.grid_addimage);
        images = new ArrayList<>();
        mAdapter = new GridViewAddImagesAdapter(images);
        addImage.setAdapter(mAdapter);
    }

    private void event() {
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCancel();
            }
        });

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (content == null || content.equals(""))
                    content = "  ";

                if (images == null ||images.size() == 0)
                    dataService.sendMomentWithoutPic(content,true);
                else if (images.size() == 1)
                    dataService.sendMomentWithPic(images.get(0),content,true);
                else dataService.sendMomentWithMultiPic(images,images.size(),content,true);
            }
        });

        tvPrivacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                content = editText.getText().toString();
                tvLength.setText(content.length()+"/140");
                if(content.length()==0) btnCancel.setBackground(getDrawable(R.drawable.setting_back));
                else btnCancel.setBackground(getDrawable(R.drawable.cancel));
            }
        });

        final int maxImages = 9;
        mAdapter.setOnItemClickListener(new GridViewAddImagesAdapter.OnItemClickListener() {
            @Override
            public void onClickBlankImage(int position) {
                ImageConfig config = ((BaseApplication) getApplication()).getMultiSelect(
                        maxImages-mAdapter.getCount()+1);
                ImageSelector.open(PublishActivity.this,config);
            }

            @Override
            public void onClickAlreadyImage(int position) {
                Intent intent = new Intent(PublishActivity.this, PhotoViewerActivity.class);
                intent.putExtra("image_list",(Serializable) images);
                intent.putExtra("current_item",position);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onDestroy() {
        unbindService(connection);
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ImageSelector.IMAGE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            images.addAll(data.getStringArrayListExtra(ImageSelectorActivity.EXTRA_RESULT));
            mAdapter.notifyDataSetChanged(images);
        }
    }

    @Override
    public void onBackPressed() {
        onCancel();
    }

    private void onCancel() {
        //有内容，按返回键时弹出对话框
        DialogOnClickListener listener = new DialogOnClickListener();
        if(content!=null && !content.equals("") || images!=null && images.size()!=0) {
            AlertDialog dialog = new AlertDialog.Builder(PublishActivity.this)
                    .setTitle("提示")
                    .setMessage("还有内容未发布，确定离开吗")
                    .setNegativeButton("取消",listener)
                    .setPositiveButton("确定",listener)
                    .show();
        }
        //发送动态未接收到服务器反馈时
        //else if(!success) {

        //}
        else {
            super.onBackPressed();
        }
    }

    /**
     * 获取上传的图片的原始尺寸
     */
    private void getImageSize() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                Bitmap bitmap;
                for(int i=0;i<images.size();i++) {
                    bitmap = BitmapFactory.decodeFile(images.get(i));
                    bitmap.getWidth();
                    bitmap.getHeight();
                    bitmap.recycle();
                }
                success = true;
            }
        }).start();
    }

    //
    private class DialogOnClickListener implements DialogInterface.OnClickListener {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            if (which == DialogInterface.BUTTON_POSITIVE) {
                Intent intent = new Intent(PublishActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
            else if (which == DialogInterface.BUTTON_NEGATIVE) {
                dialog.dismiss();
            }
        }
    }
}
