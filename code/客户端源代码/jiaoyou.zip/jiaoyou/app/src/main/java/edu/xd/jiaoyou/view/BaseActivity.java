package edu.xd.jiaoyou.view;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import java.lang.reflect.Method;

import edu.xd.jiaoyou.data.UICallback;

/**
 * Created by ZhengXi on 2017/5/30.
 */

public class BaseActivity extends AppCompatActivity {

    private static int SCREEN_WIDTH  = 0;
    private static int SCREEN_HEIGHT = 0;
    private static int WINDOW_HEIGHT = 0;
    private static int STATUS_HEIGHT = 0;
    private static int VIRTUAL_KEY_HEIGHT = 0;

    public int getScreenWidth() {
        if(SCREEN_WIDTH==0) getScreenSize();
        return SCREEN_WIDTH;
    }

    public int getScreenHeight() {
        if(STATUS_HEIGHT==0) getScreenSize();
        return SCREEN_HEIGHT;
    }

    /**
     * 获取屏幕原始尺寸
     */
    private void getScreenSize() {
        WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        Class c;
        try {
            c = Class.forName("android.view.Display");
            Method method = c.getMethod("getRealMetrics",DisplayMetrics.class);
            method.invoke(display, displayMetrics);
            SCREEN_WIDTH  = displayMetrics.widthPixels;
            SCREEN_HEIGHT = displayMetrics.heightPixels;
        } catch(Exception e){e.printStackTrace();}
    }

    /**
     * 获得屏幕除去虚拟键的高度，即可绘制view窗口的高度
     */
    public int getWindowHeight() {
        if(WINDOW_HEIGHT==0) {
            WindowManager windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            DisplayMetrics outMetrics = new DisplayMetrics();
            windowManager.getDefaultDisplay().getMetrics(outMetrics);
            SCREEN_HEIGHT = outMetrics.heightPixels;
            SCREEN_WIDTH = outMetrics.widthPixels;
        }
        return WINDOW_HEIGHT;
    }

    /**
     * 获取底部虚拟键的高度
     */
    public int getVirtualKeyHeight() {
        if(VIRTUAL_KEY_HEIGHT==0) {
            getScreenSize();
            getWindowHeight();
            VIRTUAL_KEY_HEIGHT = SCREEN_HEIGHT - WINDOW_HEIGHT;
        }
        return VIRTUAL_KEY_HEIGHT;
    }

    /**
     * 获得状态栏的高度
     */
    public int getStatusHeight() {
        if(STATUS_HEIGHT==0) {
            try {
                Class<?> clazz = Class.forName("com.android.internal.R$dimen");
                Object object = clazz.newInstance();
                int height = Integer.parseInt(clazz.getField("status_bar_height")
                        .get(object).toString());
                STATUS_HEIGHT = getResources().getDimensionPixelSize(height);
            } catch (Exception e) {e.printStackTrace();}
        }
        return STATUS_HEIGHT;
    }

}
