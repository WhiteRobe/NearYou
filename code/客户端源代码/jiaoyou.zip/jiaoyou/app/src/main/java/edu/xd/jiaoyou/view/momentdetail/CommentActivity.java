package edu.xd.jiaoyou.view.momentdetail;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by ZhengXi on 2017/6/18.
 */

public class CommentActivity extends AppCompatActivity {
}
