package edu.xd.jiaoyou.view;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import org.json.JSONObject;

import edu.xd.jiaoyou.R;
import edu.xd.jiaoyou.data.DataService;
import edu.xd.jiaoyou.data.UICallback;
import edu.xd.jiaoyou.view.chat.ChatActivity;
import edu.xd.jiaoyou.view.custom.CircleImageView;

/**
 * Created by ZhengXi on 2017/6/18.
 */

public class UserPageActivity extends AppCompatActivity {

    private DataService.ServiceBinder serviceBinder = null;
    private DataService dataService = null;
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            serviceBinder=(DataService.ServiceBinder)iBinder;
            dataService=serviceBinder.getDataService();
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            dataService.setUICallback(null);
            dataService=null;
        }
    };
    private UICallback uiCallback = new UICallback() {
        @Override
        public void dealServerRes(JSONObject msgIn) {

        }

        @Override
        public void dealServerPush(JSONObject msgIn) {

        }

        @Override
        public void dealServerMessage(JSONObject msgIn) {

        }
        @Override
        public void localMsg(String msg) {

        }
    };

    private Button btnBack;
    private Button btnInfo;
    private TextView tvTitle;
    private CircleImageView cvProfile;
    private TextView tvName;
    private TextView tvLocation;
    private RelativeLayout homepage;
    private Button btnSend;

    private int userId = -1;            //此界面userId
    private String userName;
    private String userProfile;
    private boolean isStranger = false; //是否为陌生人，默认为false，添加新朋友时将设此值true

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userpage);

        Intent bindIntent = new Intent(UserPageActivity.this, DataService.class);
        bindService(bindIntent, connection, BIND_AUTO_CREATE);

        //获得当前用户id
        Intent intent = getIntent();
        userId = intent.getIntExtra("userId",-1);
        userName = intent.getStringExtra("userName");
        userProfile = intent.getStringExtra("userProfile");
        isStranger = intent.getBooleanExtra("stranger",false);
        System.out.println("userPage:"+userId+"  "+userName+"  "+userProfile);

        init();
    }

    @Override
    public void onDestroy() {
        unbindService(connection);
        super.onDestroy();
    }

    private void init() {
        btnBack = (Button) findViewById(R.id.btn_back);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        btnInfo = (Button) findViewById(R.id.btn_function);
        btnInfo.setBackground(getDrawable(R.drawable.user_info));
        btnInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserPageActivity.this,UserInfoActivity.class);
                intent.putExtra("userId",userId);
                startActivity(intent);
            }
        });

        tvTitle = (TextView) findViewById(R.id.textView_title);
        tvTitle.setText("个人资料");

        cvProfile = (CircleImageView) findViewById(R.id.img_userpage_profile);
        Glide.with(UserPageActivity.this)
                .load(userProfile)
                .asBitmap().
                into(cvProfile);

        tvName = (TextView) findViewById(R.id.textView_userpage_name);
        tvName.setText(userName);
        tvLocation = (TextView) findViewById(R.id.textView_userpage_location);

        homepage = (RelativeLayout) findViewById(R.id.rLayout_userpage_homepage);
        homepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserPageActivity.this,HomepageActivity.class);
                intent.putExtra("userId",userId);
                startActivity(intent);
            }
        });

        btnSend = (Button) findViewById(R.id.btn_userpage_send);
        if (isStranger) btnSend.setText("加好友");
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isStranger) {
                    dataService.setUICallback(uiCallback);
                    //dataService.
                }
                else {
                    Intent intent = new Intent(UserPageActivity.this, ChatActivity.class);
                    intent.putExtra("userId",userId);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
